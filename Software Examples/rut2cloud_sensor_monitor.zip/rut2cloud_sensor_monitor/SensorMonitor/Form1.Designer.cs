﻿namespace SensorMonitor
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea5 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea6 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series6 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea7 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series7 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea8 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series8 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea9 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series9 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.PortSelectorBox = new System.Windows.Forms.ComboBox();
            this.ports_label = new System.Windows.Forms.Label();
            this.start_button = new System.Windows.Forms.Button();
            this.stop_button = new System.Windows.Forms.Button();
            this.serial = new System.IO.Ports.SerialPort(this.components);
            this.DebugOutputBox = new System.Windows.Forms.TextBox();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.temperatureBox = new System.Windows.Forms.TextBox();
            this.pressureBox = new System.Windows.Forms.TextBox();
            this.humidityBox = new System.Windows.Forms.TextBox();
            this.AccX_Box = new System.Windows.Forms.TextBox();
            this.AccY_Box = new System.Windows.Forms.TextBox();
            this.AccZ_Box = new System.Windows.Forms.TextBox();
            this.GyrZ_Box = new System.Windows.Forms.TextBox();
            this.GyrY_Box = new System.Windows.Forms.TextBox();
            this.GyrX_Box = new System.Windows.Forms.TextBox();
            this.MagY_Box = new System.Windows.Forms.TextBox();
            this.MagZ_Box = new System.Windows.Forms.TextBox();
            this.MagX_Box = new System.Windows.Forms.TextBox();
            this.chartAccX = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.chartAccY = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartAccZ = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.chartGyrZ = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartGyrY = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.chartGyrX = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartMagZ = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartMagY = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.chartMagX = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.port_scanner = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.chartAccX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartAccY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartAccZ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartGyrZ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartGyrY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartGyrX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartMagZ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartMagY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartMagX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // PortSelectorBox
            // 
            this.PortSelectorBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PortSelectorBox.FormattingEnabled = true;
            this.PortSelectorBox.Location = new System.Drawing.Point(27, 48);
            this.PortSelectorBox.Name = "PortSelectorBox";
            this.PortSelectorBox.Size = new System.Drawing.Size(121, 21);
            this.PortSelectorBox.TabIndex = 0;
            // 
            // ports_label
            // 
            this.ports_label.AutoSize = true;
            this.ports_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ports_label.Location = new System.Drawing.Point(24, 26);
            this.ports_label.Name = "ports_label";
            this.ports_label.Size = new System.Drawing.Size(81, 13);
            this.ports_label.TabIndex = 1;
            this.ports_label.Text = "Port Selector";
            // 
            // start_button
            // 
            this.start_button.BackColor = System.Drawing.Color.ForestGreen;
            this.start_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.start_button.Location = new System.Drawing.Point(184, 39);
            this.start_button.Name = "start_button";
            this.start_button.Size = new System.Drawing.Size(85, 32);
            this.start_button.TabIndex = 2;
            this.start_button.Text = "START";
            this.start_button.UseVisualStyleBackColor = false;
            this.start_button.Click += new System.EventHandler(this.start_button_Click);
            // 
            // stop_button
            // 
            this.stop_button.BackColor = System.Drawing.Color.Red;
            this.stop_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stop_button.Location = new System.Drawing.Point(275, 39);
            this.stop_button.Name = "stop_button";
            this.stop_button.Size = new System.Drawing.Size(75, 32);
            this.stop_button.TabIndex = 3;
            this.stop_button.Text = "STOP";
            this.stop_button.UseVisualStyleBackColor = false;
            this.stop_button.Click += new System.EventHandler(this.stop_button_Click);
            // 
            // DebugOutputBox
            // 
            this.DebugOutputBox.Location = new System.Drawing.Point(380, 23);
            this.DebugOutputBox.Multiline = true;
            this.DebugOutputBox.Name = "DebugOutputBox";
            this.DebugOutputBox.ReadOnly = true;
            this.DebugOutputBox.Size = new System.Drawing.Size(222, 94);
            this.DebugOutputBox.TabIndex = 4;
            // 
            // timer
            // 
            this.timer.Interval = 50;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // temperatureBox
            // 
            this.temperatureBox.BackColor = System.Drawing.SystemColors.Window;
            this.temperatureBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.temperatureBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.temperatureBox.Location = new System.Drawing.Point(27, 97);
            this.temperatureBox.Name = "temperatureBox";
            this.temperatureBox.ReadOnly = true;
            this.temperatureBox.Size = new System.Drawing.Size(63, 15);
            this.temperatureBox.TabIndex = 5;
            // 
            // pressureBox
            // 
            this.pressureBox.BackColor = System.Drawing.SystemColors.Window;
            this.pressureBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.pressureBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pressureBox.Location = new System.Drawing.Point(144, 97);
            this.pressureBox.Name = "pressureBox";
            this.pressureBox.ReadOnly = true;
            this.pressureBox.Size = new System.Drawing.Size(72, 15);
            this.pressureBox.TabIndex = 6;
            // 
            // humidityBox
            // 
            this.humidityBox.BackColor = System.Drawing.SystemColors.Window;
            this.humidityBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.humidityBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.humidityBox.Location = new System.Drawing.Point(250, 97);
            this.humidityBox.Name = "humidityBox";
            this.humidityBox.ReadOnly = true;
            this.humidityBox.Size = new System.Drawing.Size(65, 15);
            this.humidityBox.TabIndex = 7;
            // 
            // AccX_Box
            // 
            this.AccX_Box.Location = new System.Drawing.Point(169, 135);
            this.AccX_Box.Name = "AccX_Box";
            this.AccX_Box.ReadOnly = true;
            this.AccX_Box.Size = new System.Drawing.Size(100, 20);
            this.AccX_Box.TabIndex = 8;
            // 
            // AccY_Box
            // 
            this.AccY_Box.Location = new System.Drawing.Point(570, 131);
            this.AccY_Box.Name = "AccY_Box";
            this.AccY_Box.ReadOnly = true;
            this.AccY_Box.Size = new System.Drawing.Size(100, 20);
            this.AccY_Box.TabIndex = 9;
            // 
            // AccZ_Box
            // 
            this.AccZ_Box.Location = new System.Drawing.Point(943, 131);
            this.AccZ_Box.Name = "AccZ_Box";
            this.AccZ_Box.ReadOnly = true;
            this.AccZ_Box.Size = new System.Drawing.Size(100, 20);
            this.AccZ_Box.TabIndex = 10;
            // 
            // GyrZ_Box
            // 
            this.GyrZ_Box.Location = new System.Drawing.Point(943, 313);
            this.GyrZ_Box.Name = "GyrZ_Box";
            this.GyrZ_Box.ReadOnly = true;
            this.GyrZ_Box.Size = new System.Drawing.Size(100, 20);
            this.GyrZ_Box.TabIndex = 13;
            // 
            // GyrY_Box
            // 
            this.GyrY_Box.Location = new System.Drawing.Point(570, 313);
            this.GyrY_Box.Name = "GyrY_Box";
            this.GyrY_Box.ReadOnly = true;
            this.GyrY_Box.Size = new System.Drawing.Size(100, 20);
            this.GyrY_Box.TabIndex = 12;
            // 
            // GyrX_Box
            // 
            this.GyrX_Box.Location = new System.Drawing.Point(169, 313);
            this.GyrX_Box.Name = "GyrX_Box";
            this.GyrX_Box.ReadOnly = true;
            this.GyrX_Box.Size = new System.Drawing.Size(100, 20);
            this.GyrX_Box.TabIndex = 11;
            // 
            // MagY_Box
            // 
            this.MagY_Box.Location = new System.Drawing.Point(570, 510);
            this.MagY_Box.Name = "MagY_Box";
            this.MagY_Box.ReadOnly = true;
            this.MagY_Box.Size = new System.Drawing.Size(100, 20);
            this.MagY_Box.TabIndex = 16;
            // 
            // MagZ_Box
            // 
            this.MagZ_Box.Location = new System.Drawing.Point(943, 514);
            this.MagZ_Box.Name = "MagZ_Box";
            this.MagZ_Box.ReadOnly = true;
            this.MagZ_Box.Size = new System.Drawing.Size(100, 20);
            this.MagZ_Box.TabIndex = 15;
            // 
            // MagX_Box
            // 
            this.MagX_Box.Location = new System.Drawing.Point(169, 514);
            this.MagX_Box.Name = "MagX_Box";
            this.MagX_Box.ReadOnly = true;
            this.MagX_Box.Size = new System.Drawing.Size(100, 20);
            this.MagX_Box.TabIndex = 14;
            // 
            // chartAccX
            // 
            chartArea1.Name = "ChartArea1";
            this.chartAccX.ChartAreas.Add(chartArea1);
            this.chartAccX.Location = new System.Drawing.Point(27, 161);
            this.chartAccX.Name = "chartAccX";
            series1.BorderWidth = 3;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series1.Color = System.Drawing.Color.Red;
            series1.Name = "AccX";
            this.chartAccX.Series.Add(series1);
            this.chartAccX.Size = new System.Drawing.Size(323, 128);
            this.chartAccX.TabIndex = 17;
            this.chartAccX.Text = "chartAccX";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(24, 138);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 13);
            this.label1.TabIndex = 18;
            this.label1.Text = "Accelerometer Axis X";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(426, 138);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(127, 13);
            this.label2.TabIndex = 19;
            this.label2.Text = "Accelerometer Axis Y";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(777, 138);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 13);
            this.label3.TabIndex = 20;
            this.label3.Text = "Accelerometer Axis Z";
            // 
            // chartAccY
            // 
            chartArea2.Name = "ChartArea1";
            this.chartAccY.ChartAreas.Add(chartArea2);
            this.chartAccY.Location = new System.Drawing.Point(404, 161);
            this.chartAccY.Name = "chartAccY";
            series2.BorderWidth = 3;
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series2.Color = System.Drawing.Color.Red;
            series2.Name = "AccY";
            this.chartAccY.Series.Add(series2);
            this.chartAccY.Size = new System.Drawing.Size(323, 128);
            this.chartAccY.TabIndex = 21;
            this.chartAccY.Text = "chartAccY";
            // 
            // chartAccZ
            // 
            chartArea3.Name = "ChartArea1";
            this.chartAccZ.ChartAreas.Add(chartArea3);
            this.chartAccZ.Location = new System.Drawing.Point(780, 161);
            this.chartAccZ.Name = "chartAccZ";
            series3.BorderWidth = 3;
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series3.Color = System.Drawing.Color.Red;
            series3.Name = "AccZ";
            this.chartAccZ.Series.Add(series3);
            this.chartAccZ.Size = new System.Drawing.Size(323, 128);
            this.chartAccZ.TabIndex = 22;
            this.chartAccZ.Text = "chartAccZ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(24, 81);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 13);
            this.label4.TabIndex = 23;
            this.label4.Text = "Temperature C°";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(141, 81);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 13);
            this.label5.TabIndex = 24;
            this.label5.Text = "Pressure Pa";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(247, 81);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 13);
            this.label6.TabIndex = 25;
            this.label6.Text = "Humidity %";
            // 
            // chartGyrZ
            // 
            chartArea4.Name = "ChartArea1";
            this.chartGyrZ.ChartAreas.Add(chartArea4);
            this.chartGyrZ.Location = new System.Drawing.Point(780, 339);
            this.chartGyrZ.Name = "chartGyrZ";
            series4.BorderWidth = 3;
            series4.ChartArea = "ChartArea1";
            series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series4.Color = System.Drawing.Color.Green;
            series4.Name = "GyrZ";
            this.chartGyrZ.Series.Add(series4);
            this.chartGyrZ.Size = new System.Drawing.Size(323, 128);
            this.chartGyrZ.TabIndex = 31;
            this.chartGyrZ.Text = "chartGyrZ";
            // 
            // chartGyrY
            // 
            chartArea5.Name = "ChartArea1";
            this.chartGyrY.ChartAreas.Add(chartArea5);
            this.chartGyrY.Location = new System.Drawing.Point(404, 339);
            this.chartGyrY.Name = "chartGyrY";
            series5.BorderWidth = 3;
            series5.ChartArea = "ChartArea1";
            series5.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series5.Color = System.Drawing.Color.Green;
            series5.Name = "GyrY";
            this.chartGyrY.Series.Add(series5);
            this.chartGyrY.Size = new System.Drawing.Size(323, 128);
            this.chartGyrY.TabIndex = 30;
            this.chartGyrY.Text = "chartGyrY";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(777, 323);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(106, 13);
            this.label7.TabIndex = 29;
            this.label7.Text = "Gyroscope Axis Z";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(426, 323);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(106, 13);
            this.label8.TabIndex = 28;
            this.label8.Text = "Gyroscope Axis Y";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(24, 323);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(106, 13);
            this.label9.TabIndex = 27;
            this.label9.Text = "Gyroscope Axis X";
            // 
            // chartGyrX
            // 
            chartArea6.Name = "ChartArea1";
            this.chartGyrX.ChartAreas.Add(chartArea6);
            this.chartGyrX.Location = new System.Drawing.Point(27, 339);
            this.chartGyrX.Name = "chartGyrX";
            series6.BorderWidth = 3;
            series6.ChartArea = "ChartArea1";
            series6.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series6.Color = System.Drawing.Color.Green;
            series6.Name = "GyrX";
            this.chartGyrX.Series.Add(series6);
            this.chartGyrX.Size = new System.Drawing.Size(323, 128);
            this.chartGyrX.TabIndex = 26;
            this.chartGyrX.Text = "chartGyrX";
            // 
            // chartMagZ
            // 
            chartArea7.Name = "ChartArea1";
            this.chartMagZ.ChartAreas.Add(chartArea7);
            this.chartMagZ.Location = new System.Drawing.Point(780, 540);
            this.chartMagZ.Name = "chartMagZ";
            series7.BorderWidth = 3;
            series7.ChartArea = "ChartArea1";
            series7.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series7.Color = System.Drawing.Color.Blue;
            series7.Name = "MagZ";
            this.chartMagZ.Series.Add(series7);
            this.chartMagZ.Size = new System.Drawing.Size(323, 128);
            this.chartMagZ.TabIndex = 37;
            this.chartMagZ.Text = "chartMagZ";
            // 
            // chartMagY
            // 
            chartArea8.Name = "ChartArea1";
            this.chartMagY.ChartAreas.Add(chartArea8);
            this.chartMagY.Location = new System.Drawing.Point(404, 540);
            this.chartMagY.Name = "chartMagY";
            series8.BorderWidth = 3;
            series8.ChartArea = "ChartArea1";
            series8.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series8.Color = System.Drawing.Color.Blue;
            series8.Name = "MagY";
            this.chartMagY.Series.Add(series8);
            this.chartMagY.Size = new System.Drawing.Size(323, 128);
            this.chartMagY.TabIndex = 36;
            this.chartMagY.Text = "chartMagY";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(777, 517);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(126, 13);
            this.label10.TabIndex = 35;
            this.label10.Text = "Magnetometer Axis Z";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(426, 517);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(126, 13);
            this.label11.TabIndex = 34;
            this.label11.Text = "Magnetometer Axis Y";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(24, 517);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(126, 13);
            this.label12.TabIndex = 33;
            this.label12.Text = "Magnetometer Axis X";
            // 
            // chartMagX
            // 
            chartArea9.Name = "ChartArea1";
            this.chartMagX.ChartAreas.Add(chartArea9);
            this.chartMagX.Location = new System.Drawing.Point(27, 540);
            this.chartMagX.Name = "chartMagX";
            series9.BorderWidth = 3;
            series9.ChartArea = "ChartArea1";
            series9.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series9.Color = System.Drawing.Color.Blue;
            series9.Name = "MagX";
            this.chartMagX.Series.Add(series9);
            this.chartMagX.Size = new System.Drawing.Size(323, 128);
            this.chartMagX.TabIndex = 32;
            this.chartMagX.Text = "chartMagX";
            // 
            // pictureBox
            // 
            this.pictureBox.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox.Image")));
            this.pictureBox.Location = new System.Drawing.Point(861, 12);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(303, 94);
            this.pictureBox.TabIndex = 38;
            this.pictureBox.TabStop = false;
            // 
            // port_scanner
            // 
            this.port_scanner.Interval = 1000;
            this.port_scanner.Tick += new System.EventHandler(this.port_scanner_Tick);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1176, 729);
            this.Controls.Add(this.pictureBox);
            this.Controls.Add(this.chartMagZ);
            this.Controls.Add(this.chartMagY);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.chartMagX);
            this.Controls.Add(this.chartGyrZ);
            this.Controls.Add(this.chartGyrY);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.chartGyrX);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.chartAccZ);
            this.Controls.Add(this.chartAccY);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.chartAccX);
            this.Controls.Add(this.MagY_Box);
            this.Controls.Add(this.MagZ_Box);
            this.Controls.Add(this.MagX_Box);
            this.Controls.Add(this.GyrZ_Box);
            this.Controls.Add(this.GyrY_Box);
            this.Controls.Add(this.GyrX_Box);
            this.Controls.Add(this.AccZ_Box);
            this.Controls.Add(this.AccY_Box);
            this.Controls.Add(this.AccX_Box);
            this.Controls.Add(this.humidityBox);
            this.Controls.Add(this.pressureBox);
            this.Controls.Add(this.temperatureBox);
            this.Controls.Add(this.DebugOutputBox);
            this.Controls.Add(this.stop_button);
            this.Controls.Add(this.start_button);
            this.Controls.Add(this.ports_label);
            this.Controls.Add(this.PortSelectorBox);
            this.HelpButton = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.Text = "RUT2CLOUD Sensors Monitor";
            ((System.ComponentModel.ISupportInitialize)(this.chartAccX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartAccY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartAccZ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartGyrZ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartGyrY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartGyrX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartMagZ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartMagY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartMagX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox PortSelectorBox;
        private System.Windows.Forms.Label ports_label;
        private System.Windows.Forms.Button start_button;
        private System.Windows.Forms.Button stop_button;
        private System.IO.Ports.SerialPort serial;
        private System.Windows.Forms.TextBox DebugOutputBox;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.TextBox temperatureBox;
        private System.Windows.Forms.TextBox pressureBox;
        private System.Windows.Forms.TextBox humidityBox;
        private System.Windows.Forms.TextBox AccX_Box;
        private System.Windows.Forms.TextBox AccY_Box;
        private System.Windows.Forms.TextBox AccZ_Box;
        private System.Windows.Forms.TextBox GyrZ_Box;
        private System.Windows.Forms.TextBox GyrY_Box;
        private System.Windows.Forms.TextBox GyrX_Box;
        private System.Windows.Forms.TextBox MagY_Box;
        private System.Windows.Forms.TextBox MagZ_Box;
        private System.Windows.Forms.TextBox MagX_Box;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartAccX;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartAccY;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartAccZ;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartGyrZ;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartGyrY;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartGyrX;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartMagZ;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartMagY;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartMagX;
        private System.Windows.Forms.PictureBox pictureBox;
        private System.Windows.Forms.Timer port_scanner;
    }
}

