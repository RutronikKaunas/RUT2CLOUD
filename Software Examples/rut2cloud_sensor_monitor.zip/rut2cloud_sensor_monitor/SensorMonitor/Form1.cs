﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading;
using System.Timers;
using System.Diagnostics;

namespace SensorMonitor
{
    public partial class MainForm : Form
    {
        /*Array for sensors data*/
        byte[] raw_data = new byte[24];

        /*Storage for ports tracking*/
        static String[] ports_detected;

        /*Signed 32-bit integers for actual sensors data*/
        double temperature = 0;
        double humidity = 0;
        double pressure = 0;
        int accx = 0;
        int accy = 0;
        int accz = 0;
        int gyrx = 0;
        int gyry = 0;
        int gyrz = 0;
        int magx = 0;
        int magy = 0;
        int magz = 0;

        /*Temperature, pressure, humidity coefficients*/
        int coef_T1 = 0;
        int coef_T2 = 0;
        int coef_T3 = 0;
        int coef_P1 = 0;
        int coef_P2 = 0;
        int coef_P3 = 0;
        int coef_P4 = 0;
        int coef_P5 = 0;
        int coef_P6 = 0;
        int coef_P7 = 0;
        int coef_P8 = 0;
        int coef_P9 = 0;
        int coef_H1 = 0;
        int coef_H2 = 0;
        int coef_H3 = 0;
        int coef_H4 = 0;
        int coef_H5 = 0;
        int coef_H6 = 0;

        /*UART Settings*/
        int baudrate = 115200;
        int system_delay_ms = 5;

        public MainForm()
        {
            InitializeComponent();
            getPorts();
            stop_button.Enabled = false;
            port_scanner.Start();

            /*Accelerometer X Chart Initialization*/
            chartAccX.Series["AccX"].IsValueShownAsLabel = false;
            chartAccX.ChartAreas["ChartArea1"].AxisX.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartAccX.ChartAreas["ChartArea1"].AxisY.IsStartedFromZero = false;

            /*Accelerometer Y Chart Initialization*/
            chartAccY.Series["AccY"].IsValueShownAsLabel = false;
            chartAccY.ChartAreas["ChartArea1"].AxisX.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartAccY.ChartAreas["ChartArea1"].AxisY.IsStartedFromZero = false;

            /*Accelerometer X Chart Initialization*/
            chartAccZ.Series["AccZ"].IsValueShownAsLabel = false;
            chartAccZ.ChartAreas["ChartArea1"].AxisX.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartAccZ.ChartAreas["ChartArea1"].AxisY.IsStartedFromZero = false;

            /*Gyroscope X Chart Initialization*/
            chartGyrX.Series["GyrX"].IsValueShownAsLabel = false;
            chartGyrX.ChartAreas["ChartArea1"].AxisX.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartGyrX.ChartAreas["ChartArea1"].AxisY.IsStartedFromZero = false;

            /*Gyroscope Y Chart Initialization*/
            chartGyrY.Series["GyrY"].IsValueShownAsLabel = false;
            chartGyrY.ChartAreas["ChartArea1"].AxisX.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartGyrY.ChartAreas["ChartArea1"].AxisY.IsStartedFromZero = false;

            /*Gyroscope Z Chart Initialization*/
            chartGyrZ.Series["GyrZ"].IsValueShownAsLabel = false;
            chartGyrZ.ChartAreas["ChartArea1"].AxisX.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartGyrZ.ChartAreas["ChartArea1"].AxisY.IsStartedFromZero = false;

            /*Magnetometer X Chart Initialization*/
            chartMagX.Series["MagX"].IsValueShownAsLabel = false;
            chartMagX.ChartAreas["ChartArea1"].AxisX.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartMagX.ChartAreas["ChartArea1"].AxisY.IsStartedFromZero = false;

            /*Magnetometer Y Chart Initialization*/
            chartMagY.Series["MagY"].IsValueShownAsLabel = false;
            chartMagY.ChartAreas["ChartArea1"].AxisX.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartMagY.ChartAreas["ChartArea1"].AxisY.IsStartedFromZero = false;

            /*Magnetometer Z Chart Initialization*/
            chartMagZ.Series["MagZ"].IsValueShownAsLabel = false;
            chartMagZ.ChartAreas["ChartArea1"].AxisX.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartMagZ.ChartAreas["ChartArea1"].AxisY.IsStartedFromZero = false;
        }

        void getPorts()
        {
            String[] ports = SerialPort.GetPortNames();
            PortSelectorBox.Items.AddRange(ports);
        }

        void sensors_init()
        {
            /*Read the BME280 ID*/
            protocol_read(0xEE, 0xD0, raw_data, 1);
            if (raw_data[0] == 96)
            {
                /*Write the ID on the screen*/
                DebugOutputBox.AppendText("BME280 ID: ");
                DebugOutputBox.AppendText(Convert.ToString(raw_data[0]));
                DebugOutputBox.AppendText("\n");

                /*Reset the BME280*/
                raw_data[0] = 0xE0;
                raw_data[1] = 0xB6;
                protocol_write(0xEE, raw_data, 2);
                Thread.Sleep(100);

                /*Read 24 bytes of data from address 0x88*/
                protocol_read(0xEE, 0x88, raw_data, 24);

                /*Convert data*/
                /*Temperature coefficients*/
                coef_T1 = (raw_data[0] & 0xFF) + ((raw_data[1] & 0xFF) * 256);
                coef_T2 = (raw_data[2] & 0xFF) + ((raw_data[3] & 0xFF) * 256);
                if (coef_T2 > 32767)
                {
                    coef_T2 -= 65536;
                }
                coef_T3 = (raw_data[4] & 0xFF) + ((raw_data[5] & 0xFF) * 256);
                if (coef_T3 > 32767)
                {
                    coef_T3 -= 65536;
                }

                /* Pressure coefficients */
                coef_P1 = (raw_data[6] & 0xFF) + ((raw_data[7] & 0xFF) * 256);
                coef_P2 = (raw_data[8] & 0xFF) + ((raw_data[9] & 0xFF) * 256);
                if (coef_P2 > 32767)
                {
                    coef_P2 -= 65536;
                }
                coef_P3 = (raw_data[10] & 0xFF) + ((raw_data[11] & 0xFF) * 256);
                if (coef_P3 > 32767)
                {
                    coef_P3 -= 65536;
                }
                coef_P4 = (raw_data[12] & 0xFF) + ((raw_data[13] & 0xFF) * 256);
                if (coef_P4 > 32767)
                {
                    coef_P4 -= 65536;
                }
                coef_P5 = (raw_data[14] & 0xFF) + ((raw_data[15] & 0xFF) * 256);
                if (coef_P5 > 32767)
                {
                    coef_P5 -= 65536;
                }
                coef_P6 = (raw_data[16] & 0xFF) + ((raw_data[17] & 0xFF) * 256);
                if (coef_P6 > 32767)
                {
                    coef_P6 -= 65536;
                }
                coef_P7 = (raw_data[18] & 0xFF) + ((raw_data[19] & 0xFF) * 256);
                if (coef_P7 > 32767)
                {
                    coef_P7 -= 65536;
                }
                coef_P8 = (raw_data[20] & 0xFF) + ((raw_data[21] & 0xFF) * 256);
                if (coef_P8 > 32767)
                {
                    coef_P8 -= 65536;
                }
                coef_P9 = (raw_data[22] & 0xFF) + ((raw_data[23] & 0xFF) * 256);
                if (coef_P9 > 32767)
                {
                    coef_P9 -= 65536;
                }

                /*Read & Convert 1 byte of data from address 0xA1*/
                protocol_read(0xEE, 0xA1, raw_data, 1);
                coef_H1 = (raw_data[0] & 0xFF);

                /*Read 7 bytes of data from address 0xE1*/
                protocol_read(0xEE, 0xE1, raw_data, 7);


                /* Convert the data */
                /* Humidity coefficients */
                coef_H2 = (raw_data[0] & 0xFF) + (raw_data[1] * 256);
                if (coef_H2 > 32767)
                {
                    coef_H2 -= 65536;
                }
                coef_H3 = raw_data[2] & 0xFF;
                coef_H4 = ((raw_data[3] & 0xFF) * 16) + (raw_data[4] & 0xF);
                if (coef_H4 > 32767)
                {
                    coef_H4 -= 65536;
                }
                coef_H5 = ((raw_data[4] & 0xFF) / 16) + ((raw_data[5] & 0xFF) * 16);
                if (coef_H5 > 32767)
                {
                    coef_H5 -= 65536;
                }
                coef_H6 = raw_data[6] & 0xFF;
                if (coef_H6 > 127)
                {
                    coef_H6 -= 256;
                }

                /*BME280 Humidity oversampling x1*/
                raw_data[0] = 0xF2;
                raw_data[1] = 0x01;
                protocol_write(0xEE, raw_data, 2);

                /*BME280 Mode NORMAL, Pressure & Temperature oversampling x1*/
                raw_data[0] = 0xF4;
                raw_data[1] = 0x27;
                protocol_write(0xEE, raw_data, 2);

                /*BME280 Time standby 0.5 ms*/
                raw_data[0] = 0xF5;
                raw_data[1] = 0x00;
                protocol_write(0xEE, raw_data, 2);

                Thread.Sleep(300);
            }


            /*Read the BMX055 Accelerometer ID*/
            protocol_read(0x32, 0x00, raw_data, 1);
            if (raw_data[0] == 250)
            {
                DebugOutputBox.AppendText("BMX055 Accelerometer ID: ");
                DebugOutputBox.AppendText(Convert.ToString(raw_data[0]));
                DebugOutputBox.AppendText("\n");

                /*BMX055 Accel Reset*/
                raw_data[0] = 0x14;
                raw_data[1] = 0x00;
                protocol_write(0x32, raw_data, 2);
                Thread.Sleep(10);

                /*BMX055 Accel Set Range = +/- 2g*/
                raw_data[0] = 0x0F;
                raw_data[1] = 0x03;
                protocol_write(0x32, raw_data, 2);

                /*BMX055 Accel Set bandwidth = 1000 Hz*/
                raw_data[0] = 0x10;
                raw_data[1] = 0x0F;
                protocol_write(0x32, raw_data, 2);

                /*Normal mode, Sleep duration = 0.5ms*/
                raw_data[0] = 0x11;
                raw_data[1] = 0x00;
                protocol_write(0x32, raw_data, 2);

                Thread.Sleep(300);

            }


            /*Read the BMX055 Gyroscope ID*/
            protocol_read(0xD2, 0x00, raw_data, 1);
            if (raw_data[0] == 15)
            {
                DebugOutputBox.AppendText("BMX055 Gyroscope ID: ");
                DebugOutputBox.AppendText(Convert.ToString(raw_data[0]));
                DebugOutputBox.AppendText("\n");

                /*BMX055 Gyro Reset*/
                raw_data[0] = 0x14;
                raw_data[1] = 0x00;
                protocol_write(0xD2, raw_data, 2);
                Thread.Sleep(10);

                /*Full scale = +/- 125 degree*/
                raw_data[0] = 0x0F;
                raw_data[1] = 0x04;
                protocol_write(0xD2, raw_data, 2);

                /*Bandwidth ODR = 100 Hz*/
                raw_data[0] = 0x10;
                raw_data[1] = 0x07;
                protocol_write(0xD2, raw_data, 2);

                /*Normal mode, Sleep duration = 2ms*/
                raw_data[0] = 0x11;
                raw_data[1] = 0x00;
                protocol_write(0xD2, raw_data, 2);  

                Thread.Sleep(300);
            }

            /*Magnetometer Reset*/
            raw_data[0] = 0x4B;
            raw_data[1] = 0x83;
            protocol_write(0x26, raw_data, 2);
            Thread.Sleep(10);

            /*Read the BMX055 Magnetometer ID*/
            protocol_read(0x26, 0x40, raw_data, 1);
            if (raw_data[0] == 50)
            {
                DebugOutputBox.AppendText("BMX055 Magnetometer ID: ");
                DebugOutputBox.AppendText(Convert.ToString(raw_data[0]));
                DebugOutputBox.AppendText("\n");

                /*Normal Mode, ODR = 10 Hz*/
                raw_data[0] = 0x4C;
                raw_data[1] = 0x00;
                protocol_write(0x26, raw_data, 2);

                /*X, Y, Z-Axis enabled*/
                raw_data[0] = 0x4E;
                raw_data[1] = 0x84;
                protocol_write(0x26, raw_data, 2);

                /*No. of Repetitions for X-Y Axis = 9*/
                raw_data[0] = 0x51;
                raw_data[1] = 0x04;
                protocol_write(0x26, raw_data, 2);

                /*No. of Repetitions for Z-Axis = 15*/
                raw_data[0] = 0x52;
                raw_data[1] = 0x0F;
                protocol_write(0x26, raw_data, 2);

                Thread.Sleep(300);
            }

        }

        void sensors_deinit()
        {
            /*Reset the BME280*/
            raw_data[0] = 0xE0;
            raw_data[1] = 0xB6;
            protocol_write(0xEE, raw_data, 2);
            Thread.Sleep(10);

            /*BMX055 Accel Reset*/
            raw_data[0] = 0x14;
            raw_data[1] = 0x00;
            protocol_write(0x32, raw_data, 2);
            Thread.Sleep(10);

            /*BMX055 Gyro Reset*/
            raw_data[0] = 0x14;
            raw_data[1] = 0x00;
            protocol_write(0xD2, raw_data, 2);
            Thread.Sleep(10);

            /*Magnetometer Reset*/
            raw_data[0] = 0x4B;
            raw_data[1] = 0x83;
            protocol_write(0x26, raw_data, 2);
            Thread.Sleep(10);
        }

        void measurements()
        {
            /*Read BME280 measurements*/
            protocol_read(0xEE, 0xF7, raw_data, 8);

            /*Convert BME280 data*/
            long adc_p = (((long)(raw_data[0] & 0xFF) * 65536) + ((long)(raw_data[1] & 0xFF) * 256) + (long)(raw_data[2] & 0xF0)) / 16;
            long adc_t = (((long)(raw_data[3] & 0xFF) * 65536) + ((long)(raw_data[4] & 0xFF) * 256) + (long)(raw_data[5] & 0xF0)) / 16;
            long adc_h = ((long)(raw_data[6] & 0xFF) * 256 + (long)(raw_data[7] & 0xFF));

            /* Temperature offset calculations */
            double var1 = (((double)adc_t) / 16384.0 - ((double)coef_T1) / 1024.0) * ((double)coef_T2);
            double var2 = ((((double)adc_t) / 131072.0 - ((double)coef_T1) / 8192.0) *
                           (((double)adc_t) / 131072.0 - ((double)coef_T1) / 8192.0)) * ((double)coef_T3);
            double t_fine = (long)(var1 + var2);
            temperature = (var1 + var2) / 5120.0;

            /* Pressure offset calculations */
            var1 = ((double)t_fine / 2.0) - 64000.0;
            var2 = var1 * var1 * ((double)coef_P6) / 32768.0;
            var2 = var2 + var1 * ((double)coef_P5) * 2.0;
            var2 = (var2 / 4.0) + (((double)coef_P4) * 65536.0);
            var1 = (((double)coef_P3) * var1 * var1 / 524288.0 + ((double)coef_P2) * var1) / 524288.0;
            var1 = (1.0 + var1 / 32768.0) * ((double)coef_P1);
            double p = 1048576.0 - (double)adc_p;
            p = (p - (var2 / 4096.0)) * 6250.0 / var1;
            var1 = ((double)coef_P9) * p * p / 2147483648.0;
            var2 = p * ((double)coef_P8) / 32768.0;
            pressure = (p + (var1 + var2 + ((double)coef_P7)) / 16.0);

            /* Humidity offset calculations */
            double var_H = (((double)t_fine) - 76800.0);
            var_H = (adc_h - (coef_H4 * 64.0 + coef_H5 / 16384.0 * var_H)) * (coef_H2 / 65536.0 * (1.0 + coef_H6 / 67108864.0 * var_H * (1.0 + coef_H3 / 67108864.0 * var_H)));
            humidity = var_H * (1.0 - coef_H1 * var_H / 524288.0);
            if (humidity > 100.0)
            {
                humidity = 100.0;
            }
            else
                if (humidity < 0.0)
            {
                humidity = 0.0;
            }



            /*Read accelerometer measurements*/
            protocol_read(0x32, 0x02, raw_data, 6);

            /*Convert accelerometer data*/
            accx = ((raw_data[1] & 0xFF) * 256 + (raw_data[0] & 0xF0)) / 16;
            if (accx > 2047)
            {
                accx -= 4096;
            }
            accy = ((raw_data[3] & 0xFF) * 256 + (raw_data[2] & 0xF0)) / 16;
            if (accy > 2047)
            {
                accy -= 4096;
            }
            accz = ((raw_data[5] & 0xFF) * 256 + (raw_data[4] & 0xF0)) / 16;
            if (accz > 2047)
            {
                accz -= 4096;
            }

            /*Read gyroscope measurements*/
            protocol_read(0xD2, 0x02, raw_data, 6);

            /*Convert gyroscope data*/
            gyrx = ((raw_data[1] & 0xFF) * 256 + (raw_data[0] & 0xFF));
            if (gyrx > 32767)
            {
                gyrx -= 65536;
            }
            gyry = ((raw_data[3] & 0xFF) * 256 + (raw_data[2] & 0xFF));
            if (gyry > 32767)
            {
                gyry -= 65536;
            }
            gyrz = ((raw_data[5] & 0xFF) * 256 + (raw_data[4] & 0xFF));
            if (gyrz > 32767)
            {
                gyrz -= 65536;
            }

            /*Read magnetometer measurements*/
            protocol_read(0x26, 0x42, raw_data, 6);

            /*Convert magnetometer data*/
            magx = ((raw_data[1] & 0xFF) * 256 + (raw_data[0] & 0xF8)) / 8;
            if (magx > 4095)
            {
                magx -= 8192;
            }
            magy = ((raw_data[3] & 0xFF) * 256 + (raw_data[2] & 0xF8)) / 8;
            if (magy > 4095)
            {
                magy -= 8192;
            }
            magz = ((raw_data[5] & 0xFF) * 256 + (raw_data[4] & 0xFE)) / 2;
            if (magz > 16383)
            {
                magz -= 32768;
            }
        }

        public void protocol_write(byte address, byte[] buffer, Int32 count)
        {
            try
            {
                /*Write start character*/
                serial.BaseStream.WriteByte((byte)0x53);

                /*Write the device address*/
                serial.BaseStream.WriteByte((byte)address);

                /*Write the number of bytes to be sent*/
                serial.BaseStream.WriteByte((byte)(count));

                /*Write data*/
                serial.Write(buffer, 0, count);

                /*Write stop character*/
                serial.BaseStream.WriteByte((byte)0x50);
            }

            catch (TimeoutException)
            {
                DebugOutputBox.AppendText("Data send timeout\n");
            }
            catch (InvalidOperationException)
            {
                serial.Close();
                timer.Stop();
                start_button.Enabled = true;
                stop_button.Enabled = false;
                PortSelectorBox.Enabled = true;
                DebugOutputBox.Text = "Invalid operation\n";
            }
            catch (System.IO.IOException)
            {
                serial.Close();
                timer.Stop();
                start_button.Enabled = true;
                stop_button.Enabled = false;
                PortSelectorBox.Enabled = true;
                DebugOutputBox.Text = "Connection was lost\n";
            }
        }

        public void protocol_read(byte address, byte register, byte[] buffer, Int32 count)
        {
            byte read_address = 1;
            int wait_time = 0;

            try
            {
                /*Write start character*/
                serial.BaseStream.WriteByte((byte)0x53);

                /*Write the device address*/
                serial.BaseStream.WriteByte((byte)address);

                /*Write the number of bytes to be sent*/
                serial.BaseStream.WriteByte((byte)1);

                /*Write register*/
                serial.BaseStream.WriteByte((byte)register);

                /*Write stop character*/
                serial.BaseStream.WriteByte((byte)0x50);

                /*Write start character*/
                serial.BaseStream.WriteByte((byte)0x53);

                /*Write the device address for reading*/
                serial.BaseStream.WriteByte((byte)(address + read_address));

                /*Write the number of bytes to be read*/
                serial.BaseStream.WriteByte((byte)(count));

                /*Write stop character*/
                serial.BaseStream.WriteByte((byte)0x50);

                /*Wait for data to arrive*/
                wait_time = (int)(count * 8 * 1000 / baudrate);
                Thread.Sleep(wait_time + system_delay_ms);
            }

            catch (TimeoutException)
            {
                DebugOutputBox.AppendText("Data send timeout\n");
            }
            catch (InvalidOperationException)
            {
                serial.Close();
                timer.Stop();
                start_button.Enabled = true;
                stop_button.Enabled = false;
                PortSelectorBox.Enabled = true;
                DebugOutputBox.Text = "Invalid operation\n";
            }
            catch (System.IO.IOException)
            {
                serial.Close();
                timer.Stop();
                start_button.Enabled = true;
                stop_button.Enabled = false;
                PortSelectorBox.Enabled = true;
                DebugOutputBox.Text = "Connection was lost\n";
            }

            try
            {
                /*Read the data*/
                serial.Read(buffer, 0, count);
            }

            catch (TimeoutException)
            {
                DebugOutputBox.AppendText("Data receive timeout\n");
            }
            catch (InvalidOperationException)
            {
                serial.Close();
                timer.Stop();
                start_button.Enabled = true;
                stop_button.Enabled = false;
                PortSelectorBox.Enabled = true;
                DebugOutputBox.Text = "Invalid operation\n";
            }
            catch (System.IO.IOException)
            {
                serial.Close();
                timer.Stop();
                start_button.Enabled = true;
                stop_button.Enabled = false;
                PortSelectorBox.Enabled = true;
                DebugOutputBox.Text = "Connection was lost\n";
            }

        }

        private void start_button_Click(object sender, EventArgs e)
        {
            try
            {
                /*Check if COM Port selected*/
                if (PortSelectorBox.Text != "")
                {
                    serial.PortName = PortSelectorBox.Text;
                    serial.BaudRate = baudrate;
                    serial.Parity = Parity.None;
                    serial.StopBits = StopBits.One;
                    serial.DataBits = 8;
                    serial.Handshake = Handshake.None;
                    serial.RtsEnable = false;
                    serial.ReadTimeout = 100;
                    serial.WriteTimeout = 100;
                    serial.Open();
                    DebugOutputBox.Text = "Port opened\n";

                    /*Check if sensors are responding*/
                    /*Read the BME280 ID*/
                    protocol_read(0xEE, 0xD0, raw_data, 1);
                    if (raw_data[0] == 96)
                    {
                        /*Read the BMX055 Accelerometer ID*/
                        protocol_read(0x32, 0x00, raw_data, 1);
                        if (raw_data[0] == 250)
                        {
                            start_button.Enabled = false;
                            stop_button.Enabled = true;
                            PortSelectorBox.Enabled = false;
                            sensors_init();
                            timer.Start();
                        }
                        else
                        {
                            DebugOutputBox.AppendText("No response from BMX055\n");
                            serial.Close();
                            DebugOutputBox.AppendText("Port closed\n");
                        }
                    }

                    else
                    {
                        DebugOutputBox.AppendText("No response from BME280\n");
                        serial.Close();
                        DebugOutputBox.AppendText("Port closed\n");
                    }

                }
                else
                {
                    DebugOutputBox.Text = "Port not selected\n";
                }

            }
            catch (UnauthorizedAccessException)
            {
                DebugOutputBox.Text = "Could not open the port\n";
            }
            catch (System.IO.IOException)
            {
                serial.Close();
                timer.Stop();
                start_button.Enabled = true;
                stop_button.Enabled = false;
                PortSelectorBox.Enabled = true;
                DebugOutputBox.Text = "Could not open the port\n";
            }
        }

        private void stop_button_Click(object sender, EventArgs e)
        {
            timer.Stop();
            sensors_deinit();
            serial.Close();
            start_button.Enabled = true;
            stop_button.Enabled = false;
            PortSelectorBox.Enabled = true;
            DebugOutputBox.Text = "Port closed\n";
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            timer.Stop();
            measurements();

            temperatureBox.Text = Convert.ToString(Math.Round(temperature, 2));
            pressureBox.Text = Convert.ToString(Math.Round(pressure, 2));
            humidityBox.Text = Convert.ToString(Math.Round(humidity, 2));

            AccX_Box.Text = Convert.ToString(accx);
            AccY_Box.Text = Convert.ToString(accy);
            AccZ_Box.Text = Convert.ToString(accz);

            GyrX_Box.Text = Convert.ToString(gyrx);
            GyrY_Box.Text = Convert.ToString(gyry);
            GyrZ_Box.Text = Convert.ToString(gyrz);

            MagX_Box.Text = Convert.ToString(magx);
            MagY_Box.Text = Convert.ToString(magy);
            MagZ_Box.Text = Convert.ToString(magz);

            /* Accelerometer X Chart Draw*/
            if (chartAccX.IsHandleCreated)
            {
                chartAccX.ChartAreas["ChartArea1"].AxisY.Maximum = Double.NaN;
                chartAccX.ChartAreas["ChartArea1"].AxisY.Minimum = Double.NaN;
                chartAccX.ChartAreas[0].RecalculateAxesScale();

                chartAccX.Series["AccX"].Points.Add(accx);

                if (chartAccX.Series[0].Points.Count == 20)
                {
                    chartAccX.Series[0].Points.RemoveAt(0);
                }
            }

            /* Accelerometer Y Chart Draw*/
            if (chartAccY.IsHandleCreated)
            {
                chartAccY.ChartAreas["ChartArea1"].AxisY.Maximum = Double.NaN;
                chartAccY.ChartAreas["ChartArea1"].AxisY.Minimum = Double.NaN;
                chartAccY.ChartAreas[0].RecalculateAxesScale();

                chartAccY.Series["AccY"].Points.Add(accy);

                if (chartAccY.Series[0].Points.Count == 20)
                {
                    chartAccY.Series[0].Points.RemoveAt(0);
                }
            }

            /* Accelerometer Z Chart Draw*/
            if (chartAccZ.IsHandleCreated)
            {
                chartAccZ.ChartAreas["ChartArea1"].AxisY.Maximum = Double.NaN;
                chartAccZ.ChartAreas["ChartArea1"].AxisY.Minimum = Double.NaN;
                chartAccZ.ChartAreas[0].RecalculateAxesScale();

                chartAccZ.Series["AccZ"].Points.Add(accz);

                if (chartAccZ.Series[0].Points.Count == 20)
                {
                    chartAccZ.Series[0].Points.RemoveAt(0);
                }
            }

            /* Gyroscope X Chart Draw*/
            if (chartGyrX.IsHandleCreated)
            {
                chartGyrX.ChartAreas["ChartArea1"].AxisY.Maximum = Double.NaN;
                chartGyrX.ChartAreas["ChartArea1"].AxisY.Minimum = Double.NaN;
                chartGyrX.ChartAreas[0].RecalculateAxesScale();

                chartGyrX.Series["GyrX"].Points.Add(gyrx);

                if (chartGyrX.Series[0].Points.Count == 20)
                {
                    chartGyrX.Series[0].Points.RemoveAt(0);
                }
            }

            /* Gyroscope Y Chart Draw*/
            if (chartGyrY.IsHandleCreated)
            {
                chartGyrY.ChartAreas["ChartArea1"].AxisY.Maximum = Double.NaN;
                chartGyrY.ChartAreas["ChartArea1"].AxisY.Minimum = Double.NaN;
                chartGyrY.ChartAreas[0].RecalculateAxesScale();

                chartGyrY.Series["GyrY"].Points.Add(gyry);

                if (chartGyrY.Series[0].Points.Count == 20)
                {
                    chartGyrY.Series[0].Points.RemoveAt(0);
                }
            }

            /* Gyroscope Z Chart Draw*/
            if (chartGyrZ.IsHandleCreated)
            {
                chartGyrZ.ChartAreas["ChartArea1"].AxisY.Maximum = Double.NaN;
                chartGyrZ.ChartAreas["ChartArea1"].AxisY.Minimum = Double.NaN;
                chartGyrZ.ChartAreas[0].RecalculateAxesScale();

                chartGyrZ.Series["GyrZ"].Points.Add(gyrz);

                if (chartGyrZ.Series[0].Points.Count == 20)
                {
                    chartGyrZ.Series[0].Points.RemoveAt(0);
                }
            }

            /* Magnetometer X Chart Draw*/
            if (chartMagX.IsHandleCreated)
            {
                chartMagX.ChartAreas["ChartArea1"].AxisY.Maximum = Double.NaN;
                chartMagX.ChartAreas["ChartArea1"].AxisY.Minimum = Double.NaN;
                chartMagX.ChartAreas[0].RecalculateAxesScale();

                chartMagX.Series["MagX"].Points.Add(magx);

                if (chartMagX.Series[0].Points.Count == 20)
                {
                    chartMagX.Series[0].Points.RemoveAt(0);
                }
            }

            /* Magnetometer Y Chart Draw*/
            if (chartMagY.IsHandleCreated)
            {
                chartMagY.ChartAreas["ChartArea1"].AxisY.Maximum = Double.NaN;
                chartMagY.ChartAreas["ChartArea1"].AxisY.Minimum = Double.NaN;
                chartMagY.ChartAreas[0].RecalculateAxesScale();

                chartMagY.Series["MagY"].Points.Add(magy);

                if (chartMagY.Series[0].Points.Count == 20)
                {
                    chartMagY.Series[0].Points.RemoveAt(0);
                }
            }

            /* Magnetometer Z Chart Draw*/
            if (chartMagZ.IsHandleCreated)
            {
                chartMagZ.ChartAreas["ChartArea1"].AxisY.Maximum = Double.NaN;
                chartMagZ.ChartAreas["ChartArea1"].AxisY.Minimum = Double.NaN;
                chartMagZ.ChartAreas[0].RecalculateAxesScale();

                chartMagZ.Series["MagZ"].Points.Add(magz);

                if (chartMagZ.Series[0].Points.Count == 20)
                {
                    chartMagZ.Series[0].Points.RemoveAt(0);
                }
            }

            timer.Start();
        }

        private void port_scanner_Tick(object sender, EventArgs e)
        {
            String[] ports = SerialPort.GetPortNames();

            if (ports_detected == null)
            {
                ports_detected = (string[])ports.Clone();
            }

            if (ports != null)
            {
                if (!ports.SequenceEqual(ports_detected))
                {
                    ports_detected = (string[])ports.Clone();
                    PortSelectorBox.Items.Clear();
                    PortSelectorBox.Items.AddRange(ports_detected);
                }
            }
        }
    }
}
