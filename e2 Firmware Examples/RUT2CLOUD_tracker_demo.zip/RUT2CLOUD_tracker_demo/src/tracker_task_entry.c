#include "tracker_task.h"
#include "uart0_receive_thread.h"
#include "bme280.h"
#include "bmx055.h"
#include "math.h"
#include "util.h"
#include "common.h"
#include "user_rtc.h"
#include "config_s3a7.h"
#include "StringCommandParser.h"
#include "stdlib.h"
#include "stdio.h"
#include "sms_commands.h"

#define MAX_LONGITUDE               180
#define MAX_LATITUDE                90
#define TELIT_BATT_ADC_COEFF        0.281       /*"Telit ADC1" battery voltage divider ratio*/
#define SHUT_DOWN_VOLTAGE           3333        /*System shut down voltage mV for battery saving/protection*/
#define GNSS_NSAT                   5           /*GNSS satellites number threshold */
#define GNSS_SAT_WAIT               300         /*GNSS signal wait time in seconds*/
#define SMS_CMD                     4           /*SMS commands used*/
#define GNSS_OFF_LITMIT             1800        /*Longest time interval in seconds when GNSS module will not be shut down*/

const char google_link[] ="http://maps.google.com/maps?q=%s,%s";

/*SMS commands structure*/
typedef struct
 {
  char *Command;
  void (*OnExecute)( const char *pString );
 } tSMSproc;

/* LED type structure */
bsp_leds_t leds;

/*Modem and GNSS Power and Reset control pins*/
ioport_port_pin_t cell_reset = CELL_RESET_CTRL_PIN;
ioport_port_pin_t gnss_reset = GNSS_RESET_CTRL_PIN;
ioport_port_pin_t cell_pwr = CELL_POWER_CTRL_PIN;
ioport_port_pin_t gnss_pwr = GNSS_POWER_CTRL_PIN;
ioport_port_pin_t charger_ctrl = CHARGER_CTRL_PIN;

char g_sms_buff[100];
char incoming_number[20];
extern TSCPHandler   SCPHandler;
_Bool alarm_flag;
uint8_t sms_received = 0;

/*Modem data structure */
modem_data_storage_t modem_data;

/*Sensors data structure */
sensors_data_storage_t sensors_data;

/*Sensors coefficients storage*/
sensors_coefficients_t sensors_coeff;

/*Tracker settings storage*/
tracker_settings_t tracker_settings;

/*SMS commands structure initialisation*/
static const tSMSproc SMScomands[ SMS_CMD ] =
{
 {"normal", NormalModeConfig }, /*Command for entering normal mode. Always on, may send certain amount of SMS in intervals. Etc.: normal60t10 */
 {"rtc", RTCModeConfig },       /*Command for entering RTC mode. RTC timer is used to wake up from Standby mode. Sends SMS in intervals. Etc.: rtc300*/
 {"acc", ACCModeConfig },       /*Command for entering ACC mode. Accelerometer interrupt is used (P304 IRQ9). Sends SMS every time waken. Etc.: acc10*/
 {"memnum", MemNumConfig },     /*Command for memorising the SMS recipients number. Send SMS with memnum to memorise yours number */
};

/*Tick function for AT engine provided here*/
void g_modem_timer_callback(timer_callback_args_t * p_args)
{
    UNUSED(p_args);
    /*Execute AT parser tick function 10ms intervals*/
    SCP_Tick(10);
}

/*RTC Alarm interrupt*/
void rtc_alarm_callback(rtc_callback_args_t * p_args)
{
    UNUSED(p_args);

    /*Alarm event for intervals generation in normal mode*/
    alarm_flag = true;
}

/*Button interrupt IRQ0*/
void button_callback(external_irq_callback_args_t *p_args)
{
    UNUSED(p_args);
}

/*Accelerometer interrupt IRQ9*/
void accelerometer_callback(external_irq_callback_args_t *p_args)
{
    UNUSED(p_args);
}

/*Specific string copy function. Copies only digits and dots*/
static void strxcpy(char *dest, char *src)
{
    int limit;

    limit = 10;

    while(((*src >= '0') && (*src <= '9')) || (*src == '.') )
    {
        while(*src == ' ')
        {
            src++;
            limit--;

            if(limit <= 0)
            {
                break;
            }
        }

        *dest = *src;
        dest++;
        src++;
        limit--;

        if(limit <= 0)
        {
            break;
        }
    }
}

/*UART send function for AT commands parser*/
uint32_t uart_send_buff(uint8_t *data_out, uint32_t size)
{
    return g_sf_modem_uart0.p_api->write(g_sf_modem_uart0.p_ctrl, data_out, size, TX_WAIT_FOREVER);
}

/*UART receive function for AT commands parser*/
uint32_t uart_read_byte(uint8_t *pData)
{
    return g_sf_modem_uart0.p_api->read(g_sf_modem_uart0.p_ctrl, pData, 1, TX_WAIT_FOREVER);
}

/*Convert latitude and longitude from NMEA to decimal */
static double nmea2dec(char *nmea, char type, char *dir)
{
    unsigned int idx, dot = 0;
    double dec = 0;
    for (idx=0; idx<strlen(nmea);idx++){
        if (nmea[idx] == '.')
        {
            dot = idx;
            break;
        }
    }

    if ((dot < 3) || (dot > 5))
    {
        return 0;
    }

    int dd;
    double mm;
    char cdd[5], cmm[10];
    memset(cdd, 0, sizeof(cdd));
    memset(cmm, 0, sizeof(cmm));
    if(type == 1)
    {
        strncpy(cdd, nmea, dot-2);
        strncpy(cmm, nmea+dot-2, 7);
    }
    if(type == 2)
    {
        strncpy(cdd, nmea, dot-2);
        strncpy(cmm, nmea+dot-2, 7);
    }

    dd = atoi(cdd);
    mm = atof(cmm);

    dec = dd + (mm/60);

    if (type == 1 && dec > MAX_LATITUDE)
        return 0;
    else if (type == 2 && dec > MAX_LONGITUDE)
        return 0;

    if (*dir == 'N' || *dir == 'E')
      return dec;
    else
      return -1 * dec;
}

static inline void ModemReset(void)
{
    /*Turn on Reset MOSFET*/
    g_ioport.p_api->pinWrite(cell_reset, IOPORT_LEVEL_HIGH);

    /*Keep it on for a 200ms as required*/
    tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND/5));


    /*Turn off Reset MOSFET*/
    g_ioport.p_api->pinWrite(cell_reset, IOPORT_LEVEL_LOW);

    /*wait for a 1000ms as required*/
    tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND));
}

static inline void ModemOn(void)
{
    /*Turn on power for GSM Modem*/
    g_ioport.p_api->pinWrite(cell_pwr, IOPORT_LEVEL_HIGH);
}

static inline void ModemOff(void)
{
    /*Turn off power for GSM Modem*/
    g_ioport.p_api->pinWrite(cell_pwr, IOPORT_LEVEL_LOW);
}

static inline void GNSS_On(void)
{
    /*Turn on power for GNSS module*/
    g_ioport.p_api->pinWrite(gnss_pwr, IOPORT_LEVEL_HIGH);
}

static inline void GNSS_Off(void)
{
    /*Turn off power for GNSS module*/
    g_ioport.p_api->pinWrite(gnss_pwr, IOPORT_LEVEL_LOW);
}

static inline void Charger_On(void)
{
    /*Turn on Li-ion Battery Charger*/
    g_ioport.p_api->pinWrite(charger_ctrl, IOPORT_LEVEL_LOW);
}

static inline void Charger_Off(void)
{
    /*Turn off Li-ion Battery Charger*/
    g_ioport.p_api->pinWrite(charger_ctrl, IOPORT_LEVEL_HIGH);
}

static void GSM_init( void )
{
    /*Release reset pins*/
    g_ioport.p_api->pinWrite(cell_reset, IOPORT_LEVEL_LOW);
    g_ioport.p_api->pinWrite(gnss_reset, IOPORT_LEVEL_LOW);

    /*Reset the Modem*/
    ModemReset();

    /*Open and start hardware timer for AT parser ticks*/
    g_modem_timer.p_api->open(g_modem_timer.p_ctrl,g_modem_timer.p_cfg);
    g_modem_timer.p_api->start(g_modem_timer.p_ctrl);
}

static void GSM_deinit( void )
{
    /*Stop hardware timer for AT parser ticks*/
    g_modem_timer.p_api->stop(g_modem_timer.p_ctrl);
    g_modem_timer.p_api->close(g_modem_timer.p_ctrl);

    ModemOff();

    /*Shut Down GNSS module only if intervals are longer than GNSS_OFF_LITMIT*/
    if(tracker_settings.RTC_interval > GNSS_OFF_LITMIT)
    {
        GNSS_Off();
    }
}

/*Low power module callback*/
void lpm_callback(sf_power_profiles_v2_callback_args_t *p_args)
{
    /*Prepare to go to Low Power Mode*/
    if(p_args->event == SF_POWER_PROFILES_V2_EVENT_PRE_LOW_POWER)
    {
        g_ioport.p_api->pinWrite(leds.p_leds[0], IOPORT_LEVEL_HIGH);
        GSM_deinit();
        modem_data.gsm_pwr_status = false;
        modem_data.gnss_pwr_status = false;
        /*Do not suspend BMX055 in movement detection mode*/
        if(tracker_settings.mode != POWER_SAVING_ACC)
        {
            bmx055_deinit();
        }
        bme280_deinit();
    }

    /*Returning from Low Power Mode*/
    if(p_args->event == SF_POWER_PROFILES_V2_EVENT_POST_LOW_POWER)
    {
        /*Close Low Power Module Framework*/
        //(void) g_sf_power_profiles_v2_common.p_api->close(g_sf_power_profiles_v2_common.p_ctrl);
    }
}

/*Incoming Call Function*/
static void IncomingCall(const char *pString)
{
    UNUSED(pString);
    char *result = NULL;

    /* Wait 50ms */
    tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND/20));

      /**/
      result = strstr((char*)SCPHandler.RxBuffer, "+CLIP: ");
      /*Response found, lets look for operator string, begins with (") */
      if(result)
      {
          result = strchr(result, '"');

          /*Copy operator to the RAM and return*/
          if(result)
          {
              /*Prepare to save the callers number*/
              memset(tracker_settings.phone_number, 0x00, sizeof(tracker_settings.phone_number));

              /*Save callers number*/
              for(uint8_t i = 0; i < sizeof(tracker_settings.phone_number); i++)
              {
                  tracker_settings.phone_number[i] = *result;
                  result++;

                  /*Last operator char?*/
                  if(*result == '"')
                  {
                      i++;
                      tracker_settings.phone_number[i] = *result;
                      break;
                  }
              }
          }
      }

      /*Hang up*/
      result = SCP_SendCommandWaitAnswer("ATH\r", "OK", 2000, 1);

      if(result)
      {
          /*Save the number with whole structure to Data flash*/
          TrackerSettingsSave();
      }
}

/*Incoming SMS Function*/
static void IncomingSMS(const char *pString)
{
    UNUSED(pString);

    /*Increase SMS counter*/
    sms_received++;
}

/*Returns network registration status*/
static int32_t NetworkRegistrationCheck(void)
{
    char *result = NULL;
    int32_t ntwrk_stat = 0;

    /*Request network status info*/
    result = SCP_SendCommandWaitAnswer("AT+CREG?\r", "OK", 2000, 1);

    if(result)
    {
        result = NULL;
        result = strstr((char*)SCPHandler.RxBuffer, "+CREG: ");
        if(result)
        {
            result += 9;
            ntwrk_stat = atoi(result);
        }
    }
    else
    {
        return 0;
    }

    return ntwrk_stat;
}

/*Waits for network available, suspends actual task*/
static _Bool WaitForNetwork(void)
{
    int32_t test = 0;

    /*Wait 5 minutes for network*/
    for(int i = 300; i > 0; i--)
    {
        /*Get current network state*/
        test = NetworkRegistrationCheck();

        /*registered, home network  or  registered, roaming is acceptable*/
        if((test == 1) || (test == 5))
        {
            return true;
        }

        else
        {
            /* Wait 1000ms */
            tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND));
        }
    }

    return false;
}

/*Returns ADC1 battery voltage*/
static int32_t MeasureBattVoltage(void)
{
    int32_t voltage_mv = 0;
    char *result = NULL;

    /*Request ADC1*/
    result = SCP_SendCommandWaitAnswer("AT#ADC=1,2\r", "OK", 5000, 1);

    if(result)
    {
        result = NULL;
        result = strstr((char*)SCPHandler.RxBuffer, "#ADC:");
        if(result)
        {
            result += 6;
            voltage_mv = atoi(result);
            voltage_mv = (int32_t)(voltage_mv/TELIT_BATT_ADC_COEFF);
        }
    }
    else
    {
        return 0;
    }

    return voltage_mv;
}

/*Returns pointer to IMEI string of 15 numbers*/
static char* GetIMEI(void)
{
    char *result = NULL;
    static char imei[16];
    _Bool isDigit = false;
    uint32_t j = 0, i=0;

    /*Request IMEI*/
    result = SCP_SendCommandWaitAnswer("AT+CGSN\r", "OK", 100, 1);

    /*We have response, lets look for the info in the receiver buffer*/
    if(result)
    {
        result = NULL;

        /*Lets look for a ASCII number...*/
        while((j < strlen((char*)SCPHandler.RxBuffer)) && (!isDigit))
        {
          if((SCPHandler.RxBuffer[j] > 47) && (SCPHandler.RxBuffer[j] < 58))
          {
              isDigit = true;
              result = (char*)&SCPHandler.RxBuffer[j];
              break;
          }

          j++;
        }

        /*First number of IMEI found, copy the number to the RAM and return */
        if(result)
        {
            memset(imei, 0x00, 16);

            /*Maximum 15 chars for IMEI is allowed*/
            for(i = 0; i < 15; i++)
            {
                /*Not a number in IMEI shall be treated as error*/
                if(!(*result > 47 && *result < 58))
                {
                    return NULL;
                }

                imei[i] = *result;

                result++;
            }

            return imei;
        }
    }

    return NULL;
}

/*Request model identification*/
static char* GetID(void)
{
    char *result = NULL;
    static char device_id[21];

    /*Request model identification*/
    result = SCP_SendCommandWaitAnswer("AT#CGMM\r", "OK", 100, 1);

    /*We have response, lets look for the info in the receiver buffer*/
    if(result)
    {
        result = NULL;
        result = strstr((char*)SCPHandler.RxBuffer, "#CGMM: ");

        if(result)
        {
            result += 7;

            /*Copy operator to the RAM and return*/
            memset(device_id, 0x00, 21);

            /*Maximum 20 chars for model identification allowed*/
            for(uint8_t i = 0; i < 20; i++)
            {
                device_id[i] = *result;
                result++;

                /*Device_id end*/
                if(*result == '\r')
                {
                    return device_id;
                }
            }
        }

    }

    return NULL;
}

/*Returns pointer to firmware version*/
static char* GetVersion(void)
{
    char *result = NULL;
    static char version[16];
    uint32_t i=0;

    /*Request IMEI*/
    result = SCP_SendCommandWaitAnswer("AT+CGMR\r", "OK", 100, 1);

    /*We have response, lets look for the info in the receiver buffer*/
    if(result)
    {
        result = NULL;

        /*Lets look for a (\n) char as the begining of firmware version string*/
        result = strchr((char*)SCPHandler.RxBuffer, '\n');

        /*Copy string to RAM */
        if(result)
        {
            result++;
            memset(version, 0x00, 16);

            /*Maximum 15 chars limit*/
            for(i = 0; i < 15; i++)
            {

                version[i] = *result;
                result++;

                if(*result == '\r')
                {
                    break;
                }
            }

            return version;
        }
    }

    return NULL;
}

/*Writes firmware version to given pointer, must have 50 bytes allocated*/
static _Bool GetGPSVersion(char *version)
{
    char *result = NULL;
    char *temp = NULL;

    temp = version;

    /*Request GPS module firmware version*/
    result = SCP_SendCommandWaitAnswer("AT$GPSSW\r", "OK", 30000, 1);

    if(result)
    {
        result = NULL;
        result = strstr((char*)SCPHandler.RxBuffer, "$GPSSW: ");
        result += 8;
        if(result)
        {
            memset(version, 0x00, 50);

            /*Maximum 49 chars for firmware version*/
            for(uint8_t i = 0; i < 49; i++)
            {
                *temp = *result;
                result++;
                temp++;

                /*The end of the string*/
                if(*result == '\r')
                {
                    break;
                }
            }

            return true;
        }
    }

    return false;
}

/*Read GPS properties*/
static _Bool GetGPSLocation( char *utc, char *date, char *lat, char *lon, char *alt, char *hdop, char *cog, char *speed, char *nsat)
{
    char *result = NULL;
    char *dir = NULL;
    double coordinate = 0;

    /*Request GPS data*/
    result = SCP_SendCommandWaitAnswer("AT$GPSACP\r", "OK", 2000, 1);

    /*We have response, lets look for the info in the receiver buffer*/
    if(result)
    {
        result = NULL;
        result = strstr((char*)SCPHandler.RxBuffer, "$GPSACP: ");
        result +=9;
        if(result)
        {
            strxcpy(utc, result);
            result = strchr(result, ',');
            result++;
            if(result)
            {
                dir = strchr(result, 'N');
                if(!dir)
                {
                    dir = strchr(result, 'S');
                }
                coordinate = nmea2dec(result, 1, dir);
                sprintf(lat, "%.6f", coordinate);
                result = strchr(result, ',');
                result++;
                if(result)
                {
                    dir = strchr(result, 'E');
                    if(!dir)
                    {
                        dir = strchr(result, 'W');
                    }
                    coordinate = nmea2dec(result, 2, dir);
                    sprintf(lon, "%.6f", coordinate);
                    result = strchr(result, ',');
                    result++;
                    if(result)
                    {
                        strxcpy(hdop, result);
                        result = strchr(result, ',');
                        result++;
                        if(result)
                        {
                            strxcpy(alt, result);
                            result = strchr(result, ',');
                            result++;
                            result = strchr(result, ',');
                            result++;
                            if(result)
                            {
                                strxcpy(cog, result);
                                result = strchr(result, ',');
                                result++;
                                if(result)
                                {
                                    strxcpy(speed, result);
                                    result = strchr(result, ',');
                                    result++;
                                    result = strchr(result, ',');
                                    result++;
                                    if(result)
                                    {
                                        strxcpy(date, result);
                                        result = strchr(result, ',');
                                        result++;
                                        if(result)
                                        {
                                            strxcpy(nsat, result);
                                        }

                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    return false;
}

static void read_gnss(void)
{
    /*Clean temporary and global GNSS data storages*/
    char temp_utc[16];
    char temp_dat[16];
    char temp_lat[16];
    char temp_lon[16];
    char temp_alt[16];
    char temp_pre[16];
    char temp_cou[16];
    char temp_spe[16];
    char temp_nsa[16];
    memset(temp_utc,0x00,sizeof(temp_utc));
    memset(temp_dat,0x00,sizeof(temp_dat));
    memset(temp_lat,0x00,sizeof(temp_lat));
    memset(temp_lon,0x00,sizeof(temp_lon));
    memset(temp_alt,0x00,sizeof(temp_alt));
    memset(temp_pre,0x00,sizeof(temp_pre));
    memset(temp_cou,0x00,sizeof(temp_cou));
    memset(temp_spe,0x00,sizeof(temp_spe));
    memset(temp_nsa,0x00,sizeof(temp_nsa));
    memset(modem_data.gps_utc,0x00,sizeof(modem_data.gps_utc));
    memset(modem_data.gps_date,0x00,sizeof(modem_data.gps_date));
    memset(modem_data.gps_latitude,0x00,sizeof(modem_data.gps_latitude));
    memset(modem_data.gps_longitude,0x00,sizeof(modem_data.gps_longitude));
    memset(modem_data.gps_altitude,0x00,sizeof(modem_data.gps_altitude));
    memset(modem_data.gps_precision,0x00,sizeof(modem_data.gps_precision));
    memset(modem_data.gps_course,0x00,sizeof(modem_data.gps_course));
    memset(modem_data.gps_speed,0x00,sizeof(modem_data.gps_speed));
    memset(modem_data.gps_satt_in_use,0x00,sizeof(modem_data.gps_satt_in_use));

    /*Read GNSS data*/
    modem_data.gnss_online = GetGPSLocation(temp_utc,temp_dat,temp_lat,temp_lon,temp_alt,temp_pre,temp_cou,temp_spe,temp_nsa);

    /*Save data to RAM*/
    strcpy(modem_data.gps_utc, temp_utc);
    strcpy(modem_data.gps_date, temp_dat);
    strcpy(modem_data.gps_latitude, temp_lat);
    strcpy(modem_data.gps_longitude, temp_lon);
    strcpy(modem_data.gps_altitude, temp_alt);
    strcpy(modem_data.gps_precision, temp_pre);
    strcpy(modem_data.gps_course, temp_cou);
    strcpy(modem_data.gps_speed, temp_spe);
    strcpy(modem_data.gps_satt_in_use, temp_nsa);
}

static void sms_parser(void)
{
    char *result = NULL;
    int i;

    if(sms_received != 0)
    {
        /*Read all messages*/
        result = SCP_SendCommandWaitAnswer("AT+CMGL=\"ALL\"\r", "OK", 5000, 1);
        if(result)
        {
            /*Search for declared SMS command and execute it*/
            for (i=0; i<SMS_CMD; i++)
             {
                result = NULL;
                result = strstr( (char*)SCPHandler.RxBuffer, SMScomands[i].Command );
                if ((result) && (SMScomands[i].OnExecute))
                {
                    SMScomands[i].OnExecute( result );
                }
             }
        }

        /*Must wait 5000ms*/
        tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND*5));

        /*Delete all stored messages*/
        SCP_SendCommandWaitAnswer("AT+CMGD=1,4\r", "OK", 5000, 1);
        sms_received = 0;
    }
}


static void send_sms(void)
{
    char local_buff[50];

    if(atoi(modem_data.gps_satt_in_use) >= 5)
    {

        memset(g_sms_buff, 0x00, sizeof(g_sms_buff));
        memset(local_buff, 0x00, sizeof(local_buff));

        sprintf(g_sms_buff, google_link, modem_data.gps_latitude, modem_data.gps_longitude);

        /*Termination symbol*/
        strcat(g_sms_buff, "\032");

        sprintf(local_buff, "AT+CMGS=%s\r", tracker_settings.phone_number);
        SCP_SendDoubleCommandWaitAnswer(local_buff, g_sms_buff, ">", "OK", 2000, 1);
    }

    /*Wait 5000ms for modem to finish send SMS*/
    tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND*5));

    memset(g_sms_buff, 0x00, sizeof(g_sms_buff));
    memset(local_buff, 0x00, sizeof(local_buff));

    if(atoi(modem_data.gps_satt_in_use) <= 4)
    {
        strcat(g_sms_buff, "No Satellites ");
    }

    else
    {
        strcat(g_sms_buff, modem_data.gps_latitude);
        strcat(g_sms_buff, ", ");
        strcat(g_sms_buff, modem_data.gps_longitude);
        strcat(g_sms_buff, ", ");
        strcat(g_sms_buff, modem_data.gps_altitude);
        strcat(g_sms_buff, "m ");
        strcat(g_sms_buff, modem_data.gps_speed);
        strcat(g_sms_buff, "km/h ");
    }

    memset(local_buff, 0x00, sizeof(local_buff));
    sprintf(local_buff, "%.2f", sensors_data.bme280_temperature);
    strcat(local_buff, "C, ");
    strcat(g_sms_buff, local_buff);

    memset(local_buff, 0x00, sizeof(local_buff));
    sprintf(local_buff, "%.2f", sensors_data.bme280_pressure);
    strcat(local_buff, "kPa, ");
    strcat(g_sms_buff, local_buff);

    memset(local_buff, 0x00, sizeof(local_buff));
    sprintf(local_buff, "%.2f", sensors_data.bme280_humidity);
    strcat(local_buff, "% ");
    strcat(g_sms_buff, local_buff);

    memset(local_buff, 0x00, sizeof(local_buff));
    sprintf(local_buff, "%d", (int)modem_data.batt_voltage_mv);
    strcat(local_buff, "mV");
    strcat(g_sms_buff, local_buff);

    /*Termination symbol*/
    strcat(g_sms_buff, "\032");

    sprintf(local_buff, "AT+CMGS=%s\r", tracker_settings.phone_number);
    SCP_SendDoubleCommandWaitAnswer(local_buff, g_sms_buff, ">", "OK", 2000, 1);
}

static void battery_critical_shut_down(void)
{
    g_rtc0.p_api->close(g_rtc0.p_ctrl);
    g_external_irq9.p_api->close(g_external_irq9.p_ctrl);
    if(tracker_settings.mode == POWER_SAVING_ACC)
    {bmx055_deinit();}
    /*Enter Low Power Mode*/
     (void) g_sf_power_profiles_v2_common.p_api->lowPowerApply(g_sf_power_profiles_v2_common.p_ctrl, &g_sf_power_profiles_v2_low_power_0); /*Enter low power mode*/
}

static void low_level_init(void)
{
    ssp_err_t err;
    uint32_t crc_result;

    /* Initialise the LED */
    err = R_BSP_LedsGet(&leds);
    if(err) { APP_ERR_TRAP(err); }

    /*Hardware CRC Engine open*/
    err =  g_crc.p_api->open(g_crc.p_ctrl, g_crc.p_cfg);
    if(err) { APP_ERR_TRAP(err); }

    /* Data flash memory initialisations*/
    if(OpenDriver())
    {
        /*Read whole structure from DATA memory to RAM*/
        err = ReadSettings( &tracker_settings, sizeof(tracker_settings) );
        if(!err)
        {
            /*Check its CRC, exclude last for bytes from calculation*/
            err =  g_crc.p_api->calculate(g_crc.p_ctrl, &tracker_settings, sizeof(tracker_settings)-4, CRC_SEED, &crc_result);
            if(err) { APP_ERR_TRAP(err); }

            /*Initialise all default settings if CRC does not match (most likely MCU memory is fresh)*/
            if(crc_result != tracker_settings.CRC_data)
            {
                tracker_settings.mode = DEFAULT_MODE;
                tracker_settings.interval = 0;
                tracker_settings.repeat = 0;
                tracker_settings.RTC_interval = 3600;
                tracker_settings.ACC_threshold = 5;
                memset(tracker_settings.phone_number, 0x00, sizeof(tracker_settings.phone_number));

                /*Calculate new CRC*/
                err =  g_crc.p_api->calculate(g_crc.p_ctrl, &tracker_settings, sizeof(tracker_settings)-4, CRC_SEED, &crc_result);
                if(err) { APP_ERR_TRAP(err); }if(err) { APP_ERR_TRAP(err); }
                tracker_settings.CRC_data = crc_result;

                /*Write to Data flash */
                err = WriteSettings( &tracker_settings, sizeof(tracker_settings));
                if(err) { APP_ERR_TRAP(err); }
            }

            /*Default settings*/
            tracker_settings.interval = 0;
            tracker_settings.repeat = 0;
        }

        else /*Memory read error, initialise with defaults and may try to proceed*/
        {
            tracker_settings.mode = DEFAULT_MODE;
            tracker_settings.interval = 0;
            tracker_settings.repeat = 0;
            tracker_settings.RTC_interval = 3600;
            tracker_settings.ACC_threshold = 5;
            memset(tracker_settings.phone_number, 0x00, sizeof(tracker_settings.phone_number));
            tracker_settings.CRC_data = 0;
        }
    }
    else /*error*/
    {
        if(err) { APP_ERR_TRAP(err); }
    }

    /*Hardware CRC Engine close*/
    (void)g_crc.p_api->close(g_crc.p_ctrl);

    /*Flash driver close*/
    CloseDriver();

    /*Button IRQ0 interrupt*/
    err =  g_external_irq0.p_api->open(g_external_irq0.p_ctrl, g_external_irq0.p_cfg);
    if(err) { APP_ERR_TRAP(err); }

    /*RTC*/
    err = g_rtc0.p_api->open(g_rtc0.p_ctrl, g_rtc0.p_cfg);
    if(err) { APP_ERR_TRAP(err); }
    user_function_set_rtc_time();

    /*Accelerometer IRQ9 interrupt*/
    if(tracker_settings.mode == POWER_SAVING_ACC)
    {
        err =  g_external_irq9.p_api->open(g_external_irq9.p_ctrl, g_external_irq9.p_cfg);
        if(err) { APP_ERR_TRAP(err); }
    }

    /*Select Run Profile*/
    err = g_sf_power_profiles_v2_common.p_api->runApply(g_sf_power_profiles_v2_common.p_ctrl, &g_sf_power_profiles_v2_run_0);
    if(err) { APP_ERR_TRAP(err); }
}

static void system_startup(void)
{
    _Bool bme280_init_status = false;
    _Bool bmx055_init_status = false;

    _Bool temp_result = false;
    _Bool init_OK = false;
    char * scp_result = NULL;
    int32_t voltage = 0;

    /*LED blink for power on indication*/
    g_ioport.p_api->pinWrite(leds.p_leds[0], IOPORT_LEVEL_LOW);
    tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND/2));
    g_ioport.p_api->pinWrite(leds.p_leds[0], IOPORT_LEVEL_HIGH);

    /*Initialise GL865 V3.1 Modem and sensors*/
    modem_start:

    /*Initialise BME280 Sensors*/
    bme280_init_status = bme280_init();
    if(!bme280_init_status) { APP_ERR_TRAP(bme280_init_status); }

    /*Initialise Accelerometer. Gyroscope and Magnetometer are put to deep suspend modes*/
    bmx055_init_status = bmx055_init();
    if(!bmx055_init_status) { APP_ERR_TRAP(bmx055_init_status); }

    /*Restart uart_comms framework*/
    (void)g_sf_modem_uart0.p_api->close(g_sf_modem_uart0.p_ctrl);
    (void)g_sf_modem_uart0.p_api->open(g_sf_modem_uart0.p_ctrl, g_sf_modem_uart0.p_cfg);

    /*Apply power for GSM and GNSS modules*/
    ModemOn();
    GNSS_On();
    Charger_On();
    modem_data.gsm_pwr_status = true;
    modem_data.gnss_pwr_status = true;
    modem_data.charger_pwr_status = true;
    /*GSM and GNSS initialisation*/
    GSM_init();
    /*AT parser initialisation*/
    SCP_Init(uart_send_buff, uart_read_byte);
    /*AT CaLlbacks Register*/
    SCP_AddCallback("+CLIP:", IncomingCall);
    SCP_AddCallback("+CMTI:", IncomingSMS);
    /*Wait 1000ms for modem to be ready*/
    tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND));
    /*Try AT command*/
    scp_result = SCP_SendCommandWaitAnswer("AT\r\n", "OK", 2000, 1);
    /*Echo commands turn off*/
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("ATE0\r\n", "OK", 2000, 1);
    /*Wait 5000ms for ADC to be ready*/
    tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND*5));
    /*Set provider to default*/
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("AT+COPS=0\r\n", "OK", 60000, 1);
    /*eSIM card removed and switched to Nano SIM card */
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("AT#SIMDET=0\r", "OK", 2000, 1);
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("AT#GPIO=4,1,1\r", "OK", 2000, 1);
    /*Wait 1000ms for modem to be ready*/
    tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND));
    /*Nano SIM card present*/
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("AT#SIMDET=1\r", "OK", 2000, 1);
    /*Wait 5000ms for modem to be ready*/
    tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND*5));
    if(scp_result)
    {
        /*Get IMEI*/
        scp_result = NULL;
        scp_result = GetIMEI();
        if(scp_result)
        {
            memset(modem_data.imei, 0x00, 16);
            strcpy(modem_data.imei, scp_result);
        }

        /*Get module type*/
        scp_result = NULL;
        scp_result = GetID();
        if(scp_result)
        {
            memset(modem_data.device_name, 0x00, 21);
            strcpy(modem_data.device_name, scp_result);
        }

        /*Get firmware version*/
        scp_result = NULL;
        scp_result = GetVersion();
        if(scp_result)
        {
            memset(modem_data.fw_version, 0x00, 16);
            strcpy(modem_data.fw_version, scp_result);
        }
    }

    /*Message format = text mode*/
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("AT+CMGF=1\r", "OK", 2000, 1);
    /*Select how the new received message event is notified by the DCE to the DTE.*/
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("AT+CNMI=1,1,0,0,0\r", "OK", 2000, 1);
    /*Wait 1000ms for modem to be ready*/
    tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND));
    /*Enable error report*/
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("AT+CMEE=2\r", "OK", 2000, 1);
    /*Enable the extended call type format reporting*/
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("AT+CRC=1\r", "OK", 2000, 1);
    /*Enable the caller number identification.*/
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("AT+CLIP=1\r", "OK", 2000, 1);
    /*CPU Clock Mode.*/
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("AT#CPUMODE=6\r", "OK", 2000, 1);

    /*Battery critical shut down*/
    voltage = MeasureBattVoltage();
    if(voltage <= SHUT_DOWN_VOLTAGE)
    {
        battery_critical_shut_down();
    }

    /*GSM network and GNSS module status*/
    if (scp_result)
    {
        /*Wait for GSM network, 5 minutes at most*/
        temp_result = WaitForNetwork();

        /*We are registered to the network now*/
        if(temp_result)
        {
            temp_result = false;

            /*Try to get GNSS software version*/
            for(int i = 10; i > 0; i--)
            {
                /*Get GPS firmware version*/
                temp_result = GetGPSVersion(modem_data.gps_sw_version);
                tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND/2));
            }

            /*Indicate system status*/
            if(temp_result)
            {
                init_OK = true;
                g_ioport.p_api->pinWrite(leds.p_leds[0], IOPORT_LEVEL_LOW);
            }
            else
            {
                init_OK = false;
                g_ioport.p_api->pinWrite(leds.p_leds[0], IOPORT_LEVEL_HIGH);
            }
        }
        else
        {
            init_OK = false;
            g_ioport.p_api->pinWrite(leds.p_leds[0], IOPORT_LEVEL_HIGH);
        }
    }

    /*Initialisation failure*/
    if(!init_OK)
    {
        /*Turn off everything*/
        g_ioport.p_api->pinWrite(leds.p_leds[0], IOPORT_LEVEL_HIGH);
        GSM_deinit();
        modem_data.gsm_pwr_status = false;
        modem_data.gnss_pwr_status = false;
        bmx055_deinit();
        bme280_deinit();
        /*Enter Low Power Mode*/
        (void) g_sf_power_profiles_v2_common.p_api->lowPowerApply(g_sf_power_profiles_v2_common.p_ctrl, &g_sf_power_profiles_v2_low_power_0); /*Enter low power mode*/

        /*Restart on wake up*/
        goto modem_start;
    }
}

/* Tracker Task entry function */
void tracker_task_entry(void)
{
    uint32_t i;
    ssp_err_t err;

    /*Initialise hardware that will retain configuration in low power mode*/
    low_level_init();

    while (1)
    {
        /*Setup Telit modem and BOSH sensors always on wake up or startup*/
        system_startup();

        /*Initial alarm state is true*/
        alarm_flag = true;

        mode_select:

        /*Select operation mode*/
        switch (tracker_settings.mode)
        {

            /*Normal Mode*/
            case POWER_SAVING_OFF:
            {
                while(tracker_settings.mode == POWER_SAVING_OFF)
                {
                    /*Look for URC (Unsolicited Result Code)*/
                   SCP_Process();

                    /* Read/Parse messages */
                    sms_parser();

                    /*Break if operational mode has changed*/
                    if(tracker_settings.mode != POWER_SAVING_OFF)
                    {
                        /*Accelerometer IRQ9 interrupt*/
                        if(tracker_settings.mode == POWER_SAVING_ACC)
                        {
                            err =  g_external_irq9.p_api->open(g_external_irq9.p_ctrl, g_external_irq9.p_cfg);
                            if(err) { APP_ERR_TRAP(err); }
                        }

                        /*Mode exit*/
                        goto mode_select;
                    }

                    /*Read GNSS information*/
                    read_gnss();

                    /*Read Sensors*/
                    bme280_measure();

                    /*Measure battery voltage*/
                    modem_data.batt_voltage_mv = MeasureBattVoltage();

                    /*Battery critical shut down*/
                    if(modem_data.batt_voltage_mv <= SHUT_DOWN_VOLTAGE)
                    {
                        battery_critical_shut_down();
                    }

                    /*Send SMS in intervals generated by RTC alarm interrupt*/
                    if(tracker_settings.repeat != 0)
                    {
                        if(alarm_flag)
                        {
                            tracker_settings.repeat--;

                            /*Send messages*/
                            send_sms();

                            /*Alarm setup*/
                            user_function_set_rtc_alarm((time_t)tracker_settings.interval);

                            alarm_flag = false;
                        }
                    }

                    /*Wait 1000 milliseconds*/
                    tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND));
                }

                break;
            }

            /*Real time clock mode*/
            case POWER_SAVING_RTC:
            {
                /*Reset Normal Mode variables*/
                alarm_flag = true;
                tracker_settings.interval = 0;
                tracker_settings.repeat = 0;

                /*Read GNSS data, wait for satellites */
                for(i = 0; i < GNSS_SAT_WAIT; i++)
                {
                    /*Look for URC (Unsolicited Result Code)*/
                    SCP_Process();

                    /* Read/Parse messages */
                    sms_parser();

                    /*Break if operational mode has changed*/
                    if(tracker_settings.mode != POWER_SAVING_RTC)
                    {
                        /*Accelerometer IRQ9 interrupt*/
                        if(tracker_settings.mode == POWER_SAVING_ACC)
                        {
                            err =  g_external_irq9.p_api->open(g_external_irq9.p_ctrl, g_external_irq9.p_cfg);
                            if(err) { APP_ERR_TRAP(err); }
                        }

                        /*Mode exit*/
                        goto mode_select;
                    }

                    /*Read GNSS information*/
                    read_gnss();

                    /*Stop the search if certain accuracy is reached*/
                    if(atoi(modem_data.gps_satt_in_use) > GNSS_NSAT)
                    {
                        break;
                    }

                    /*Wait 1000 milliseconds*/
                    tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND));
                }

                /*Read Temperature, Pressure, Humidity*/
                bme280_measure();

                /*Measure battery voltage*/
                modem_data.batt_voltage_mv = MeasureBattVoltage();

                /*Send messages*/
                send_sms();

                /*Wait 5000ms for modem to finish send SMS*/
                tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND*5));

                /*Enter low power mode if operation mode have not changed*/
                if(tracker_settings.mode == POWER_SAVING_RTC)
                {
                    /*Alarm setup*/
                    user_function_set_rtc_alarm((time_t)tracker_settings.RTC_interval);

                    /*Enter Low Power Mode*/
                    (void) g_sf_power_profiles_v2_common.p_api->lowPowerApply(g_sf_power_profiles_v2_common.p_ctrl, &g_sf_power_profiles_v2_low_power_0); /*Enter low power mode*/
                }

                break;
            }

            /*Movement detection mode*/
            case POWER_SAVING_ACC:
            {
                /*Reset Normal Mode variables*/
                alarm_flag = true;
                tracker_settings.interval = 0;
                tracker_settings.repeat = 0;

                /*Read GNSS data, wait for satellites */
                for(i = 0; i < GNSS_SAT_WAIT; i++)
                {
                    /*Look for URC (Unsolicited Result Code)*/
                    SCP_Process();

                    /* Read/Parse messages */
                    sms_parser();

                    /*Break if operational mode has changed*/
                    if(tracker_settings.mode != POWER_SAVING_ACC)
                    {
                        /*IRQ9 interrupt turn off*/
                        err =  g_external_irq9.p_api->close(g_external_irq9.p_ctrl);
                        if(err) { APP_ERR_TRAP(err); }

                        /*Mode exit*/
                        goto mode_select;
                    }

                    /*Read GNSS information*/
                    read_gnss();

                    /*Stop the search if certain accuracy is reached*/
                    if(atoi(modem_data.gps_satt_in_use) > GNSS_NSAT)
                    {
                        break;
                    }

                    /*Wait 1000 milliseconds*/
                    tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND));
                }

                /*Read Temperature, Pressure, Humidity*/
                bme280_measure();

                /*Measure battery voltage*/
                modem_data.batt_voltage_mv = MeasureBattVoltage();

                /*Send messages*/
                send_sms();

                /*Wait 5000ms for modem to finish send SMS*/
                tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND*5));

                /*Enter low power mode if operation mode have not changed*/
                if(tracker_settings.mode == POWER_SAVING_ACC)
                {
                    /*Enter Low Power Mode*/
                    (void) g_sf_power_profiles_v2_common.p_api->lowPowerApply(g_sf_power_profiles_v2_common.p_ctrl, &g_sf_power_profiles_v2_low_power_0); /*Enter low power mode*/
                }
                break;
            }
        }
    }
}
