/*
 * sms_commands.c
 *
 *  Created on: 12 Dec 2018
 *      Author: GDR
 */


#include "sms_commands.h"
#include "common.h"
#include "StringCommandParser.h"
#include "stdlib.h"
#include "stdio.h"

/*Tracker settings storage*/
extern tracker_settings_t tracker_settings;
extern char g_sms_buff[100];

/*AT Commands Parser Storage*/
extern TSCPHandler   SCPHandler;

/* Normal Mode */
void NormalModeConfig (const char *pString)
{
    unsigned int interval = 0;
    uint8_t repetition = 0;
    char *symbol = NULL;
    char local_buff[50];
    uint8_t previuos_mode;

    /* Skip text 'normal'*/
    pString += 6;
    if(pString)
    {
        interval = (uint32_t)atoi(pString);
        symbol = strstr(pString, "t");
        if(symbol)
        {
            symbol++;
            repetition = (uint8_t)atoi(symbol);
        }

        /*Copy received settings*/
        previuos_mode = tracker_settings.mode;
        tracker_settings.mode = POWER_SAVING_OFF;
        tracker_settings.interval = interval;
        tracker_settings.repeat = repetition;

        /*Save settings, only if mode has changed (decrease flash wearing)*/
        if(tracker_settings.mode != previuos_mode)
        {
            TrackerSettingsSave();
        }

        /*Send SMS confirmation*/
        memset(g_sms_buff, 0x00, sizeof(g_sms_buff));
        memset(local_buff, 0x00, sizeof(local_buff));
        strcat(g_sms_buff, "Normal mode OK! ");
        strcat(g_sms_buff, "Interval ");
        memset(local_buff, 0x00, sizeof(local_buff));
        sprintf(local_buff, "%u", interval);
        strcat(g_sms_buff, local_buff);
        strcat(g_sms_buff, " seconds. ");
        strcat(g_sms_buff, "Repeat ");
        memset(local_buff, 0x00, sizeof(local_buff));
        sprintf(local_buff, "%d", repetition);
        strcat(g_sms_buff, local_buff);
        strcat(g_sms_buff, " times.");

        /*Termination symbol*/
        strcat(g_sms_buff, "\032");

        sprintf(local_buff, "AT+CMGS=%s\r", tracker_settings.phone_number);
        SCP_SendDoubleCommandWaitAnswer(local_buff, g_sms_buff, ">", "OK", 2000, 1);
    }

}


/* Real Time Clock Mode */
void RTCModeConfig (const char *pString)
{
    unsigned int interval = 0;
    char local_buff[50];

    /* Skip text 'rtc'*/
    pString += 3;
    if(pString)
    {
        interval = (uint32_t)atoi(pString);
        tracker_settings.mode = POWER_SAVING_RTC;
        tracker_settings.RTC_interval = interval;

        TrackerSettingsSave();

        /*Send SMS confirmation*/
        memset(g_sms_buff, 0x00, sizeof(g_sms_buff));
        memset(local_buff, 0x00, sizeof(local_buff));
        strcat(g_sms_buff, "RTC power saving mode OK! ");
        strcat(g_sms_buff, "Interval ");
        memset(local_buff, 0x00, sizeof(local_buff));
        sprintf(local_buff, "%u", interval);
        strcat(g_sms_buff, local_buff);
        strcat(g_sms_buff, " seconds. ");

        /*Termination symbol*/
        strcat(g_sms_buff, "\032");

        sprintf(local_buff, "AT+CMGS=%s\r", tracker_settings.phone_number);
        SCP_SendDoubleCommandWaitAnswer(local_buff, g_sms_buff, ">", "OK", 2000, 1);
    }
}

/* Accelerometer Mode */
void ACCModeConfig (const char *pString)
{
    uint8_t threshold = 0;
    char local_buff[50];

    /* Skip text 'acc'*/
    pString += 3;
    if(pString)
    {
        threshold = (uint8_t)atoi(pString);
        tracker_settings.mode = POWER_SAVING_ACC;
        tracker_settings.ACC_threshold = threshold;

        TrackerSettingsSave();

        /*Send SMS confirmation*/
        memset(g_sms_buff, 0x00, sizeof(g_sms_buff));
        memset(local_buff, 0x00, sizeof(local_buff));
        strcat(g_sms_buff, "Movement detection mode OK! ");
        strcat(g_sms_buff, "Threshold ");
        memset(local_buff, 0x00, sizeof(local_buff));
        sprintf(local_buff, "%u", threshold);
        strcat(g_sms_buff, local_buff);
        strcat(g_sms_buff, " units. ");

        /*Termination symbol*/
        strcat(g_sms_buff, "\032");

        sprintf(local_buff, "AT+CMGS=%s\r", tracker_settings.phone_number);
        SCP_SendDoubleCommandWaitAnswer(local_buff, g_sms_buff, ">", "OK", 2000, 1);
    }
}

/*Memorise Number*/
void MemNumConfig (const char *pString)
{
    char *result = NULL;
    char local_buff[50];

    UNUSED(pString);

    /*Parse phone number from received SMS*/
    result = strstr( (char*)SCPHandler.RxBuffer, "+CMGL: ");
    if (result)
    {
        result = NULL;
        result = strstr( (char*)SCPHandler.RxBuffer, ",");
        if (result)
        {
            result++;
            result = strstr( result, ",");
            if(result)
            {
                result++;

                if(*result == '"')
                {
                    /*Copy operator to the RAM and return*/
                    /*Prepare to save the callers number*/
                    memset(tracker_settings.phone_number, 0x00, sizeof(tracker_settings.phone_number));

                    /*Save callers number*/
                    for(uint8_t i = 0; i < sizeof(tracker_settings.phone_number); i++)
                    {
                        tracker_settings.phone_number[i] = *result;
                        result++;

                        /*Last operator char?*/
                        if(*result == '"')
                        {
                            i++;
                            tracker_settings.phone_number[i] = *result;
                            break;
                        }
                    }
                }
            }
        }
    }

    /*Saving into Data Flash*/
    if(result)
    {
        TrackerSettingsSave();

        /*Send SMS confirmation*/
        memset(g_sms_buff, 0x00, sizeof(g_sms_buff));
        memset(local_buff, 0x00, sizeof(local_buff));
        strcat(g_sms_buff, "Saved: ");
        strcat(g_sms_buff, tracker_settings.phone_number);

        /*Termination symbol*/
        strcat(g_sms_buff, "\032");

        sprintf(local_buff, "AT+CMGS=%s\r", tracker_settings.phone_number);
        SCP_SendDoubleCommandWaitAnswer(local_buff, g_sms_buff, ">", "OK", 2000, 1);
    }

}
