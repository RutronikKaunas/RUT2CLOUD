RUT2CLOUD Rutronik Board Rev2 typical GNSS tracker demo.
(GL865 V3.1 Telit Modem; SL876Q5-A Telit GNSS Module; Renesas Synergy S3A7 64-pin QFN MCU, Battery charger, LDO, BOSH Sensors BME280 and BMX055 are on board.

Note: Before using this firmware the wire between MCU's P304 and BMX055 INT1 pin has to soldered in order to have the wake up from accelerometr's interrupt;
Also call has to be made or SMS has to be send to memorize SMS recipient number.

The Tracker is controlled using SMS messages. 
Four SMS commands are implemented in the demo firmware:

1. "normal" 
SMS text example "normal60t10".
Text "normal" is for normal mode activation.
Digits "60" is time interval for receiving SMS and "10" is amount of messages to be received.
Normal mode means that tracker is never going to be turned off, until battery is empty. 
It is always ready to receive SMS commands and send SMS with coordinates as soon as etc.: "normnormal60t10" command is received.

2. "rtc"
SMS text example "rtc300".
Text "rtc" is for real time clock wake up and power saving mode activation.
Digits "300" are time interval for receiving SMS.
RTC Clock mode saves the battery power by turning off Modem and GNSS module and suspending the MCU itself for low power mode.
GNSS is shut down only if interval is longer than 1800 seconds by default.

3. "acc"
SMS text example "acc10".
Text "acc" is for accelerometer wake up and power saving mode activation.
Digits "10" are for accelerometer slope detection threshold (sensitivity) setup.
In this mode system is driven into low power mode after GNNS coordinates has been found and SMS sent.
The system will wake up if any movement is detected.

4. "memnum"
SMS text example "memnum".
Use this command for memorizing SMS recipient's number.
In addition to this, the number can be stored simple by calling the Trackers SIM card number (it will be hanged automatically)


