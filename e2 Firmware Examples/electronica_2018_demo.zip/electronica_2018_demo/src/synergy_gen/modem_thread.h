/* generated thread header file - do not edit */
#ifndef MODEM_THREAD_H_
#define MODEM_THREAD_H_
#include "bsp_api.h"
#include "tx_api.h"
#include "hal_data.h"
#ifdef __cplusplus
extern "C" void modem_thread_entry(void);
#else
extern void modem_thread_entry(void);
#endif
#include "r_agt.h"
#include "r_timer_api.h"
#ifdef __cplusplus
extern "C"
{
#endif
/** AGT Timer Instance */
extern const timer_instance_t g_modem_timer;
#ifndef g_modem_timer_callback
void g_modem_timer_callback(timer_callback_args_t *p_args);
#endif
#ifdef __cplusplus
} /* extern "C" */
#endif
#endif /* MODEM_THREAD_H_ */
