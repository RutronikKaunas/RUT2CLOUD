/* generated thread source file - do not edit */
#include "sensors_thread.h"

TX_THREAD sensors_thread;
void sensors_thread_create(void);
static void sensors_thread_func(ULONG thread_input);
static uint8_t sensors_thread_stack[1024] BSP_PLACE_IN_SECTION_V2(".stack.sensors_thread") BSP_ALIGN_VARIABLE_V2(BSP_STACK_ALIGNMENT);
void tx_startup_err_callback(void *p_instance, void *p_data);
void tx_startup_common_init(void);
/** Get driver cfg from bus and use all same settings except slave address and addressing mode. */
const i2c_cfg_t g_sf_i2c_reset_00_i2c_cfg =
{ .channel = g_sf_i2c_bus0_CHANNEL,
  .rate = g_sf_i2c_bus0_RATE,
  .slave = 0x00,
  .addr_mode = I2C_ADDR_MODE_7BIT,
  .sda_delay = g_sf_i2c_bus0_SDA_DELAY,
  .p_transfer_tx = g_sf_i2c_bus0_P_TRANSFER_TX,
  .p_transfer_rx = g_sf_i2c_bus0_P_TRANSFER_RX,
  .p_callback = g_sf_i2c_bus0_P_CALLBACK,
  .p_context = g_sf_i2c_bus0_P_CONTEXT,
  .rxi_ipl = g_sf_i2c_bus0_RXI_IPL,
  .txi_ipl = g_sf_i2c_bus0_TXI_IPL,
  .tei_ipl = g_sf_i2c_bus0_TEI_IPL,
  .eri_ipl = g_sf_i2c_bus0_ERI_IPL,
  .p_extend = g_sf_i2c_bus0_P_EXTEND, };

sf_i2c_instance_ctrl_t g_sf_i2c_reset_00_ctrl =
{ .p_lower_lvl_ctrl = &g_i2c0_ctrl, };
const sf_i2c_cfg_t g_sf_i2c_reset_00_cfg =
{ .p_bus = (sf_i2c_bus_t *) &g_sf_i2c_bus0, .p_lower_lvl_cfg = &g_sf_i2c_reset_00_i2c_cfg, };
/* Instance structure to use this module. */
const sf_i2c_instance_t g_sf_i2c_reset_00 =
{ .p_ctrl = &g_sf_i2c_reset_00_ctrl, .p_cfg = &g_sf_i2c_reset_00_cfg, .p_api = &g_sf_i2c_on_sf_i2c };
/** Get driver cfg from bus and use all same settings except slave address and addressing mode. */
const i2c_cfg_t g_sf_i2c_reset_FF_i2c_cfg =
{ .channel = g_sf_i2c_bus0_CHANNEL,
  .rate = g_sf_i2c_bus0_RATE,
  .slave = 0xFF,
  .addr_mode = I2C_ADDR_MODE_7BIT,
  .sda_delay = g_sf_i2c_bus0_SDA_DELAY,
  .p_transfer_tx = g_sf_i2c_bus0_P_TRANSFER_TX,
  .p_transfer_rx = g_sf_i2c_bus0_P_TRANSFER_RX,
  .p_callback = g_sf_i2c_bus0_P_CALLBACK,
  .p_context = g_sf_i2c_bus0_P_CONTEXT,
  .rxi_ipl = g_sf_i2c_bus0_RXI_IPL,
  .txi_ipl = g_sf_i2c_bus0_TXI_IPL,
  .tei_ipl = g_sf_i2c_bus0_TEI_IPL,
  .eri_ipl = g_sf_i2c_bus0_ERI_IPL,
  .p_extend = g_sf_i2c_bus0_P_EXTEND, };

sf_i2c_instance_ctrl_t g_sf_i2c_reset_FF_ctrl =
{ .p_lower_lvl_ctrl = &g_i2c0_ctrl, };
const sf_i2c_cfg_t g_sf_i2c_reset_FF_cfg =
{ .p_bus = (sf_i2c_bus_t *) &g_sf_i2c_bus0, .p_lower_lvl_cfg = &g_sf_i2c_reset_FF_i2c_cfg, };
/* Instance structure to use this module. */
const sf_i2c_instance_t g_sf_i2c_reset_FF =
{ .p_ctrl = &g_sf_i2c_reset_FF_ctrl, .p_cfg = &g_sf_i2c_reset_FF_cfg, .p_api = &g_sf_i2c_on_sf_i2c };
/** Get driver cfg from bus and use all same settings except slave address and addressing mode. */
const i2c_cfg_t g_sf_i2c_493D_i2c_cfg =
{ .channel = g_sf_i2c_bus0_CHANNEL,
  .rate = g_sf_i2c_bus0_RATE,
  .slave = 0x35,
  .addr_mode = I2C_ADDR_MODE_7BIT,
  .sda_delay = g_sf_i2c_bus0_SDA_DELAY,
  .p_transfer_tx = g_sf_i2c_bus0_P_TRANSFER_TX,
  .p_transfer_rx = g_sf_i2c_bus0_P_TRANSFER_RX,
  .p_callback = g_sf_i2c_bus0_P_CALLBACK,
  .p_context = g_sf_i2c_bus0_P_CONTEXT,
  .rxi_ipl = g_sf_i2c_bus0_RXI_IPL,
  .txi_ipl = g_sf_i2c_bus0_TXI_IPL,
  .tei_ipl = g_sf_i2c_bus0_TEI_IPL,
  .eri_ipl = g_sf_i2c_bus0_ERI_IPL,
  .p_extend = g_sf_i2c_bus0_P_EXTEND, };

sf_i2c_instance_ctrl_t g_sf_i2c_493D_ctrl =
{ .p_lower_lvl_ctrl = &g_i2c0_ctrl, };
const sf_i2c_cfg_t g_sf_i2c_493D_cfg =
{ .p_bus = (sf_i2c_bus_t *) &g_sf_i2c_bus0, .p_lower_lvl_cfg = &g_sf_i2c_493D_i2c_cfg, };
/* Instance structure to use this module. */
const sf_i2c_instance_t g_sf_i2c_493D =
{ .p_ctrl = &g_sf_i2c_493D_ctrl, .p_cfg = &g_sf_i2c_493D_cfg, .p_api = &g_sf_i2c_on_sf_i2c };
#if (3) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_transfer3) && !defined(SSP_SUPPRESS_ISR_DTCELC_EVENT_ELC_SOFTWARE_EVENT_0)
#define DTC_ACTIVATION_SRC_ELC_EVENT_ELC_SOFTWARE_EVENT_0
#if defined(DTC_ACTIVATION_SRC_ELC_EVENT_ELC_SOFTWARE_EVENT_0) && !defined(DTC_VECTOR_DEFINED_SOFTWARE_EVENT_0)
SSP_VECTOR_DEFINE( elc_software_event_isr, ELC, SOFTWARE_EVENT_0);
#define DTC_VECTOR_DEFINED_SOFTWARE_EVENT_0
#endif
#if defined(DTC_ACTIVATION_SRC_ELC_EVENT_ELC_SOFTWARE_EVENT_1) && !defined(DTC_VECTOR_DEFINED_SOFTWARE_EVENT_1)
SSP_VECTOR_DEFINE(elc_software_event_isr, ELC, SOFTWARE_EVENT_1);
#define DTC_VECTOR_DEFINED_SOFTWARE_EVENT_1
#endif
#endif
#endif

dtc_instance_ctrl_t g_transfer3_ctrl;
transfer_info_t g_transfer3_info =
{ .dest_addr_mode = TRANSFER_ADDR_MODE_INCREMENTED,
  .repeat_area = TRANSFER_REPEAT_AREA_SOURCE,
  .irq = TRANSFER_IRQ_END,
  .chain_mode = TRANSFER_CHAIN_MODE_DISABLED,
  .src_addr_mode = TRANSFER_ADDR_MODE_INCREMENTED,
  .size = TRANSFER_SIZE_2_BYTE,
  .mode = TRANSFER_MODE_BLOCK,
  .p_dest = (void *) NULL,
  .p_src = (void const *) NULL,
  .num_blocks = 1,
  .length = 1, };
const transfer_cfg_t g_transfer3_cfg =
{ .p_info = &g_transfer3_info, .activation_source = ELC_EVENT_ELC_SOFTWARE_EVENT_0, .auto_enable = false, .p_callback =
          NULL,
  .p_context = &g_transfer3, .irq_ipl = (3) };
/* Instance structure to use this module. */
const transfer_instance_t g_transfer3 =
{ .p_ctrl = &g_transfer3_ctrl, .p_cfg = &g_transfer3_cfg, .p_api = &g_transfer_on_dtc };
#if (BSP_IRQ_DISABLED) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_timer0) && !defined(SSP_SUPPRESS_ISR_AGT0)
SSP_VECTOR_DEFINE_CHAN(agt_int_isr, AGT, INT, 0);
#endif
#endif
static agt_instance_ctrl_t g_timer0_ctrl;
static const timer_on_agt_cfg_t g_timer0_extend =
{ .count_source = AGT_CLOCK_PCLKB,
  .agto_output_enabled = false,
  .agtio_output_enabled = false,
  .output_inverted = false,
  .agtoa_output_enable = false,
  .agtob_output_enable = false, };
static const timer_cfg_t g_timer0_cfg =
{ .mode = TIMER_MODE_PERIODIC,
  .period = 100,
  .unit = TIMER_UNIT_PERIOD_MSEC,
  .channel = 0,
  .autostart = false,
  .p_callback = NULL,
  .p_context = &g_timer0,
  .p_extend = &g_timer0_extend,
  .irq_ipl = (BSP_IRQ_DISABLED), };
/* Instance structure to use this module. */
const timer_instance_t g_timer0 =
{ .p_ctrl = &g_timer0_ctrl, .p_cfg = &g_timer0_cfg, .p_api = &g_timer_on_agt };
#if (3) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_adc0) && !defined(SSP_SUPPRESS_ISR_ADC0)
SSP_VECTOR_DEFINE_CHAN(adc_scan_end_isr, ADC, SCAN_END, 0);
#endif
#endif
#if (BSP_IRQ_DISABLED) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_adc0) && !defined(SSP_SUPPRESS_ISR_ADC0)
SSP_VECTOR_DEFINE_CHAN(adc_scan_end_b_isr, ADC, SCAN_END_B, 0);
#endif
#endif
adc_instance_ctrl_t g_adc0_ctrl;
const adc_cfg_t g_adc0_cfg =
{ .unit = 0,
  .mode = ADC_MODE_SINGLE_SCAN,
  .resolution = ADC_RESOLUTION_14_BIT,
  .alignment = ADC_ALIGNMENT_RIGHT,
  .add_average_count = ADC_ADD_FOUR,
  .clearing = ADC_CLEAR_AFTER_READ_ON,
  .trigger = ADC_TRIGGER_SYNC_ELC,
  .trigger_group_b = ADC_TRIGGER_SYNC_ELC,
  .p_callback = NULL,
  .p_context = &g_adc0,
  .scan_end_ipl = (3),
  .scan_end_b_ipl = (BSP_IRQ_DISABLED),
  .calib_adc_skip = false, };
const adc_channel_cfg_t g_adc0_channel_cfg =
        { .scan_mask = (uint32_t) (
                ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) ADC_MASK_CHANNEL_3)
                        | ((uint64_t) ADC_MASK_CHANNEL_4) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0)
                        | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0)
                        | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0)
                        | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0)
                        | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0)
                        | ((uint64_t) 0) | (0)),
          /** Group B channel mask is right shifted by 32 at the end to form the proper mask */
          .scan_mask_group_b = (uint32_t) (
                  (((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) ADC_MASK_CHANNEL_3)
                          | ((uint64_t) ADC_MASK_CHANNEL_4) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0)
                          | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0)
                          | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0)
                          | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0)
                          | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0)
                          | ((uint64_t) 0) | (0)) >> 32),
          .priority_group_a = ADC_GROUP_A_PRIORITY_OFF, .add_mask = (uint32_t) (
                  (0) | (0) | (0) | (ADC_MASK_CHANNEL_3) | (ADC_MASK_CHANNEL_4) | (0) | (0) | (0) | (0) | (0) | (0)
                          | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0)
                          | (0) | (0) | (0) | (0)),
          .sample_hold_mask = (uint32_t) ((0) | (0) | (0)), .sample_hold_states = 24, };
/* Instance structure to use this module. */
const adc_instance_t g_adc0 =
{ .p_ctrl = &g_adc0_ctrl, .p_cfg = &g_adc0_cfg, .p_channel_cfg = &g_adc0_channel_cfg, .p_api = &g_adc_on_adc };
#if defined(__ICCARM__)
#define g_sf_adc_periodic0_err_callback_WEAK_ATTRIBUTE
#pragma weak g_sf_adc_periodic0_err_callback  = g_sf_adc_periodic0_err_callback_internal
#elif defined(__GNUC__)
#define g_sf_adc_periodic0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_sf_adc_periodic0_err_callback_internal")))
#endif
void g_sf_adc_periodic0_err_callback(void *p_instance, void *p_data)
g_sf_adc_periodic0_err_callback_WEAK_ATTRIBUTE;
#if ADC_PERIODIC_ON_ADC_PERIODIC_CALLBACK_USED_g_sf_adc_periodic0
void g_adc_framework_user_callback(sf_adc_periodic_callback_args_t * p_args);
#endif
uint16_t g_user_buffer[4];
sf_adc_periodic_instance_ctrl_t g_sf_adc_periodic0_ctrl;
sf_adc_periodic_cfg_t g_sf_adc_periodic0_cfg =
{ .p_lower_lvl_adc = &g_adc0, .p_lower_lvl_timer = &g_timer0, .p_lower_lvl_transfer = &g_transfer3, .p_data_buffer =
          g_user_buffer,
  .data_buffer_length = 4, .sample_count = 1, .p_callback = g_adc_framework_user_callback, .p_extend = NULL, };

sf_adc_periodic_instance_t g_sf_adc_periodic0 =
        { .p_ctrl = &g_sf_adc_periodic0_ctrl, .p_cfg = &g_sf_adc_periodic0_cfg, .p_api =
                  &g_sf_adc_periodic_on_sf_adc_periodic, };
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function 
 *             with the prototype below.
 *             - void g_sf_adc_periodic0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_sf_adc_periodic0_err_callback_internal(void *p_instance, void *p_data);
void g_sf_adc_periodic0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}

/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.

 *            - void sf_adc_periodic_init0(void)
 **********************************************************************************************************************/
void sf_adc_periodic_init0(void)
{
    ssp_err_t ssp_err_g_sf_adc_periodic0;
    ssp_err_g_sf_adc_periodic0 = g_sf_adc_periodic0.p_api->open (g_sf_adc_periodic0.p_ctrl, g_sf_adc_periodic0.p_cfg);
    if (SSP_SUCCESS != ssp_err_g_sf_adc_periodic0)
    {
        g_sf_adc_periodic0_err_callback ((void *) &g_sf_adc_periodic0, &ssp_err_g_sf_adc_periodic0);
    }
}
/** Get driver cfg from bus and use all same settings except slave address and addressing mode. */
const i2c_cfg_t g_sf_i2c_mlx90393_i2c_cfg =
{ .channel = g_sf_i2c_bus0_CHANNEL,
  .rate = g_sf_i2c_bus0_RATE,
  .slave = 0x0C,
  .addr_mode = I2C_ADDR_MODE_7BIT,
  .sda_delay = g_sf_i2c_bus0_SDA_DELAY,
  .p_transfer_tx = g_sf_i2c_bus0_P_TRANSFER_TX,
  .p_transfer_rx = g_sf_i2c_bus0_P_TRANSFER_RX,
  .p_callback = g_sf_i2c_bus0_P_CALLBACK,
  .p_context = g_sf_i2c_bus0_P_CONTEXT,
  .rxi_ipl = g_sf_i2c_bus0_RXI_IPL,
  .txi_ipl = g_sf_i2c_bus0_TXI_IPL,
  .tei_ipl = g_sf_i2c_bus0_TEI_IPL,
  .eri_ipl = g_sf_i2c_bus0_ERI_IPL,
  .p_extend = g_sf_i2c_bus0_P_EXTEND, };

sf_i2c_instance_ctrl_t g_sf_i2c_mlx90393_ctrl =
{ .p_lower_lvl_ctrl = &g_i2c0_ctrl, };
const sf_i2c_cfg_t g_sf_i2c_mlx90393_cfg =
{ .p_bus = (sf_i2c_bus_t *) &g_sf_i2c_bus0, .p_lower_lvl_cfg = &g_sf_i2c_mlx90393_i2c_cfg, };
/* Instance structure to use this module. */
const sf_i2c_instance_t g_sf_i2c_mlx90393 =
{ .p_ctrl = &g_sf_i2c_mlx90393_ctrl, .p_cfg = &g_sf_i2c_mlx90393_cfg, .p_api = &g_sf_i2c_on_sf_i2c };
/** Get driver cfg from bus and use all same settings except slave address and addressing mode. */
const i2c_cfg_t g_sf_i2c_bmx055_mag_i2c_cfg =
{ .channel = g_sf_i2c_bus0_CHANNEL,
  .rate = g_sf_i2c_bus0_RATE,
  .slave = 0x13,
  .addr_mode = I2C_ADDR_MODE_7BIT,
  .sda_delay = g_sf_i2c_bus0_SDA_DELAY,
  .p_transfer_tx = g_sf_i2c_bus0_P_TRANSFER_TX,
  .p_transfer_rx = g_sf_i2c_bus0_P_TRANSFER_RX,
  .p_callback = g_sf_i2c_bus0_P_CALLBACK,
  .p_context = g_sf_i2c_bus0_P_CONTEXT,
  .rxi_ipl = g_sf_i2c_bus0_RXI_IPL,
  .txi_ipl = g_sf_i2c_bus0_TXI_IPL,
  .tei_ipl = g_sf_i2c_bus0_TEI_IPL,
  .eri_ipl = g_sf_i2c_bus0_ERI_IPL,
  .p_extend = g_sf_i2c_bus0_P_EXTEND, };

sf_i2c_instance_ctrl_t g_sf_i2c_bmx055_mag_ctrl =
{ .p_lower_lvl_ctrl = &g_i2c0_ctrl, };
const sf_i2c_cfg_t g_sf_i2c_bmx055_mag_cfg =
{ .p_bus = (sf_i2c_bus_t *) &g_sf_i2c_bus0, .p_lower_lvl_cfg = &g_sf_i2c_bmx055_mag_i2c_cfg, };
/* Instance structure to use this module. */
const sf_i2c_instance_t g_sf_i2c_bmx055_mag =
{ .p_ctrl = &g_sf_i2c_bmx055_mag_ctrl, .p_cfg = &g_sf_i2c_bmx055_mag_cfg, .p_api = &g_sf_i2c_on_sf_i2c };
/** Get driver cfg from bus and use all same settings except slave address and addressing mode. */
const i2c_cfg_t g_sf_i2c_bmx055_gyr_i2c_cfg =
{ .channel = g_sf_i2c_bus0_CHANNEL,
  .rate = g_sf_i2c_bus0_RATE,
  .slave = 0x69,
  .addr_mode = I2C_ADDR_MODE_7BIT,
  .sda_delay = g_sf_i2c_bus0_SDA_DELAY,
  .p_transfer_tx = g_sf_i2c_bus0_P_TRANSFER_TX,
  .p_transfer_rx = g_sf_i2c_bus0_P_TRANSFER_RX,
  .p_callback = g_sf_i2c_bus0_P_CALLBACK,
  .p_context = g_sf_i2c_bus0_P_CONTEXT,
  .rxi_ipl = g_sf_i2c_bus0_RXI_IPL,
  .txi_ipl = g_sf_i2c_bus0_TXI_IPL,
  .tei_ipl = g_sf_i2c_bus0_TEI_IPL,
  .eri_ipl = g_sf_i2c_bus0_ERI_IPL,
  .p_extend = g_sf_i2c_bus0_P_EXTEND, };

sf_i2c_instance_ctrl_t g_sf_i2c_bmx055_gyr_ctrl =
{ .p_lower_lvl_ctrl = &g_i2c0_ctrl, };
const sf_i2c_cfg_t g_sf_i2c_bmx055_gyr_cfg =
{ .p_bus = (sf_i2c_bus_t *) &g_sf_i2c_bus0, .p_lower_lvl_cfg = &g_sf_i2c_bmx055_gyr_i2c_cfg, };
/* Instance structure to use this module. */
const sf_i2c_instance_t g_sf_i2c_bmx055_gyr =
{ .p_ctrl = &g_sf_i2c_bmx055_gyr_ctrl, .p_cfg = &g_sf_i2c_bmx055_gyr_cfg, .p_api = &g_sf_i2c_on_sf_i2c };
/** Get driver cfg from bus and use all same settings except slave address and addressing mode. */
const i2c_cfg_t g_sf_i2c_bmx055_acc_i2c_cfg =
{ .channel = g_sf_i2c_bus0_CHANNEL,
  .rate = g_sf_i2c_bus0_RATE,
  .slave = 0x19,
  .addr_mode = I2C_ADDR_MODE_7BIT,
  .sda_delay = g_sf_i2c_bus0_SDA_DELAY,
  .p_transfer_tx = g_sf_i2c_bus0_P_TRANSFER_TX,
  .p_transfer_rx = g_sf_i2c_bus0_P_TRANSFER_RX,
  .p_callback = g_sf_i2c_bus0_P_CALLBACK,
  .p_context = g_sf_i2c_bus0_P_CONTEXT,
  .rxi_ipl = g_sf_i2c_bus0_RXI_IPL,
  .txi_ipl = g_sf_i2c_bus0_TXI_IPL,
  .tei_ipl = g_sf_i2c_bus0_TEI_IPL,
  .eri_ipl = g_sf_i2c_bus0_ERI_IPL,
  .p_extend = g_sf_i2c_bus0_P_EXTEND, };

sf_i2c_instance_ctrl_t g_sf_i2c_bmx055_acc_ctrl =
{ .p_lower_lvl_ctrl = &g_i2c0_ctrl, };
const sf_i2c_cfg_t g_sf_i2c_bmx055_acc_cfg =
{ .p_bus = (sf_i2c_bus_t *) &g_sf_i2c_bus0, .p_lower_lvl_cfg = &g_sf_i2c_bmx055_acc_i2c_cfg, };
/* Instance structure to use this module. */
const sf_i2c_instance_t g_sf_i2c_bmx055_acc =
{ .p_ctrl = &g_sf_i2c_bmx055_acc_ctrl, .p_cfg = &g_sf_i2c_bmx055_acc_cfg, .p_api = &g_sf_i2c_on_sf_i2c };
/** Get driver cfg from bus and use all same settings except slave address and addressing mode. */
const i2c_cfg_t g_sf_i2c_bme280_i2c_cfg =
{ .channel = g_sf_i2c_bus0_CHANNEL,
  .rate = g_sf_i2c_bus0_RATE,
  .slave = 0x77,
  .addr_mode = I2C_ADDR_MODE_7BIT,
  .sda_delay = g_sf_i2c_bus0_SDA_DELAY,
  .p_transfer_tx = g_sf_i2c_bus0_P_TRANSFER_TX,
  .p_transfer_rx = g_sf_i2c_bus0_P_TRANSFER_RX,
  .p_callback = g_sf_i2c_bus0_P_CALLBACK,
  .p_context = g_sf_i2c_bus0_P_CONTEXT,
  .rxi_ipl = g_sf_i2c_bus0_RXI_IPL,
  .txi_ipl = g_sf_i2c_bus0_TXI_IPL,
  .tei_ipl = g_sf_i2c_bus0_TEI_IPL,
  .eri_ipl = g_sf_i2c_bus0_ERI_IPL,
  .p_extend = g_sf_i2c_bus0_P_EXTEND, };

sf_i2c_instance_ctrl_t g_sf_i2c_bme280_ctrl =
{ .p_lower_lvl_ctrl = &g_i2c0_ctrl, };
const sf_i2c_cfg_t g_sf_i2c_bme280_cfg =
{ .p_bus = (sf_i2c_bus_t *) &g_sf_i2c_bus0, .p_lower_lvl_cfg = &g_sf_i2c_bme280_i2c_cfg, };
/* Instance structure to use this module. */
const sf_i2c_instance_t g_sf_i2c_bme280 =
{ .p_ctrl = &g_sf_i2c_bme280_ctrl, .p_cfg = &g_sf_i2c_bme280_cfg, .p_api = &g_sf_i2c_on_sf_i2c };
TX_SEMAPHORE g_mx_drdy_semaphore;
extern bool g_ssp_common_initialized;
extern uint32_t g_ssp_common_thread_count;
extern TX_SEMAPHORE g_ssp_common_initialized_semaphore;

void sensors_thread_create(void)
{
    /* Increment count so we will know the number of ISDE created threads. */
    g_ssp_common_thread_count++;

    /* Initialize each kernel object. */
    UINT err_g_mx_drdy_semaphore;
    err_g_mx_drdy_semaphore = tx_semaphore_create (&g_mx_drdy_semaphore, (CHAR *) "MLX9039 Data Ready Semaphore", 0);
    if (TX_SUCCESS != err_g_mx_drdy_semaphore)
    {
        tx_startup_err_callback (&g_mx_drdy_semaphore, 0);
    }

    UINT err;
    err = tx_thread_create (&sensors_thread, (CHAR *) "Sensors Thread", sensors_thread_func, (ULONG) NULL,
                            &sensors_thread_stack, 1024, 4, 4, 10, TX_AUTO_START);
    if (TX_SUCCESS != err)
    {
        tx_startup_err_callback (&sensors_thread, 0);
    }
}

static void sensors_thread_func(ULONG thread_input)
{
    /* Not currently using thread_input. */
    SSP_PARAMETER_NOT_USED (thread_input);

    /* Initialize common components */
    tx_startup_common_init ();

    /* Initialize each module instance. */
    /** Call initialization function if user has selected to do so. */
#if (0)
    sf_adc_periodic_init0();
#endif

    /* Enter user code for this thread. */
    sensors_thread_entry ();
}
