/* generated thread source file - do not edit */
#include "modem_thread.h"

TX_THREAD modem_thread;
void modem_thread_create(void);
static void modem_thread_func(ULONG thread_input);
static uint8_t modem_thread_stack[2048] BSP_PLACE_IN_SECTION_V2(".stack.modem_thread") BSP_ALIGN_VARIABLE_V2(BSP_STACK_ALIGNMENT);
void tx_startup_err_callback(void *p_instance, void *p_data);
void tx_startup_common_init(void);
#if (1) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_modem_timer) && !defined(SSP_SUPPRESS_ISR_AGT1)
SSP_VECTOR_DEFINE_CHAN(agt_int_isr, AGT, INT, 1);
#endif
#endif
static agt_instance_ctrl_t g_modem_timer_ctrl;
static const timer_on_agt_cfg_t g_modem_timer_extend =
{ .count_source = AGT_CLOCK_PCLKB,
  .agto_output_enabled = false,
  .agtio_output_enabled = false,
  .output_inverted = false,
  .agtoa_output_enable = false,
  .agtob_output_enable = false, };
static const timer_cfg_t g_modem_timer_cfg =
{ .mode = TIMER_MODE_PERIODIC,
  .period = 10,
  .unit = TIMER_UNIT_PERIOD_MSEC,
  .channel = 1,
  .autostart = false,
  .p_callback = g_modem_timer_callback,
  .p_context = &g_modem_timer,
  .p_extend = &g_modem_timer_extend,
  .irq_ipl = (1), };
/* Instance structure to use this module. */
const timer_instance_t g_modem_timer =
{ .p_ctrl = &g_modem_timer_ctrl, .p_cfg = &g_modem_timer_cfg, .p_api = &g_timer_on_agt };
extern bool g_ssp_common_initialized;
extern uint32_t g_ssp_common_thread_count;
extern TX_SEMAPHORE g_ssp_common_initialized_semaphore;

void modem_thread_create(void)
{
    /* Increment count so we will know the number of ISDE created threads. */
    g_ssp_common_thread_count++;

    /* Initialize each kernel object. */

    UINT err;
    err = tx_thread_create (&modem_thread, (CHAR *) "Modem Thread", modem_thread_func, (ULONG) NULL,
                            &modem_thread_stack, 2048, 5, 5, 1, TX_AUTO_START);
    if (TX_SUCCESS != err)
    {
        tx_startup_err_callback (&modem_thread, 0);
    }
}

static void modem_thread_func(ULONG thread_input)
{
    /* Not currently using thread_input. */
    SSP_PARAMETER_NOT_USED (thread_input);

    /* Initialize common components */
    tx_startup_common_init ();

    /* Initialize each module instance. */

    /* Enter user code for this thread. */
    modem_thread_entry ();
}
