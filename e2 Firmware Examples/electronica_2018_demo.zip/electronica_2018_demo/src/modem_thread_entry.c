#include "modem_thread.h"
#include "common.h"
#include "config_s3a7.h"
#include "uart0_receive_thread.h"
#include "StringCommandParser.h"
#include "stdlib.h"
#include "stdio.h"
#include "util.h"
#include "math.h"

#define MAX_LONGITUDE               180
#define MAX_LATITUDE                90
#define CMD_BUFF_LENGTH             1024
#define SESSIONID_LENGTH            24
#define TELIT_BATT_ADC_COEFF        0.27618143//"Telit ADC1" battery voltage divider ratio
#define MODEM_DATA_REQUEST_INTERVAL 150 //time interval for modem properties
#define TELIT_CLOUD_UPDATE_INTERVAL 300 //time interval for modem properties
#define GPS_DATA_REQUEST_INTERVAL   5 //time interval for GPS
#define USE_GPS                     1
#define USE_AGPS                    1
#define UPLOAD_CLOUD                1
#define AGPS_DATA_REQUEST_INTERVAL  300 //time interval for AGPS
#define MSG_SEND_INTERVAL           1500 //time interval for SMS
#define GPRS_CONNECT_RETRY          3 //GPRS connect attemptions

/*Modem and GNSS Power and Reset control pins*/
ioport_port_pin_t cell_reset = CELL_RESET_CTRL_PIN;
ioport_port_pin_t gnss_reset = GNSS_RESET_CTRL_PIN;
ioport_port_pin_t cell_pwr = CELL_POWER_CTRL_PIN;
ioport_port_pin_t gnss_pwr = GNSS_POWER_CTRL_PIN;
ioport_port_pin_t charger_ctrl = CHARGER_CTRL_PIN;

const char fcmd_HTTPPOST[] ="POST /api HTTP/1.0\r\nHost: api-de.devicewise.com\r\nContent-Type: application/json\r\nContent-Length:";
const char fcmd_dW_auth[]  = "{\"auth\":{\"command\":\"api.authenticate\",\"params\":{\"appToken\":\"%s\",\"appId\":\"%s\",\"thingKey\":\"%s\"}}}\r\n";
const char fcmd_dw_post_auth[]  = "{\"auth\":{\"sessionId\":\"%s\"},";

const char fcmd_dw_post_p1[]  = "\"1\":{\"command\":\"property.publish\",\"params\":{\"thingKey\":\"%s\",\"key\":\"temperature\",\"value\":%d}},";
const char fcmd_dw_post_p2[]  = "\"2\":{\"command\":\"property.publish\",\"params\":{\"thingKey\":\"%s\",\"key\":\"pressure\",\"value\":%d}},";
const char fcmd_dw_post_p3[]  = "\"3\":{\"command\":\"property.publish\",\"params\":{\"thingKey\":\"%s\",\"key\":\"humidity\",\"value\":%d}},";
const char fcmd_dw_post_p4[]  = "\"4\":{\"command\":\"property.publish\",\"params\":{\"thingKey\":\"%s\",\"key\":\"tms1142_position\",\"value\":%d}},";
const char fcmd_dw_post_p5[]  = "\"5\":{\"command\":\"property.publish\",\"params\":{\"thingKey\":\"%s\",\"key\":\"mlx90393_position\",\"value\":%d}},";
const char fcmd_dw_post_p6[]  = "\"6\":{\"command\":\"property.publish\",\"params\":{\"thingKey\":\"%s\",\"key\":\"tle493d_position\",\"value\":%d}},";
const char fcmd_dw_post_p7[]  = "\"7\":{\"command\":\"property.publish\",\"params\":{\"thingKey\":\"%s\",\"key\":\"power_output\",\"value\":%d}},";
const char fcmd_dw_post_p8[]  = "\"8\":{\"command\":\"location.publish\",\"params\":{\"thingKey\":\"%s\",\"lat\":%s,\"lng\":%s,\"fixType\":\"manual\",\"fixAcc\":%s}}}}\r\n";

/*App ID and tokens*/
const char telit_appID[] = "xxx";
const char telit_appToken[] = "yyy";
char telit_sessionId[25];

char g_sms_buff[100];
extern sensors_data_storage_t sensors_data;
char post_buff[CMD_BUFF_LENGTH];
char post_length[16];
extern TSCPHandler   SCPHandler;
static _Bool msg_sts = false;
static _Bool agps_block = false;


/*Sensors data structure initial values*/
modem_data_storage_t modem_data =
{
 .gsm_pwr_status = false,
 .gnss_pwr_status = false,
 .charger_pwr_status = false,
 .gprs_status = false,
 .batt_voltage_mv = 0,
 .signal = 0,
 .gnss_online = false,
};

int32_t SignalQualitydBm(void);

/*Specific string copy function*/
static void strxcpy(char *dest, char *src)
{
    int limit;

    limit = 10;

    while(((*src >= '0') && (*src <= '9')) || (*src == '.') )
    {
        while(*src == ' ')
        {
            src++;
            limit--;

            if(limit <= 0)
            {
                break;
            }
        }

        *dest = *src;
        dest++;
        src++;
        limit--;

        if(limit <= 0)
        {
            break;
        }
    }
}

/**
 * Convert latitude,longitude from nmea to decimal
 * @param type lat = 1, lon = 2
 */
static double nmea2dec(char *nmea, char type, char *dir)
{
    unsigned int idx, dot = 0;
    double dec = 0;
    for (idx=0; idx<strlen(nmea);idx++){
        if (nmea[idx] == '.')
        {
            dot = idx;
            break;
        }
    }

    if ((dot < 3) || (dot > 5))
    {
        return 0;
    }

    int dd;
    double mm;
    char cdd[5], cmm[10];
    memset(cdd, 0, sizeof(cdd));
    memset(cmm, 0, sizeof(cmm));
    if(type == 1)
    {
        strncpy(cdd, nmea, dot-2);
        strncpy(cmm, nmea+dot-2, 7);
    }
    if(type == 2)
    {
        strncpy(cdd, nmea, dot-2);
        strncpy(cmm, nmea+dot-2, 7);
    }

    dd = atoi(cdd);
    mm = atof(cmm);

    dec = dd + (mm/60);

    if (type == 1 && dec > MAX_LATITUDE)
        return 0;
    else if (type == 2 && dec > MAX_LONGITUDE)
        return 0;

    if (*dir == 'N' || *dir == 'E')
      return dec;
    else
      return -1 * dec;
}

static inline void ModemReset(void)
{
    /*Turn on Reset MOSFET*/
    g_ioport.p_api->pinWrite(cell_reset, IOPORT_LEVEL_HIGH);

    /*Keep it on for a 200ms as required*/
    tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND/5));


    /*Turn off Reset MOSFET*/
    g_ioport.p_api->pinWrite(cell_reset, IOPORT_LEVEL_LOW);

    /*wait for a 1000ms as required*/
    tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND));
}

static inline void ModemOn(void)
{
    /*Turn on power for GSM Modem*/
    g_ioport.p_api->pinWrite(cell_pwr, IOPORT_LEVEL_HIGH);
}

static inline void ModemOff(void)
{
    /*Turn off power for GSM Modem*/
    g_ioport.p_api->pinWrite(cell_pwr, IOPORT_LEVEL_LOW);
}

static inline void GNSS_On(void)
{
    /*Turn on power for GNSS module*/
    g_ioport.p_api->pinWrite(gnss_pwr, IOPORT_LEVEL_HIGH);
}

static inline void GNSS_Off(void)
{
    /*Turn off power for GNSS module*/
    g_ioport.p_api->pinWrite(gnss_pwr, IOPORT_LEVEL_LOW);
}

static inline void Charger_On(void)
{
    /*Turn on Li-ion Battery Charger*/
    g_ioport.p_api->pinWrite(charger_ctrl, IOPORT_LEVEL_LOW);
}

static inline void Charger_Off(void)
{
    /*Turn off Li-ion Battery Charger*/
    g_ioport.p_api->pinWrite(charger_ctrl, IOPORT_LEVEL_HIGH);
}

static void GSM_init( void )
{
    /*Release reset pins*/
    g_ioport.p_api->pinWrite(cell_reset, IOPORT_LEVEL_LOW);
    g_ioport.p_api->pinWrite(gnss_reset, IOPORT_LEVEL_LOW);

    /*Reset the Modem*/
    ModemReset();

    /*Open and start hardware timer for AT parser ticks*/
    g_modem_timer.p_api->open(g_modem_timer.p_ctrl,g_modem_timer.p_cfg);
    g_modem_timer.p_api->start(g_modem_timer.p_ctrl);
}

/*Tick function for AT engine provided here*/
void g_modem_timer_callback(timer_callback_args_t * p_args)
{
    UNUSED(p_args);
    /*Execute AT parser tick function 10ms intervals*/
    SCP_Tick(10);
}

uint32_t uart_send_buff(uint8_t *data_out, uint32_t size)
{
    return g_sf_modem_uart0.p_api->write(g_sf_modem_uart0.p_ctrl, data_out, size, TX_WAIT_FOREVER);
}

uint32_t uart_read_byte(uint8_t *pData)
{
    return g_sf_modem_uart0.p_api->read(g_sf_modem_uart0.p_ctrl, pData, 1, TX_WAIT_FOREVER);
}

static void IncomingCall(const char *pString)
{
    UNUSED(pString);

    /*Hang up*/
    (void) SCP_SendCommandWaitAnswer("ATH\r", "OK", 200, 5);

    msg_sts = false;
}

static void GetAGPSLocation(const char *pString)
{

    uint8_t retry = 5;
    uint8_t i;
    char *result = NULL;

    /*Data arriving...*/
    modem_data.data_request = false;

    /*#AGPSRING: Received, wait for the end of the line to arrive..*/
    for(i = 0; i < retry; i++)
    {
        /* Wait 20ms */
        tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND/50));

        result = strchr(pString, '\r');

        if(result)
        {
            result = strchr(pString, ',');
            result++;
            if(result)
            {
                memset(modem_data.gps_latitude, 0x00, sizeof(modem_data.gps_latitude));
                strxcpy(modem_data.gps_latitude, result);
                result = strchr(result, ',');
                result++;

                if(result)
                {
                    memset(modem_data.gps_longitude, 0x00, sizeof(modem_data.gps_longitude));
                    strxcpy(modem_data.gps_longitude, result);
                    result = strchr(result, ',');
                    result++;

                    if(result)
                    {
                        memset(modem_data.gps_altitude, 0x00, sizeof(modem_data.gps_altitude));
                        strxcpy(modem_data.gps_altitude, result);
                        result = strchr(result, ',');
                        result++;

                        if(result)
                        {
                            memset(modem_data.gps_precision, 0x00, sizeof(modem_data.gps_precision));
                            strxcpy(modem_data.gps_precision, result);

                            /*Delete message*/
                            result = strstr(pString, "#AGPSRING");
                            memset(result, ' ', strlen("#AGPSRING"));
                            break;
                        }
                    }
                }
            }
        }
    }

    /*If we have main AGPS data we may block now*/
    if(strlen(modem_data.gps_latitude) != 0 && strlen(modem_data.gps_longitude) != 0 && strlen(modem_data.gps_precision) != 0 )
    {
        agps_block = true;
    }

}

/*Returns network registration status*/
static int32_t NetworkRegistrationCheck(void)
{
    char *result = NULL;
    int32_t ntwrk_stat = 0;

    /*Request network status info*/
    result = SCP_SendCommandWaitAnswer("AT+CREG?\r", "OK", 500, 5);

    if(result)
    {
        result = NULL;
        result = strstr((char*)SCPHandler.RxBuffer, "+CREG: ");
        if(result)
        {
            result += 9;
            ntwrk_stat = atoi(result);
        }
    }
    else
    {
        return 0;
    }

    return ntwrk_stat;
}

/*Returns GPRS status*/
static int32_t GPRS_StatusCheck(void)
{
    char *result = NULL;
    int32_t gprs_stat = 0;

    /*Request network status info*/
    result = SCP_SendCommandWaitAnswer("AT#SGACT?\r", "OK", 1000, 1);

    if(result)
    {
        result = NULL;
        result = strstr((char*)SCPHandler.RxBuffer, "#SGACT: ");
        if(result)
        {
            result += 10;
            gprs_stat = atoi(result);
        }
    }
    else
    {
        return 0;
    }

    return gprs_stat;
}

/*Connect GPRS, returns true and IP address if succeeded, must have 15 bytes allocated*/
static _Bool GPRS_Connect(char *ip_address)
{
    char *result = NULL;
    char *temp = NULL;

    temp = ip_address;

    /*Request network status info*/
    result = SCP_SendCommandWaitAnswer("AT#SGACT=1,1\r", "OK", 1000, 1);

    if(result)
    {
        result = NULL;
        result = strstr((char*)SCPHandler.RxBuffer, "#SGACT: ");
        result += 8;
        if(result)
        {
            memset(ip_address, 0x00, 15);

            /*Maximum 15 chars for IP address*/
            for(uint8_t i = 0; i < 15; i++)
            {
                /*Not a number or dot in IP address shall be treated as error*/
                if(!(*result > 47 && *result < 58) && !(*result == '.') && (!(*result == '\r')))
                {
                    memset(ip_address, 0x00, 15);
                    break;
                }

                *temp = *result;
                result++;
                temp++;

                /*The end of the string*/
                if(*result == '\r')
                {
                    break;
                }
            }

            return true;
        }
    }

    return false;
}

/*Waits for network available, suspends actual task*/
static void WaitForNetwork(void)
{
    int32_t test,temp = 0;

    /*Wait for network available*/
    while(!temp)
    {

        /*Get current network state*/
        test = NetworkRegistrationCheck();

        /*registered, home network  or  registered, roaming is acceptable*/
        if((test == 1) || (test == 5))
        {temp = test;}

        else
        {
            /* Wait 1000ms */
            tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND));
        }
    }
}

/*Returns ADC1 battery voltage*/
static int32_t MeasureBattVoltage(void)
{
    int32_t voltage_mv;
    char *result = NULL;

    /*Request ADC1*/
    result = SCP_SendCommandWaitAnswer("AT#ADC=1,2\r", "OK", 5000, 1);

    if(result)
    {
        result = NULL;
        result = strstr((char*)SCPHandler.RxBuffer, "#ADC:");
        if(result)
        {
            result += 6;
            voltage_mv = atoi(result);
            voltage_mv = (int32_t)(voltage_mv/TELIT_BATT_ADC_COEFF);
        }
    }
    else
    {
        return 0;
    }

    return voltage_mv;
}

/*Returns received signal quality in dBm*/
 int32_t SignalQualitydBm(void)
{
    int32_t signal_level;
    char *result = NULL;

    /*Request RSSI*/
    result = SCP_SendCommandWaitAnswer("AT+CSQ\r", "OK", 500, 1);

    if(result)
    {
        result = NULL;
        result = strstr((char*)SCPHandler.RxBuffer, "+CSQ:");
        if(result)
        {
            result += 6;
            signal_level = atoi(result);
            /*
              0 - (-113) dBm or less
              1 - (-111) dBm
              2..30 - (-109)dBm..(-53)dBm / 2 dBm per step
              31 - (-51)dBm or greater
              99 - not known or not detectable

             */

            /*Convert level to dBm*/
            if(signal_level == 0)
            {
                signal_level = -113;
            }
            else if (signal_level == 1)
            {
                signal_level = -111;
            }
            else if ((signal_level > 1) && (signal_level < 31))
            {
                signal_level = signal_level*2 - 113;
            }
            else if (signal_level == 31)
            {
                signal_level = -51;
            }
            else
            {
                signal_level = -2147483647;
            }
        }
    }
    else
    {
        return -2147483647;
    }

    return signal_level;
}

/*Returns received signal quality */
static int32_t SignalQuality(void)
{
    int32_t signal_level;
    char *result = NULL;

    /*Request RSSI*/
    result = SCP_SendCommandWaitAnswer("AT+CSQ\r", "OK", 500, 1);

    if(result)
    {
        result = NULL;
        result = strstr((char*)SCPHandler.RxBuffer, "+CSQ:");
        if(result)
        {
            result += 6;
            signal_level = atoi(result);
        }
    }
    else
    {
        return 0;
    }

    return signal_level;
}

/*Returns pointer to operator string*/
static char* GetOperator(void)
{
    char *result = NULL;
    static char operator[17];

    /*Request operator*/
    result = SCP_SendCommandWaitAnswer("AT+COPS?\r", "OK", 30000, 1);

    /*We have response, lets look for the info in the receiver buffer*/
    if(result)
    {
        result = NULL;
        result = strstr((char*)SCPHandler.RxBuffer, "+COPS:");

        /*Response found, lets look for operator string, begins with (") */
        if(result)
        {
            result = strchr(result, '"');

            /*Copy operator to the RAM and return*/
            if(result)
            {
                /*Clean static buffer*/
                memset(operator, 0x00, 17);

                /*Maximum 16 chars for operator initials allowed*/
                for(uint8_t i = 0; i < 16; i++)
                {
                    operator[i] = *result;
                    result++;

                    /*Last operator char?*/
                    if(*result == '"')
                    {
                        i++;
                        operator[i] = *result;
                        return operator;
                    }
                }

                return operator;
            }
        }
    }

    return NULL;
}

/*Returns pointer to IMEI string of 15 numbers*/
static char* GetIMEI(void)
{
    char *result = NULL;
    static char imei[16];
    _Bool isDigit = false;
    uint32_t j = 0, i=0;

    /*Request IMEI*/
    result = SCP_SendCommandWaitAnswer("AT+CGSN\r", "OK", 100, 1);

    /*We have response, lets look for the info in the receiver buffer*/
    if(result)
    {
        result = NULL;

        /*Lets look for a ASCII number...*/
        while((j < strlen((char*)SCPHandler.RxBuffer)) && (!isDigit))
        {
          if((SCPHandler.RxBuffer[j] > 47) && (SCPHandler.RxBuffer[j] < 58))
          {
              isDigit = true;
              result = (char*)&SCPHandler.RxBuffer[j];
              break;
          }

          j++;
        }

        /*First number of IMEI found, copy the number to the RAM and return */
        if(result)
        {
            memset(imei, 0x00, 16);

            /*Maximum 15 chars for IMEI is allowed*/
            for(i = 0; i < 15; i++)
            {
                /*Not a number in IMEI shall be treated as error*/
                if(!(*result > 47 && *result < 58))
                {
                    return NULL;
                }

                imei[i] = *result;

                result++;
            }

            return imei;
        }
    }

    return NULL;
}

/*Request model identification*/
static char* GetID(void)
{
    char *result = NULL;
    static char device_id[21];

    /*Request model identification*/
    result = SCP_SendCommandWaitAnswer("AT#CGMM\r", "OK", 100, 1);

    /*We have response, lets look for the info in the receiver buffer*/
    if(result)
    {
        result = NULL;
        result = strstr((char*)SCPHandler.RxBuffer, "#CGMM: ");

        if(result)
        {
            result += 7;

            /*Copy operator to the RAM and return*/
            memset(device_id, 0x00, 21);

            /*Maximum 20 chars for model identification allowed*/
            for(uint8_t i = 0; i < 20; i++)
            {
                device_id[i] = *result;
                result++;

                /*Device_id end*/
                if(*result == '\r')
                {
                    return device_id;
                }
            }
        }

    }

    return NULL;
}

/*Returns pointer to firmware version*/
static char* GetVersion(void)
{
    char *result = NULL;
    static char version[16];
    uint32_t i=0;

    /*Request IMEI*/
    result = SCP_SendCommandWaitAnswer("AT+CGMR\r", "OK", 100, 1);

    /*We have response, lets look for the info in the receiver buffer*/
    if(result)
    {
        result = NULL;

        /*Lets look for a (\n) char as the begining of firmware version string*/
        result = strchr((char*)SCPHandler.RxBuffer, '\n');

        /*Copy string to RAM */
        if(result)
        {
            result++;
            memset(version, 0x00, 16);

            /*Maximum 15 chars limit*/
            for(i = 0; i < 15; i++)
            {

                version[i] = *result;
                result++;

                if(*result == '\r')
                {
                    break;
                }
            }

            return version;
        }
    }

    return NULL;
}

/*Writes firmware version to given pointer, must have 50 bytes allocated*/
static _Bool GetGPSVersion(char *version)
{
    char *result = NULL;
    char *temp = NULL;

    temp = version;

    /*Request GPS module firmware version*/
    result = SCP_SendCommandWaitAnswer("AT$GPSSW\r", "OK", 30000, 1);

    if(result)
    {
        result = NULL;
        result = strstr((char*)SCPHandler.RxBuffer, "$GPSSW: ");
        result += 8;
        if(result)
        {
            memset(version, 0x00, 50);

            /*Maximum 49 chars for firmware version*/
            for(uint8_t i = 0; i < 49; i++)
            {
                *temp = *result;
                result++;
                temp++;

                /*The end of the string*/
                if(*result == '\r')
                {
                    break;
                }
            }

            return true;
        }
    }

    return false;
}

/*Read GPS properties*/
static _Bool GetGPSLocation( char *utc, char *date, char *lat, char *lon, char *alt, char *hdop, char *cog, char *speed, char *nsat)
{
    char *result = NULL;
    char *dir = NULL;
    double coordinate = 0;

    /*Request GPS data*/
    result = SCP_SendCommandWaitAnswer("AT$GPSACP\r", "OK", 100, 1);

    /*We have response, lets look for the info in the receiver buffer*/
    if(result)
    {
        result = NULL;
        result = strstr((char*)SCPHandler.RxBuffer, "$GPSACP: ");
        result +=9;
        if(result)
        {
            memset(utc, 0x00, strlen(utc));
            strxcpy(utc, result);

            result = strchr(result, ',');
            result++;
            if(result)
            {
                dir = strchr(result, 'N');
                if(!dir)
                {
                    dir = strchr(result, 'S');
                }
                coordinate = nmea2dec(result, 1, dir);
                memset(lat, 0x00, strlen(lat));
                sprintf(lat, "%.6f", coordinate);

                result = strchr(result, ',');
                result++;
                if(result)
                {
                    dir = strchr(result, 'E');
                    if(!dir)
                    {
                        dir = strchr(result, 'W');
                    }
                    coordinate = nmea2dec(result, 2, dir);
                    memset(lon, 0x00, strlen(lon));
                    sprintf(lon, "%.6f", coordinate);

                    result = strchr(result, ',');
                    result++;
                    if(result)
                    {
                        memset(hdop, 0x00, strlen(hdop));
                        strxcpy(hdop, result);

                        result = strchr(result, ',');
                        result++;
                        if(result)
                        {
                            memset(alt, 0x00, strlen(alt));
                            strxcpy(alt, result);

                            result = strchr(result, ',');
                            result++;

                            result = strchr(result, ',');
                            result++;
                            if(result)
                            {
                                memset(cog, 0x00, strlen(cog));
                                strxcpy(cog, result);

                                result = strchr(result, ',');
                                result++;
                                if(result)
                                {
                                    memset(speed, 0x00, strlen(speed));
                                    strxcpy(speed, result);

                                    result = strchr(result, ',');
                                    result++;

                                    result = strchr(result, ',');
                                    result++;
                                    if(result)
                                    {
                                        memset(date, 0x00, strlen(date));
                                        strxcpy(date, result);

                                        result = strchr(result, ',');
                                        result++;
                                        if(result)
                                        {
                                            memset(nsat, 0x00, strlen(nsat));
                                            strxcpy(nsat, result);
                                        }

                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    return false;
}

/*Request AGPS location*/
static _Bool RequestAGPSLocation(void)
{
    char *result = NULL;

    /*Request AGPS data*/
    result = SCP_SendCommandWaitAnswer("AT#AGPSSND\r", "OK", 120000, 1);

    /*We have response*/
    if(result)
    {
        return true;
    }


    return false;
}

static _Bool TelitPortalAuthenticate(void)
{
    char *result = NULL;
    memset(post_buff, 0, sizeof(post_buff));
    int i;

    /*Reset rx buffer for data reception*/
    SCP_InitRx();

    // form data to be posted
    sprintf(post_buff, fcmd_dW_auth, telit_appToken, telit_appID, modem_data.imei);

    // get data length
    sprintf(post_length, "%d\r\n\r\n", strlen(post_buff));

    // send http post header
    SCP_SendData((char *)fcmd_HTTPPOST, strlen(fcmd_HTTPPOST));

    // send data length
    SCP_SendData(post_length, strlen(post_length));

    // send post data
    SCP_SendData(post_buff, strlen(post_buff));

    // wait for full answer
    result = SCP_WaitForAnswer("}}}", 60000);
    if (result)
    {

        // find sessionID
        result = SCP_WaitForAnswer("sessionId\":\"", 60000);
        // getting session id
        result += strlen("sessionId\":\"");

        i=0;
        while ((*result != '\"')&& (i < SESSIONID_LENGTH))
        {
            telit_sessionId[i++]=*(result++);

        }
        if (i <= SESSIONID_LENGTH)
            return true;
    }
    return false;
}


static _Bool TelitPortalPostData(void)
{
    char *result = NULL;
    uint32_t len;
    memset(post_buff, 0, sizeof(post_buff));

    double temperature, humidity, pressure;
    uint32_t tms1142_xy_angle, mlx90393_xy_angle, tle439d_xy_angle, pwm_output_level;

    /*Copy variables that might to change during data post*/
    temperature = sensors_data.bme280_temperature;
    pressure = sensors_data.bme280_pressure;
    humidity = sensors_data.bme280_humidity;
    tms1142_xy_angle = sensors_data.tms1142_xy_angle;
    mlx90393_xy_angle = sensors_data.mlx90393_xy_angle;
    tle439d_xy_angle = sensors_data.tle439d_xy_angle;
    pwm_output_level = sensors_data.pwm_output_level;

    /*Correct rotation angles for preview*/
    tms1142_xy_angle = 360 - tms1142_xy_angle;
    mlx90393_xy_angle = 360 - mlx90393_xy_angle;
    tle439d_xy_angle = 360 - tle439d_xy_angle;

    /*Reset rx buffer for data reception*/
    SCP_InitRx();

    /*If we have no GPS data, we have to exclude them from post*/
    if(strlen(modem_data.gps_latitude) == 0 || strlen(modem_data.gps_longitude) == 0 || strlen(modem_data.gps_precision) == 0 )
    {
        len =  strlen(fcmd_dw_post_auth) - 2; // one parameter
        len += strlen(fcmd_dw_post_p1) - 4;  // two parameters
        len += strlen(fcmd_dw_post_p2) -4 ; // two parameters
        len += strlen(fcmd_dw_post_p3) - 4; // two parameters
        len += strlen(fcmd_dw_post_p4) -4 ; // two parameters
        len += strlen(fcmd_dw_post_p5) -4 ; // two parameters
        len += strlen(fcmd_dw_post_p6) -4 ; // two parameters
        len += strlen(fcmd_dw_post_p7) -4 ; // two parameters

        // calculate parameters length
        sprintf((char *)post_buff,"%s%s%s%s%s%s%s%s%d%d%d%d%d%d%d",
                telit_sessionId,
                modem_data.imei,
                modem_data.imei,
                modem_data.imei,
                modem_data.imei,
                modem_data.imei,
                modem_data.imei,
                modem_data.imei,
                (int)(temperature),
                (int)(pressure),
                (int)(humidity),
                (int)tms1142_xy_angle,
                (int)mlx90393_xy_angle,
                (int)tle439d_xy_angle,
                (int)pwm_output_level );

        len += strlen((char *)post_buff);

        // form the buffer with post header
        SCP_SendData((char *)fcmd_HTTPPOST, strlen(fcmd_HTTPPOST));
        sprintf((char *)post_buff,"%d\r\n\r\n", (int)len);

        SCP_SendData((char *)post_buff, strlen(post_buff));                                  // send to the cloud

        sprintf((char *)post_buff, fcmd_dw_post_auth, telit_sessionId);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        // post first line
        sprintf((char *)post_buff, fcmd_dw_post_p1, modem_data.imei, (int)temperature);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        // post second line
        sprintf((char *)post_buff, fcmd_dw_post_p2, modem_data.imei, (int)pressure);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        // post third line
        sprintf((char *)post_buff, fcmd_dw_post_p3, modem_data.imei, (int)humidity);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        // post fourth line
        sprintf((char *)post_buff, fcmd_dw_post_p4, modem_data.imei, (int)tms1142_xy_angle);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        sprintf((char *)post_buff, fcmd_dw_post_p5, modem_data.imei, (int)mlx90393_xy_angle);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        sprintf((char *)post_buff, fcmd_dw_post_p6, modem_data.imei, (int)tle439d_xy_angle);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        sprintf((char *)post_buff, fcmd_dw_post_p7, modem_data.imei, (int)pwm_output_level);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        SCP_SendData("\r\n", strlen("\r\n"));

        result = SCP_WaitForAnswer("}}", 60000);
        if (result)
        {
            return true;
        }
    }
    else
    {
        len =  strlen(fcmd_dw_post_auth) - 2; // one parameter
        len += strlen(fcmd_dw_post_p1) - 4;  // two parameters
        len += strlen(fcmd_dw_post_p2) -4 ; // two parameters
        len += strlen(fcmd_dw_post_p3) - 4; // two parameters
        len += strlen(fcmd_dw_post_p4) -4 ; // two parameters
        len += strlen(fcmd_dw_post_p5) -4 ; // two parameters
        len += strlen(fcmd_dw_post_p6) -4 ; // two parameters
        len += strlen(fcmd_dw_post_p7) -4 ; // two parameters
        len += strlen(fcmd_dw_post_p8) -8;  // four parameters

        // calculate parameters length
        sprintf((char *)post_buff,"%s%s%s%s%s%s%s%s%d%d%d%d%d%d%d%s%s%s%s",
                telit_sessionId,
                modem_data.imei,
                modem_data.imei,
                modem_data.imei,
                modem_data.imei,
                modem_data.imei,
                modem_data.imei,
                modem_data.imei,
                (int)(temperature),
                (int)(pressure),
                (int)(humidity),
                (int)tms1142_xy_angle,
                (int)mlx90393_xy_angle,
                (int)tle439d_xy_angle,
                (int)pwm_output_level,
                modem_data.imei,
                modem_data.gps_latitude,
                modem_data.gps_longitude,
                modem_data.gps_precision);

        len += strlen((char *)post_buff);

        // form the buffer with post header
        SCP_SendData((char *)fcmd_HTTPPOST, strlen(fcmd_HTTPPOST));
        sprintf((char *)post_buff,"%d\r\n\r\n", (int)len);

        SCP_SendData((char *)post_buff, strlen(post_buff));                                  // send to the cloud

        sprintf((char *)post_buff, fcmd_dw_post_auth, telit_sessionId);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        // post first line
        sprintf((char *)post_buff, fcmd_dw_post_p1, modem_data.imei, (int)temperature);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        // post second line
        sprintf((char *)post_buff, fcmd_dw_post_p2, modem_data.imei, (int)pressure);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        // post third line
        sprintf((char *)post_buff, fcmd_dw_post_p3, modem_data.imei, (int)humidity);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        // post fourth line
        sprintf((char *)post_buff, fcmd_dw_post_p4, modem_data.imei, (int)tms1142_xy_angle);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        sprintf((char *)post_buff, fcmd_dw_post_p5, modem_data.imei, (int)mlx90393_xy_angle);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        sprintf((char *)post_buff, fcmd_dw_post_p6, modem_data.imei, (int)tle439d_xy_angle);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        sprintf((char *)post_buff, fcmd_dw_post_p7, modem_data.imei, (int)pwm_output_level);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        sprintf((char *)post_buff, fcmd_dw_post_p8, modem_data.imei, modem_data.gps_latitude, modem_data.gps_longitude, modem_data.gps_precision);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        result = SCP_WaitForAnswer("}}", 60000);
        if (result)
        {
            return true;
        }
    }


    /*Timeout. In case of error, no }} received*/
    return false;
}


/*Open socket to address*/
static _Bool ModemOpenTcpSocket(char *pAddress, uint32_t port)
{
    char *result = NULL;
    memset(post_buff, 0, sizeof(post_buff));
    // form open socket command
    sprintf(post_buff, "AT#SD=1,0,%d,\"%s\"\r", (int)port, pAddress);
    result = SCP_SendCommandWaitAnswer(post_buff, "CONNECT", 60000, 1);

    if(result)
    {
        return true;
    }

    return false;
}

/*Provider change procedure*/
static _Bool ChangeProvider(void)
{
    char *result = NULL;
    char provider[17];

    /* Set the behavior of +COPS command */
   // result = SCP_SendCommandWaitAnswer("AT#COPSMODE=1\r", "OK", 30000, 1);

    /* Send command to check what networks are available */
    result = SCP_SendCommandWaitAnswer("AT+COPS=?\r", "OK", 30000, 1);

    /*We have response, lets look for the info in the receiver buffer*/
    if(result)
    {
        result = NULL;
        result = strstr((char*)SCPHandler.RxBuffer, "+COPS:");
        if(result)
        {
            for(;;)
            {
                search:
                result = strchr(result, '(');
                if(result)
                {
                    result +=1;
                    if(*result == '1')
                    {
                        /*Provider found, copy the name*/
                        result = strchr(result, '"');

                        if(result)
                        {
                            /*Clean buffer*/
                            memset(provider, 0x00, 17);

                            /*Maximum 16 chars for operator initials allowed*/
                            for(uint8_t i = 0; i < 16; i++)
                            {
                                provider[i] = *result;
                                result++;

                                /*Last operator char?*/
                                if(*result == '"')
                                {
                                    i++;
                                    provider[i] = *result;

                                    /*Form command*/
                                    memset(post_buff, 0, sizeof(post_buff));
                                    sprintf(post_buff, "AT+COPS=1,0,%s\r",provider);
                                    result = SCP_SendCommandWaitAnswer(post_buff, "OK", 10000, 1);
                                    if(result)
                                    {
                                        return true;
                                    }
                                    else
                                    {
                                        return false;
                                    }
                                }
                            }

                        }

                        else
                        {
                            return false;
                        }
                    }
                    else
                    {
                        goto search;
                    }
                }
                else
                {
                    break;
                }

            }
        }

    }

    return false;
}

/* Modem Thread entry function */
void modem_thread_entry(void)
{
    char * scp_result = NULL;
    static uint32_t mod_time_counter = 0;
    static uint32_t agps_time_counter = 0;
    static uint32_t cloud_time_counter = 0;
    static uint32_t previous_pwm = 0;
    static uint32_t sms_time_counter = 0;
    static uint32_t gprs_recon_counter = 0;
    static _Bool authenticated = false;
    char temp_buff[20];
    _Bool temp_result = false;


    /*Apply power for GSM and GNSS modules*/
    ModemOn();
    GNSS_On();
    Charger_On();

    /*Wait 1000ms for modem to be ready*/
    tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND));
    modem_data.gsm_pwr_status = true;
    modem_data.gnss_pwr_status = true;
    modem_data.charger_pwr_status = true;

    /*GSM and GNSS initialisation*/
    GSM_init();

    /*AT parser initialisation*/
    SCP_Init(uart_send_buff, uart_read_byte);

    /*AT CaLlbacks Register*/
    SCP_AddCallback("RING\r\n", IncomingCall);
    SCP_AddCallback("#AGPSRING:", GetAGPSLocation);

    /*Wait 1000ms for modem to be ready*/
    tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND));

    /*Try AT command*/
    scp_result = SCP_SendCommandWaitAnswer("AT\r\n", "OK", 100, 5);

    /*Echo commands turn off*/
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("ATE0\r\n", "OK", 500, 1);

    /*Set provider to default*/
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("AT+COPS=0\r\n", "OK", 500, 1);

    /*eSIM card removed and switched to Nano SIM card */
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("AT#SIMDET=0\r", "OK", 500, 1);
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("AT#GPIO=4,1,1\r", "OK", 500, 1);
    /*Wait 1000ms*/
    tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND));
    /*Nano SIM card present*/
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("AT#SIMDET=1\r", "OK", 500, 1);
    /*Wait 1000ms for modem to be ready*/
    tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND));

    /*Get IMEI*/
    scp_result = NULL;
    scp_result = GetIMEI();
    if(scp_result)
    {
        memset(modem_data.imei, 0x00, 16);
        strcpy(modem_data.imei, scp_result);
    }

    /*Get module type*/
    scp_result = NULL;
    scp_result = GetID();
    if(scp_result)
    {
        memset(modem_data.device_name, 0x00, 21);
        strcpy(modem_data.device_name, scp_result);
    }

    /*Get firmware version*/
    scp_result = NULL;
    scp_result = GetVersion();
    if(scp_result)
    {
        memset(modem_data.fw_version, 0x00, 16);
        strcpy(modem_data.fw_version, scp_result);
    }

    /*Wait 3000ms for gnss to be ready*/
    tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND*3));
    /*Get GPS firmware version*/
    GetGPSVersion(modem_data.gps_sw_version);

    /*Set APN*/
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("AT+CGDCONT=1,\"IP\",\"nxt17.net\"\r", "OK", 500, 1);

    /*Message format = text mode*/
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("AT+CMGF=1\r", "OK", 100, 1);

    /*Check if we are connected to GSM network*/
    WaitForNetwork();

    while (1)
    {
        /* Wait 200ms */
        tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND/5));

        /*Look for URC (Unsolicited Result Code)*/
        SCP_Process();

        mod_time_counter++;
        agps_time_counter++;
        sms_time_counter++;
        cloud_time_counter++;

        /*Check if we have to upload to cloud ASAP*/
        if(abs((int)(previous_pwm - sensors_data.pwm_output_level)) > 5 )
        {
            /*Save output level*/
            /* Wait 2000ms */
            tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND*2));
            previous_pwm = sensors_data.pwm_output_level;
            /*Will upload ASAP*/
            cloud_time_counter = TELIT_CLOUD_UPDATE_INTERVAL;
        }

        /*Gather modem & GPS data occasionally*/
        if(mod_time_counter >= MODEM_DATA_REQUEST_INTERVAL)
        {
            /*If waiting for the data from modem do not execute commands*/
            if(!modem_data.data_request)
            {
                /*Reset counter now*/
                mod_time_counter = 0;

                /*Store signal quality*/
                modem_data.signal = SignalQuality();

                /*Battery voltage*/
                modem_data.batt_voltage_mv = MeasureBattVoltage();

                /*Network Status*/
                modem_data.network_status = NetworkRegistrationCheck();

                /*registered to home network or registered as roaming is acceptable*/
                if((modem_data.network_status == 1) || (modem_data.network_status == 5))
                {
                    /*Store operator*/
                    scp_result = NULL;
                    scp_result = GetOperator();
                    if(scp_result)
                    {
                        memset(modem_data.operator, 0x00, 17);
                        strcpy(modem_data.operator, scp_result);
                    }

                    /*Check GPRS status*/
                    modem_data.gprs_status = GPRS_StatusCheck();

                    /*Try to connect if not connected*/
                    if(!modem_data.gprs_status)
                    {
                        modem_data.gprs_status = GPRS_Connect(modem_data.ip_address);

                        /*Count how many times tried to connect*/
                        if(!modem_data.gprs_status)
                        {
                            gprs_recon_counter++;
                        }
                        else
                        {
                            gprs_recon_counter = 0;
                        }

                        /*Roaming an no GPRS, retry few times and try to change network*/
                        if(!modem_data.gprs_status && (modem_data.network_status == 5) && (gprs_recon_counter >= GPRS_CONNECT_RETRY))
                        {
                            /*reset counter*/
                            gprs_recon_counter = 0;

                            /*change provider*/
                            if(ChangeProvider())
                            {
                                /*Check if we are connected to GSM network*/
                                WaitForNetwork();
                            }
                        }
                    }
                }

                /*Gather GPS data */
                if(USE_GPS)
                {
                  char temp_utc[16];
                  char temp_dat[16];
                  char temp_lat[16];
                  char temp_lon[16];
                  char temp_alt[16];
                  char temp_pre[16];
                  char temp_cou[16];
                  char temp_spe[16];
                  char temp_nsa[16];
                  modem_data.gnss_online = GetGPSLocation
                                                           (
                                                                   temp_utc,
                                                                   temp_dat,
                                                                   temp_lat,
                                                                   temp_lon,
                                                                   temp_alt,
                                                                   temp_pre,
                                                                   temp_cou,
                                                                   temp_spe,
                                                                   temp_nsa
                                                            );
                    if((atoi(temp_nsa) > 3) && modem_data.gnss_online)
                    {
                        strcpy(modem_data.gps_utc, temp_utc);
                        strcpy(modem_data.gps_date, temp_dat);
                        strcpy(modem_data.gps_latitude, temp_lat);
                        strcpy(modem_data.gps_longitude, temp_lon);
                        strcpy(modem_data.gps_altitude, temp_alt);
                        strcpy(modem_data.gps_precision, temp_pre);
                        strcpy(modem_data.gps_course, temp_cou);
                        strcpy(modem_data.gps_speed, temp_spe);
                        strcpy(modem_data.gps_satt_in_use, temp_nsa);

                    }
                }
            }
        }

        /*Request AGPS data*/
        if(agps_time_counter >= AGPS_DATA_REQUEST_INTERVAL)
        {
            /*AGPS requests may be blocked on purpose*/
            if(!agps_block)
            {
                /*If not waiting for any data to receive*/
                if(!modem_data.data_request)
                {
                    /*Reset counter now*/
                    agps_time_counter = 0;

                    if(USE_AGPS)
                    {
                        /*Try AGPS only if connected GPRS and we have less than 4 satellites from GNSS module*/
                        if(modem_data.gprs_status && atoi(modem_data.gps_satt_in_use) < 4)
                        {
                            _Bool status = false;
                            status = RequestAGPSLocation();
                            if(status)
                            {
                                /*Block commands, Wait for data*/
                                modem_data.data_request = true;
                            }
                        }
                    }
                }
            }

        }

        /*Upload to Telit Cloud*/
        if(cloud_time_counter >= TELIT_CLOUD_UPDATE_INTERVAL)
        {
            /*If not waiting for any data to receive*/
            if(!modem_data.data_request)
            {
                if(UPLOAD_CLOUD)
                {
                    /*If we have GPRS connection...*/
                    if (modem_data.gprs_status)
                    {
                        /*Reset counter now*/
                        cloud_time_counter = 0;

                        /*Authenticate only once per session*/
                        if(!authenticated)
                        {
                            /*Authentication*/
                            temp_result = ModemOpenTcpSocket("api-de.devicewise.com", 80);
                            if(temp_result)
                            {
                                authenticated = TelitPortalAuthenticate();
                            }
                        }
                        else
                        {
                            /*Post*/
                            temp_result = ModemOpenTcpSocket("api-de.devicewise.com", 80);
                            if (temp_result)
                            {
                                /*If post fails try to authenticate again*/
                                authenticated = TelitPortalPostData();
                            }
                            else
                            {
                                authenticated = false;
                            }
                        }
                     }
                }
            }
        }

        /*Send data via SMS*/
        if(sms_time_counter >= MSG_SEND_INTERVAL)
        {
            char * result = NULL;
            static char temp = 0;

            /*Do not interrupt if other process requested data*/
            if(!modem_data.data_request)
            {
                sms_time_counter = 0;

                if(!msg_sts)
                {
                    memset(g_sms_buff, 0x00, sizeof(g_sms_buff));

                    /*
                    strcpy(g_sms_buff, modem_data.operator);

                    strcat(g_sms_buff, ", ");
                    */

                    strcat(g_sms_buff, modem_data.gps_latitude);

                    strcat(g_sms_buff, ", ");

                    strcat(g_sms_buff, modem_data.gps_longitude);

                    strcat(g_sms_buff, ", ");

                    memset(temp_buff, 0x00, sizeof(temp_buff));
                    sprintf(temp_buff, "%d", (int)sensors_data.bme280_temperature);
                    strcat(temp_buff, "C, ");
                    strcat(g_sms_buff, temp_buff);

                    memset(temp_buff, 0x00, sizeof(temp_buff));
                    sprintf(temp_buff, "%d", (int)sensors_data.bme280_pressure);
                    strcat(temp_buff, "kPa, ");
                    strcat(g_sms_buff, temp_buff);

                    memset(temp_buff, 0x00, sizeof(temp_buff));
                    sprintf(temp_buff, "%d", (int)sensors_data.bme280_humidity);
                    strcat(temp_buff, "% ");
                    strcat(g_sms_buff, temp_buff);

                    temp = 0x1A;
                    strcat(g_sms_buff, &temp);

                    temp = '>';

                    result = SCP_SendDoubleCommandWaitAnswer("AT+CMGS=+37062395356\r\n", g_sms_buff, &temp, "OK", 5000, 1);
                    if(result)
                    {
                        msg_sts = true;
                    }
                }
            }

        }
    }
}
