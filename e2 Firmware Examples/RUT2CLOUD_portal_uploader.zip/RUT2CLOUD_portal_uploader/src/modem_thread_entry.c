#include "modem_thread.h"
#include "common.h"
#include "config_s3a7.h"
#include "uart0_receive_thread.h"
#include "StringCommandParser.h"
#include "stdlib.h"
#include "stdio.h"
#include "util.h"
#include "math.h"

#define MAX_LONGITUDE               180
#define MAX_LATITUDE                90
#define CMD_BUFF_LENGTH             1024
#define SESSIONID_LENGTH            24
#define TELIT_BATT_ADC_COEFF        0.281       /*"Telit ADC1" battery voltage divider ratio*/
#define MODEM_DATA_REQUEST_INTERVAL 100 /*time interval for modem properties*/
#define TELIT_CLOUD_UPDATE_INTERVAL 600 /*time interval for modem properties*/
#define USE_GNSS                    1
#define UPLOAD_CLOUD                1
#define SEND_SMS                    0
#define GPRS_CONNECT_RETRY          5 //GPRS connect attemptions
#define SHUT_DOWN_VOLTAGE           3333 /*System shut down voltage mV for battery saving/protection*/

/* LED type structure */
bsp_leds_t leds;

/*Modem and GNSS Power and Reset control pins*/
ioport_port_pin_t cell_reset = CELL_RESET_CTRL_PIN;
ioport_port_pin_t gnss_reset = GNSS_RESET_CTRL_PIN;
ioport_port_pin_t cell_pwr = CELL_POWER_CTRL_PIN;
ioport_port_pin_t gnss_pwr = GNSS_POWER_CTRL_PIN;
ioport_port_pin_t charger_ctrl = CHARGER_CTRL_PIN;

/*Telit Portal Authentication Templates*/
const char fcmd_HTTPPOST[] ="POST /api HTTP/1.0\r\nHost: api-de.devicewise.com\r\nContent-Type: application/json\r\nContent-Length:";
const char fcmd_dW_auth[]  = "{\"auth\":{\"command\":\"api.authenticate\",\"params\":{\"appToken\":\"%s\",\"appId\":\"%s\",\"thingKey\":\"%s\"}}}\r\n";
const char fcmd_dw_post_auth[]  = "{\"auth\":{\"sessionId\":\"%s\"},";

/*Telit Portal Post Templates*/
const char fcmd_dw_post_p1[]  = "\"1\":{\"command\":\"property.publish\",\"params\":{\"thingKey\":\"%s\",\"key\":\"temperature\",\"value\":%.2f}},";
const char fcmd_dw_post_p2[]  = "\"2\":{\"command\":\"property.publish\",\"params\":{\"thingKey\":\"%s\",\"key\":\"pressure\",\"value\":%.2f}},";
const char fcmd_dw_post_p3[]  = "\"3\":{\"command\":\"property.publish\",\"params\":{\"thingKey\":\"%s\",\"key\":\"humidity\",\"value\":%.2f}},";
const char fcmd_dw_post_p4[]  = "\"4\":{\"command\":\"property.publish\",\"params\":{\"thingKey\":\"%s\",\"key\":\"mag_xy\",\"value\":%d}},";
const char fcmd_dw_post_p5[]  = "\"5\":{\"command\":\"property.publish\",\"params\":{\"thingKey\":\"%s\",\"key\":\"batt_voltage\",\"value\":%d}},";
const char fcmd_dw_post_p6[]  = "\"6\":{\"command\":\"property.publish\",\"params\":{\"thingKey\":\"%s\",\"key\":\"signal_level\",\"value\":%d}},";
const char fcmd_dw_post_p7[]  = "\"7\":{\"command\":\"location.publish\",\"params\":{\"thingKey\":\"%s\",\"lat\":%s,\"lng\":%s,\"altitude\":%s,\"heading\":%s,\"speed\":%s,\"fixType\":\"manual\",\"fixAcc\":%s}}}}\r\n";

/*App ID and tokens*/
const char telit_appID[] = "xxx";
const char telit_appToken[] = "yyy";
char telit_sessionId[25];

char g_sms_buff[100];
char incoming_number[20];
extern sensors_data_storage_t sensors_data;
char post_buff[CMD_BUFF_LENGTH];
char post_length[16];
extern TSCPHandler   SCPHandler;
static _Bool msg_sts = false;

/*Sensors data structure initial values*/
modem_data_storage_t modem_data =
{
 .gsm_pwr_status = false,
 .gnss_pwr_status = false,
 .charger_pwr_status = false,
 .gprs_status = false,
 .batt_voltage_mv = 0,
 .signal = 0,
 .gnss_online = false,
};

int32_t SignalQualitydBm(void);

/*Specific string copy function*/
static void strxcpy(char *dest, char *src)
{
    int limit;

    limit = 10;

    while(((*src >= '0') && (*src <= '9')) || (*src == '.') )
    {
        while(*src == ' ')
        {
            src++;
            limit--;

            if(limit <= 0)
            {
                break;
            }
        }

        *dest = *src;
        dest++;
        src++;
        limit--;

        if(limit <= 0)
        {
            break;
        }
    }
}

/*Convert latitude and longitude from NMEA to decimal */
static double nmea2dec(char *nmea, char type, char *dir)
{
    unsigned int idx, dot = 0;
    double dec = 0;
    for (idx=0; idx<strlen(nmea);idx++){
        if (nmea[idx] == '.')
        {
            dot = idx;
            break;
        }
    }

    if ((dot < 3) || (dot > 5))
    {
        return 0;
    }

    int dd;
    double mm;
    char cdd[5], cmm[10];
    memset(cdd, 0, sizeof(cdd));
    memset(cmm, 0, sizeof(cmm));
    if(type == 1)
    {
        strncpy(cdd, nmea, dot-2);
        strncpy(cmm, nmea+dot-2, 7);
    }
    if(type == 2)
    {
        strncpy(cdd, nmea, dot-2);
        strncpy(cmm, nmea+dot-2, 7);
    }

    dd = atoi(cdd);
    mm = atof(cmm);

    dec = dd + (mm/60);

    if (type == 1 && dec > MAX_LATITUDE)
        return 0;
    else if (type == 2 && dec > MAX_LONGITUDE)
        return 0;

    if (*dir == 'N' || *dir == 'E')
      return dec;
    else
      return -1 * dec;
}

static inline void ModemReset(void)
{
    /*Turn on Reset MOSFET*/
    g_ioport.p_api->pinWrite(cell_reset, IOPORT_LEVEL_HIGH);

    /*Keep it on for a 200ms as required*/
    tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND/5));


    /*Turn off Reset MOSFET*/
    g_ioport.p_api->pinWrite(cell_reset, IOPORT_LEVEL_LOW);

    /*wait for a 1000ms as required*/
    tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND));
}

static inline void ModemOn(void)
{
    /*Turn on power for GSM Modem*/
    g_ioport.p_api->pinWrite(cell_pwr, IOPORT_LEVEL_HIGH);
}

static inline void ModemOff(void)
{
    /*Turn off power for GSM Modem*/
    g_ioport.p_api->pinWrite(cell_pwr, IOPORT_LEVEL_LOW);
}

static inline void GNSS_On(void)
{
    /*Turn on power for GNSS module*/
    g_ioport.p_api->pinWrite(gnss_pwr, IOPORT_LEVEL_HIGH);
}

static inline void GNSS_Off(void)
{
    /*Turn off power for GNSS module*/
    g_ioport.p_api->pinWrite(gnss_pwr, IOPORT_LEVEL_LOW);
}

static inline void Charger_On(void)
{
    /*Turn on Li-ion Battery Charger*/
    g_ioport.p_api->pinWrite(charger_ctrl, IOPORT_LEVEL_LOW);
}

static inline void Charger_Off(void)
{
    /*Turn off Li-ion Battery Charger*/
    g_ioport.p_api->pinWrite(charger_ctrl, IOPORT_LEVEL_HIGH);
}

static void GSM_init( void )
{
    /*Release reset pins*/
    g_ioport.p_api->pinWrite(cell_reset, IOPORT_LEVEL_LOW);
    g_ioport.p_api->pinWrite(gnss_reset, IOPORT_LEVEL_LOW);

    /*Reset the Modem*/
    ModemReset();

    /*Open and start hardware timer for AT parser ticks*/
    g_modem_timer.p_api->open(g_modem_timer.p_ctrl,g_modem_timer.p_cfg);
    g_modem_timer.p_api->start(g_modem_timer.p_ctrl);

    /*Configure Low Power Mode*/
    g_lpmv2_standby0.p_api->lowPowerCfg(g_lpmv2_standby0.p_cfg);

    /*Configure RTC*/
    g_rtc0.p_api->open(g_rtc0.p_ctrl,g_rtc0.p_cfg);
}

/*Tick function for AT engine provided here*/
void g_modem_timer_callback(timer_callback_args_t * p_args)
{
    UNUSED(p_args);
    /*Execute AT parser tick function 10ms intervals*/
    SCP_Tick(10);
}

uint32_t uart_send_buff(uint8_t *data_out, uint32_t size)
{
    return g_sf_modem_uart0.p_api->write(g_sf_modem_uart0.p_ctrl, data_out, size, TX_WAIT_FOREVER);
}

uint32_t uart_read_byte(uint8_t *pData)
{
    return g_sf_modem_uart0.p_api->read(g_sf_modem_uart0.p_ctrl, pData, 1, TX_WAIT_FOREVER);
}

/*Incoming Call Function*/
static void IncomingCall(const char *pString)
{
    UNUSED(pString);
    char *result = NULL;

    /* Wait 50ms */
    tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND/20));

      /**/
      result = strstr((char*)SCPHandler.RxBuffer, "+CLIP: ");
      /*Response found, lets look for operator string, begins with (") */
      if(result)
      {
          result = strchr(result, '"');

          /*Copy operator to the RAM and return*/
          if(result)
          {
              /*Prepare to save the callers number*/
              memset(incoming_number, 0x00, sizeof(incoming_number));

              /*Save callers number*/
              for(uint8_t i = 0; i < sizeof(incoming_number); i++)
              {
                  incoming_number[i] = *result;
                  result++;

                  /*Last operator char?*/
                  if(*result == '"')
                  {
                      i++;
                      incoming_number[i] = *result;
                      break;
                  }
              }
          }
      }

      if(SEND_SMS)
      {
          /*Request to send SMS ASAP*/
          msg_sts = true;
      }

      else
      {
          /*Hang up*/
          (void) SCP_SendCommandWaitAnswer("ATH\r", "OK", 2000, 1);
      }

}

/*Returns network registration status*/
static int32_t NetworkRegistrationCheck(void)
{
    char *result = NULL;
    int32_t ntwrk_stat = 0;

    /*Request network status info*/
    result = SCP_SendCommandWaitAnswer("AT+CREG?\r", "OK", 2000, 1);

    if(result)
    {
        result = NULL;
        result = strstr((char*)SCPHandler.RxBuffer, "+CREG: ");
        if(result)
        {
            result += 9;
            ntwrk_stat = atoi(result);
        }
    }
    else
    {
        return 0;
    }

    return ntwrk_stat;
}

/*Returns GPRS status*/
static int32_t GPRS_StatusCheck(void)
{
    char *result = NULL;
    int32_t gprs_stat = 0;

    /*Request network status info*/
    result = SCP_SendCommandWaitAnswer("AT#SGACT?\r", "OK", 2000, 1);

    if(result)
    {
        result = NULL;
        result = strstr((char*)SCPHandler.RxBuffer, "#SGACT: ");
        if(result)
        {
            result += 10;
            gprs_stat = atoi(result);
        }
    }
    else
    {
        return 0;
    }

    return gprs_stat;
}

/*Connect GPRS, returns true and IP address if succeeded, must have 15 bytes allocated*/
static _Bool GPRS_Connect(char *ip_address)
{
    char *result = NULL;
    char *temp = NULL;

    temp = ip_address;

    /*Request network status info*/
    result = SCP_SendCommandWaitAnswer("AT#SGACT=1,1\r", "OK", 2000, 1);

    if(result)
    {
        result = NULL;
        result = strstr((char*)SCPHandler.RxBuffer, "#SGACT: ");
        result += 8;
        if(result)
        {
            memset(ip_address, 0x00, 15);

            /*Maximum 15 chars for IP address*/
            for(uint8_t i = 0; i < 15; i++)
            {
                /*Not a number or dot in IP address shall be treated as error*/
                if(!(*result > 47 && *result < 58) && !(*result == '.') && (!(*result == '\r')))
                {
                    memset(ip_address, 0x00, 15);
                    break;
                }

                *temp = *result;
                result++;
                temp++;

                /*The end of the string*/
                if(*result == '\r')
                {
                    break;
                }
            }

            return true;
        }
    }

    return false;
}

/*Waits for network available, suspends actual task*/
static void WaitForNetwork(void)
{
    int32_t test,temp = 0;

    /*Wait for network available*/
    while(!temp)
    {

        /*Get current network state*/
        test = NetworkRegistrationCheck();

        /*registered, home network  or  registered, roaming is acceptable*/
        if((test == 1) || (test == 5))
        {temp = test;}

        else
        {
            /* Wait 1000ms */
            tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND));
        }
    }
}

/*Returns ADC1 battery voltage*/
static int32_t MeasureBattVoltage(void)
{
    int32_t voltage_mv = 0;
    char *result = NULL;

    /*Request ADC1*/
    result = SCP_SendCommandWaitAnswer("AT#ADC=1,2\r", "OK", 5000, 1);

    if(result)
    {
        result = NULL;
        result = strstr((char*)SCPHandler.RxBuffer, "#ADC:");
        if(result)
        {
            result += 6;
            voltage_mv = atoi(result);
            voltage_mv = (int32_t)(voltage_mv/TELIT_BATT_ADC_COEFF);
        }
    }
    else
    {
        return 0;
    }

    return voltage_mv;
}

/*Returns received signal quality in dBm*/
 int32_t SignalQualitydBm(void)
{
    int32_t signal_level = 0;
    char *result = NULL;

    /*Request RSSI*/
    result = SCP_SendCommandWaitAnswer("AT+CSQ\r", "OK", 500, 1);

    if(result)
    {
        result = NULL;
        result = strstr((char*)SCPHandler.RxBuffer, "+CSQ:");
        if(result)
        {
            result += 6;
            signal_level = atoi(result);
            /*
              0 - (-113) dBm or less
              1 - (-111) dBm
              2..30 - (-109)dBm..(-53)dBm / 2 dBm per step
              31 - (-51)dBm or greater
              99 - not known or not detectable

             */

            /*Convert level to dBm*/
            if(signal_level == 0)
            {
                signal_level = -113;
            }
            else if (signal_level == 1)
            {
                signal_level = -111;
            }
            else if ((signal_level > 1) && (signal_level < 31))
            {
                signal_level = signal_level*2 - 113;
            }
            else if (signal_level == 31)
            {
                signal_level = -51;
            }
            else
            {
                signal_level = -2147483647;
            }
        }
    }
    else
    {
        return -2147483647;
    }

    return signal_level;
}

/*Returns received signal quality */
static int32_t SignalQuality(void)
{
    int32_t signal_level = 0;
    char *result = NULL;

    /*Request RSSI*/
    result = SCP_SendCommandWaitAnswer("AT+CSQ\r", "OK", 2000, 1);

    if(result)
    {
        result = NULL;
        result = strstr((char*)SCPHandler.RxBuffer, "+CSQ:");
        if(result)
        {
            result += 6;
            signal_level = atoi(result);
        }
    }
    else
    {
        return 0;
    }

    return signal_level;
}

/*Returns pointer to operator string*/
static char* GetOperator(void)
{
    char *result = NULL;
    static char operator[17];

    /*Request operator*/
    result = SCP_SendCommandWaitAnswer("AT+COPS?\r", "OK", 60000, 1);

    /*We have response, lets look for the info in the receiver buffer*/
    if(result)
    {
        result = NULL;
        result = strstr((char*)SCPHandler.RxBuffer, "+COPS:");

        /*Response found, lets look for operator string, begins with (") */
        if(result)
        {
            result = strchr(result, '"');

            /*Copy operator to the RAM and return*/
            if(result)
            {
                /*Clean static buffer*/
                memset(operator, 0x00, 17);

                /*Maximum 16 chars for operator initials allowed*/
                for(uint8_t i = 0; i < 16; i++)
                {
                    operator[i] = *result;
                    result++;

                    /*Last operator char?*/
                    if(*result == '"')
                    {
                        i++;
                        operator[i] = *result;
                        return operator;
                    }
                }

                return operator;
            }
        }
    }

    return NULL;
}

/*Returns pointer to IMEI string of 15 numbers*/
static char* GetIMEI(void)
{
    char *result = NULL;
    static char imei[16];
    _Bool isDigit = false;
    uint32_t j = 0, i=0;

    /*Request IMEI*/
    result = SCP_SendCommandWaitAnswer("AT+CGSN\r", "OK", 100, 1);

    /*We have response, lets look for the info in the receiver buffer*/
    if(result)
    {
        result = NULL;

        /*Lets look for a ASCII number...*/
        while((j < strlen((char*)SCPHandler.RxBuffer)) && (!isDigit))
        {
          if((SCPHandler.RxBuffer[j] > 47) && (SCPHandler.RxBuffer[j] < 58))
          {
              isDigit = true;
              result = (char*)&SCPHandler.RxBuffer[j];
              break;
          }

          j++;
        }

        /*First number of IMEI found, copy the number to the RAM and return */
        if(result)
        {
            memset(imei, 0x00, 16);

            /*Maximum 15 chars for IMEI is allowed*/
            for(i = 0; i < 15; i++)
            {
                /*Not a number in IMEI shall be treated as error*/
                if(!(*result > 47 && *result < 58))
                {
                    return NULL;
                }

                imei[i] = *result;

                result++;
            }

            return imei;
        }
    }

    return NULL;
}

/*Request model identification*/
static char* GetID(void)
{
    char *result = NULL;
    static char device_id[21];

    /*Request model identification*/
    result = SCP_SendCommandWaitAnswer("AT#CGMM\r", "OK", 100, 1);

    /*We have response, lets look for the info in the receiver buffer*/
    if(result)
    {
        result = NULL;
        result = strstr((char*)SCPHandler.RxBuffer, "#CGMM: ");

        if(result)
        {
            result += 7;

            /*Copy operator to the RAM and return*/
            memset(device_id, 0x00, 21);

            /*Maximum 20 chars for model identification allowed*/
            for(uint8_t i = 0; i < 20; i++)
            {
                device_id[i] = *result;
                result++;

                /*Device_id end*/
                if(*result == '\r')
                {
                    return device_id;
                }
            }
        }

    }

    return NULL;
}

/*Returns pointer to firmware version*/
static char* GetVersion(void)
{
    char *result = NULL;
    static char version[16];
    uint32_t i=0;

    /*Request IMEI*/
    result = SCP_SendCommandWaitAnswer("AT+CGMR\r", "OK", 100, 1);

    /*We have response, lets look for the info in the receiver buffer*/
    if(result)
    {
        result = NULL;

        /*Lets look for a (\n) char as the begining of firmware version string*/
        result = strchr((char*)SCPHandler.RxBuffer, '\n');

        /*Copy string to RAM */
        if(result)
        {
            result++;
            memset(version, 0x00, 16);

            /*Maximum 15 chars limit*/
            for(i = 0; i < 15; i++)
            {

                version[i] = *result;
                result++;

                if(*result == '\r')
                {
                    break;
                }
            }

            return version;
        }
    }

    return NULL;
}

/*Writes firmware version to given pointer, must have 50 bytes allocated*/
static _Bool GetGPSVersion(char *version)
{
    char *result = NULL;
    char *temp = NULL;

    temp = version;

    /*Request GPS module firmware version*/
    result = SCP_SendCommandWaitAnswer("AT$GPSSW\r", "OK", 30000, 1);

    if(result)
    {
        result = NULL;
        result = strstr((char*)SCPHandler.RxBuffer, "$GPSSW: ");
        result += 8;
        if(result)
        {
            memset(version, 0x00, 50);

            /*Maximum 49 chars for firmware version*/
            for(uint8_t i = 0; i < 49; i++)
            {
                *temp = *result;
                result++;
                temp++;

                /*The end of the string*/
                if(*result == '\r')
                {
                    break;
                }
            }

            return true;
        }
    }

    return false;
}

/*Read GPS properties*/
static _Bool GetGPSLocation( char *utc, char *date, char *lat, char *lon, char *alt, char *hdop, char *cog, char *speed, char *nsat)
{
    char *result = NULL;
    char *dir = NULL;
    double coordinate = 0;

    /*Request GPS data*/
    result = SCP_SendCommandWaitAnswer("AT$GPSACP\r", "OK", 2000, 1);

    /*We have response, lets look for the info in the receiver buffer*/
    if(result)
    {
        result = NULL;
        result = strstr((char*)SCPHandler.RxBuffer, "$GPSACP: ");
        result +=9;
        if(result)
        {
            strxcpy(utc, result);
            result = strchr(result, ',');
            result++;
            if(result)
            {
                dir = strchr(result, 'N');
                if(!dir)
                {
                    dir = strchr(result, 'S');
                }
                coordinate = nmea2dec(result, 1, dir);
                sprintf(lat, "%.6f", coordinate);
                result = strchr(result, ',');
                result++;
                if(result)
                {
                    dir = strchr(result, 'E');
                    if(!dir)
                    {
                        dir = strchr(result, 'W');
                    }
                    coordinate = nmea2dec(result, 2, dir);
                    sprintf(lon, "%.6f", coordinate);
                    result = strchr(result, ',');
                    result++;
                    if(result)
                    {
                        strxcpy(hdop, result);
                        result = strchr(result, ',');
                        result++;
                        if(result)
                        {
                            strxcpy(alt, result);
                            result = strchr(result, ',');
                            result++;
                            result = strchr(result, ',');
                            result++;
                            if(result)
                            {
                                strxcpy(cog, result);
                                result = strchr(result, ',');
                                result++;
                                if(result)
                                {
                                    strxcpy(speed, result);
                                    result = strchr(result, ',');
                                    result++;
                                    result = strchr(result, ',');
                                    result++;
                                    if(result)
                                    {
                                        strxcpy(date, result);
                                        result = strchr(result, ',');
                                        result++;
                                        if(result)
                                        {
                                            strxcpy(nsat, result);
                                        }

                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    return false;
}

/* Authentication */
static _Bool TelitPortalAuthenticate(void)
{
    char *result = NULL;
    memset(post_buff, 0, sizeof(post_buff));
    int i;

    /*Reset rx buffer for data reception*/
    SCP_InitRx();

    /* Form data to be posted*/
    sprintf(post_buff, fcmd_dW_auth, telit_appToken, telit_appID, modem_data.imei);

    /* Get data length */
    sprintf(post_length, "%d\r\n\r\n", strlen(post_buff));

    /* Send http post header */
    SCP_SendData((char *)fcmd_HTTPPOST, strlen(fcmd_HTTPPOST));

    /* Send data length */
    SCP_SendData(post_length, strlen(post_length));

    /* Send post data */
    SCP_SendData(post_buff, strlen(post_buff));

    /* Wait for full answer */
    result = SCP_WaitForAnswer("}}}", 60000);
    if (result)
    {

        /* Find sessionID */
        result = SCP_WaitForAnswer("sessionId\":\"", 60000);
        /* Getting session id */
        result += strlen("sessionId\":\"");

        i=0;
        while ((*result != '\"')&& (i < SESSIONID_LENGTH))
        {
            telit_sessionId[i++]=*(result++);

        }
        if (i <= SESSIONID_LENGTH)
            return true;
    }
    return false;
}

/*Post*/
static _Bool TelitPortalPostData(void)
{
    char *result = NULL;
    uint32_t len;
    memset(post_buff, 0, sizeof(post_buff));

    double temperature, humidity, pressure;
    int mag_xy,signal_level,batt_voltage;

    /*Copy variables that might to change during data post*/
    temperature = sensors_data.bme280_temperature;
    pressure = sensors_data.bme280_pressure;
    humidity = sensors_data.bme280_humidity;
    mag_xy = sensors_data.bmx055_xy_angle;
    batt_voltage = modem_data.batt_voltage_mv;
    signal_level = modem_data.signal;

    /*Reset rx buffer for data reception*/
    SCP_InitRx();

    /*If we have no GPS data, we have to exclude them from post*/
    if(
            strlen(modem_data.gps_latitude) == 0
            || strlen(modem_data.gps_longitude) == 0
            || strlen(modem_data.gps_altitude) == 0
            || strlen(modem_data.gps_course) == 0
            || strlen(modem_data.gps_speed) == 0
            || strlen(modem_data.gps_precision) == 0
            )
    {
        len =  strlen(fcmd_dw_post_auth) - 2;
        len += strlen(fcmd_dw_post_p1) - 6;
        len += strlen(fcmd_dw_post_p2) - 6;
        len += strlen(fcmd_dw_post_p3) - 6;
        len += strlen(fcmd_dw_post_p4) - 4;
        len += strlen(fcmd_dw_post_p5) - 4;
        len += strlen(fcmd_dw_post_p6) - 4;

        /* Calculate parameters length */
        sprintf(
                (char *)post_buff,"%s%s%s%s%s%s%s%.2f%.2f%.2f%d%d%d",
                telit_sessionId,
                modem_data.imei,
                modem_data.imei,
                modem_data.imei,
                modem_data.imei,
                modem_data.imei,
                modem_data.imei,
                temperature,
                pressure,
                humidity,
                mag_xy,
                batt_voltage,
                signal_level
                );

        len += strlen((char *)post_buff);

        /* Form the buffer with post header */
        SCP_SendData((char *)fcmd_HTTPPOST, strlen(fcmd_HTTPPOST));
        sprintf((char *)post_buff,"%d\r\n\r\n", (int)len);
        SCP_SendData((char *)post_buff, strlen(post_buff));
        sprintf((char *)post_buff, fcmd_dw_post_auth, telit_sessionId);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        sprintf((char *)post_buff, fcmd_dw_post_p1, modem_data.imei, temperature);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        sprintf((char *)post_buff, fcmd_dw_post_p2, modem_data.imei, pressure);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        sprintf((char *)post_buff, fcmd_dw_post_p3, modem_data.imei, humidity);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        sprintf((char *)post_buff, fcmd_dw_post_p4, modem_data.imei, mag_xy);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        sprintf((char *)post_buff, fcmd_dw_post_p5, modem_data.imei, batt_voltage);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        sprintf((char *)post_buff, fcmd_dw_post_p6, modem_data.imei, signal_level);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        SCP_SendData("\r\n", strlen("\r\n"));

        result = SCP_WaitForAnswer("}}", 60000);
        if (result)
        {
            return true;
        }
    }

    /*Include GNSS data*/
    else
    {
        len =  strlen(fcmd_dw_post_auth) - 2;
        len += strlen(fcmd_dw_post_p1) - 6;
        len += strlen(fcmd_dw_post_p2) - 6;
        len += strlen(fcmd_dw_post_p3) - 6;
        len += strlen(fcmd_dw_post_p4) - 4;
        len += strlen(fcmd_dw_post_p5) - 4;
        len += strlen(fcmd_dw_post_p6) - 4;
        len += strlen(fcmd_dw_post_p7) - 14;

        /* Calculate parameters length */
        sprintf(
                (char *)post_buff,"%s%s%s%s%s%s%s%.2f%.2f%.2f%d%d%d%s%s%s%s%s%s%s",
                telit_sessionId,
                modem_data.imei,
                modem_data.imei,
                modem_data.imei,
                modem_data.imei,
                modem_data.imei,
                modem_data.imei,
                temperature,
                pressure,
                humidity,
                mag_xy,
                batt_voltage,
                signal_level,
                modem_data.imei,
                modem_data.gps_latitude,
                modem_data.gps_longitude,
                modem_data.gps_altitude,
                modem_data.gps_course,
                modem_data.gps_speed,
                modem_data.gps_precision
                );

        len += strlen((char *)post_buff);

        /* Form the buffer with post header */
        SCP_SendData((char *)fcmd_HTTPPOST, strlen(fcmd_HTTPPOST));
        sprintf((char *)post_buff,"%d\r\n\r\n", (int)len);
        SCP_SendData((char *)post_buff, strlen(post_buff));
        sprintf((char *)post_buff, fcmd_dw_post_auth, telit_sessionId);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        sprintf((char *)post_buff, fcmd_dw_post_p1, modem_data.imei, temperature);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        sprintf((char *)post_buff, fcmd_dw_post_p2, modem_data.imei, pressure);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        sprintf((char *)post_buff, fcmd_dw_post_p3, modem_data.imei, humidity);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        sprintf((char *)post_buff, fcmd_dw_post_p4, modem_data.imei, mag_xy);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        sprintf((char *)post_buff, fcmd_dw_post_p5, modem_data.imei, batt_voltage);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        sprintf((char *)post_buff, fcmd_dw_post_p6, modem_data.imei, signal_level);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        sprintf((char *)post_buff,
                fcmd_dw_post_p7,
                modem_data.imei,
                modem_data.gps_latitude,
                modem_data.gps_longitude,
                modem_data.gps_altitude,
                modem_data.gps_course,
                modem_data.gps_speed,
                modem_data.gps_precision);
        SCP_SendData((char *)post_buff, strlen(post_buff));

        result = SCP_WaitForAnswer("}}", 60000);
        if (result)
        {
            return true;
        }
    }

    /*Timeout. In case of error, no }} received*/
    return false;
}


/*Open socket to address*/
static _Bool ModemOpenTcpSocket(char *pAddress, uint32_t port)
{
    char *result = NULL;
    memset(post_buff, 0, sizeof(post_buff));
    /* Form open socket command */
    sprintf(post_buff, "AT#SD=1,0,%d,\"%s\"\r", (int)port, pAddress);
    result = SCP_SendCommandWaitAnswer(post_buff, "CONNECT", 60000, 1);

    if(result)
    {
        return true;
    }

    return false;
}

/* Close socket to address */
static _Bool ModemCloseTcpSocket(void)
{
    char *result = NULL;
    /* Form open socket command */
    result = SCP_SendCommandWaitAnswer("AT#SH=1\r\n", "OK", 60000, 1);

    if(result)
    {
        return true;
    }

    return false;
}

/* Provider change procedure */
static _Bool ChangeProvider(void)
{
    char *result = NULL;
    char provider[17];

    /* Send command to check what networks are available */
    result = SCP_SendCommandWaitAnswer("AT+COPS=?\r", "OK", 30000, 1);

    /*We have response, lets look for the info in the receiver buffer*/
    if(result)
    {
        result = NULL;
        result = strstr((char*)SCPHandler.RxBuffer, "+COPS:");
        if(result)
        {
            for(;;)
            {
                search:
                result = strchr(result, '(');
                if(result)
                {
                    result +=1;
                    if(*result == '1')
                    {
                        /* Provider found, copy the name */
                        result = strchr(result, '"');

                        if(result)
                        {
                            /* Clean buffer */
                            memset(provider, 0x00, 17);

                            /* Maximum 16 chars for operator initials allowed */
                            for(uint8_t i = 0; i < 16; i++)
                            {
                                provider[i] = *result;
                                result++;

                                /* Last operator char? */
                                if(*result == '"')
                                {
                                    i++;
                                    provider[i] = *result;

                                    /* Form command */
                                    memset(post_buff, 0, sizeof(post_buff));
                                    sprintf(post_buff, "AT+COPS=1,0,%s\r",provider);
                                    result = SCP_SendCommandWaitAnswer(post_buff, "OK", 10000, 1);
                                    if(result)
                                    {
                                        return true;
                                    }
                                    else
                                    {
                                        return false;
                                    }
                                }
                            }

                        }

                        else
                        {
                            return false;
                        }
                    }
                    else
                    {
                        goto search;
                    }
                }
                else
                {
                    break;
                }

            }
        }

    }

    return false;
}

/* Modem Thread entry function */
void modem_thread_entry(void)
{
    ssp_err_t err;
    char * scp_result = NULL;
    static uint32_t mod_time_counter = 0;
    static uint32_t cloud_time_counter = 0;
    static uint32_t gprs_recon_counter = 0;
    static _Bool authenticated = false;
    char temp_buff[20];
    _Bool temp_result = false;
    static _Bool init_OK = false;

    /* Get LED information for this board */
    err = R_BSP_LedsGet(&leds);
    if(err)
    {
        /*No LEDs declared?*/
        APP_ERR_TRAP(err);
    }

    modem_start:

    /*Apply power for GSM and GNSS modules*/
    ModemOn();
    GNSS_On();
    Charger_On();
    modem_data.gsm_pwr_status = true;
    modem_data.gnss_pwr_status = true;
    modem_data.charger_pwr_status = true;

    /*GSM and GNSS initialisation*/
    GSM_init();

    /*AT parser initialisation*/
    SCP_Init(uart_send_buff, uart_read_byte);

    /*AT CaLlbacks Register*/
    SCP_AddCallback("+CLIP:", IncomingCall);

    /*Wait 1000ms for modem to be ready*/
    tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND));

    /*Try AT command*/
    scp_result = SCP_SendCommandWaitAnswer("AT\r\n", "OK", 2000, 1);

    /*Echo commands turn off*/
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("ATE0\r\n", "OK", 2000, 1);

    /*Set provider to default*/
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("AT+COPS=0\r\n", "OK", 2000, 1);

    /*eSIM card removed and switched to Nano SIM card */
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("AT#SIMDET=0\r", "OK", 2000, 1);
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("AT#GPIO=4,1,1\r", "OK", 2000, 1);

    /*Nano SIM card present*/
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("AT#SIMDET=1\r", "OK", 2000, 1);
    /*Wait 5000ms for modem to be ready*/
    tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND*5));

    if(scp_result)
    {
        /*Get IMEI*/
        scp_result = NULL;
        scp_result = GetIMEI();
        if(scp_result)
        {
            memset(modem_data.imei, 0x00, 16);
            strcpy(modem_data.imei, scp_result);
        }

        /*Get module type*/
        scp_result = NULL;
        scp_result = GetID();
        if(scp_result)
        {
            memset(modem_data.device_name, 0x00, 21);
            strcpy(modem_data.device_name, scp_result);
        }

        /*Get firmware version*/
        scp_result = NULL;
        scp_result = GetVersion();
        if(scp_result)
        {
            memset(modem_data.fw_version, 0x00, 16);
            strcpy(modem_data.fw_version, scp_result);
        }
    }

    /*Set APN*/
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("AT+CGDCONT=1,\"IP\",\"omnitel\"\r", "OK", 2000, 1);
    //if (scp_result) scp_result = SCP_SendCommandWaitAnswer("AT+CGDCONT=1,\"IP\",\"internet.tele2.lt\"\r", "OK", 2000, 1);
    //if (scp_result) scp_result = SCP_SendCommandWaitAnswer("AT+CGDCONT=1,\"IP\",\"nxt17.net\"\r", "OK", 2000, 1);

    /*Message format = text mode*/
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("AT+CMGF=1\r", "OK", 2000, 1);

    /*Enable error report*/
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("AT+CMEE=2\r", "OK", 2000, 1);

    /*Enable the extended call type format reporting*/
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("AT+CRC=1\r", "OK", 2000, 1);

    /*Enable the caller number identification.*/
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("AT+CLIP=1\r", "OK", 2000, 1);

    /*CPU Clock Mode.*/
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("AT#CPUMODE=6\r", "OK", 2000, 1);

    /*Delete all messages*/
    if (scp_result) scp_result = SCP_SendCommandWaitAnswer("AT+CMGD=1,4\r", "OK", 2000, 1);

    if (scp_result)
    {
        /*Check if we are connected to GSM network*/
        WaitForNetwork();

        /*Wait for GNSS to be ready*/
        while(!temp_result)
        {
            /*Get GPS firmware version*/
            temp_result = GetGPSVersion(modem_data.gps_sw_version);

            tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND/2));
        }

        init_OK = true;
    }

    if(!init_OK)
    {
        /*Restart modem*/
        goto modem_start;
    }

    while (1)
    {
        /* Wait 100ms */
        tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND/10));

        /*Look for URC (Unsolicited Result Code)*/
        SCP_Process();

        mod_time_counter++;
        cloud_time_counter++;

        /*Gather modem & GPS data occasionally*/
        if(mod_time_counter >= MODEM_DATA_REQUEST_INTERVAL)
        {
            /*If waiting for the data from modem do not execute commands*/
            if(!modem_data.data_request)
            {
                /*Reset counter now*/
                mod_time_counter = 0;

                /*Check the response to AT command*/
                scp_result = SCP_SendCommandWaitAnswer("AT\r", "OK", 2000, 1);
                if(!scp_result)
                {
                  scp_result = NULL;
                  mod_time_counter = 0;
                  cloud_time_counter = 0;
                  gprs_recon_counter = 0;
                  authenticated = false;
                  init_OK = false;
                  modem_data.gprs_status = 0;
                  modem_data.data_request = false;
                  authenticated = false;

                  /*Restart modem*/
                  goto modem_start;
                }

                /*Check if settings are still the same as initiated*/
                int error;
                scp_result = SCP_SendCommandWaitAnswer("AT+CMEE?\r", "OK", 2000, 1);
                if (scp_result)
                {
                    scp_result = NULL;
                    scp_result = strstr((char*)SCPHandler.RxBuffer, "+CMEE: ");
                    if(scp_result)
                    {
                        scp_result += 7;
                        error = atoi(scp_result);
                        if(error != 2)
                        {
                            /*Restart modem*/
                            goto modem_start;
                        }
                    }
                }

                /*Store signal quality*/
                modem_data.signal = SignalQuality();

                /*Battery voltage*/
                modem_data.batt_voltage_mv = MeasureBattVoltage();
                if(modem_data.batt_voltage_mv <= SHUT_DOWN_VOLTAGE )
                {
                    /*Shut down*/
                    ModemOff();
                    GNSS_Off();
                    /*Turn off LED*/
                    g_ioport.p_api->pinWrite(leds.p_leds[0], IOPORT_LEVEL_HIGH);
                    g_lpmv2_standby0.p_api->lowPowerModeEnter();
                }

                /*Network Status*/
                modem_data.network_status = NetworkRegistrationCheck();

                /*Registered to home network or registered as roaming is acceptable*/
                if((modem_data.network_status == 1) || (modem_data.network_status == 5))
                {
                    /*Store operator*/
                    scp_result = NULL;
                    scp_result = GetOperator();
                    if(scp_result)
                    {
                        memset(modem_data.operator, 0x00, 17);
                        strcpy(modem_data.operator, scp_result);
                    }

                    /*Check GPRS status*/
                    modem_data.gprs_status = GPRS_StatusCheck();

                    /*Try to connect if not connected*/
                    if(!modem_data.gprs_status)
                    {
                        modem_data.gprs_status = GPRS_Connect(modem_data.ip_address);

                        /*Count how many times tried to connect*/
                        if(!modem_data.gprs_status)
                        {
                            gprs_recon_counter++;
                        }
                        else
                        {
                            gprs_recon_counter = 0;
                        }

                        /*Roaming and no GPRS, retry few times and try to change network*/
                        if(!modem_data.gprs_status && (modem_data.network_status == 5) && (gprs_recon_counter >= GPRS_CONNECT_RETRY))
                        {
                            /*reset counter*/
                            gprs_recon_counter = 0;

                            /*change provider*/
                            if(ChangeProvider())
                            {
                                /*Check if we are connected to GSM network*/
                                WaitForNetwork();
                            }
                        }
                    }
                }
                else
                {
                    modem_data.gprs_status = 0;
                    modem_data.data_request = false;
                    authenticated = false;
                }

                /*Indicate GSM network and GPRS status with a modem LED*/
                if(UPLOAD_CLOUD)
                {
                    if(modem_data.gprs_status)
                    {
                        /*Turn on LED*/
                        g_ioport.p_api->pinWrite(leds.p_leds[0], IOPORT_LEVEL_LOW);
                    }
                    else
                    {
                        /*Turn off LED*/
                        g_ioport.p_api->pinWrite(leds.p_leds[0], IOPORT_LEVEL_HIGH);
                    }
                }
                else
                {
                    if((modem_data.network_status==1) || (modem_data.network_status==5))
                    {
                        /*Turn on LED*/
                        g_ioport.p_api->pinWrite(leds.p_leds[0], IOPORT_LEVEL_LOW);
                    }
                    else
                    {
                        /*Turn off LED*/
                        g_ioport.p_api->pinWrite(leds.p_leds[0], IOPORT_LEVEL_HIGH);
                    }
                }

                /* Gather GNSS data */
                if(USE_GNSS)
                {
                  char temp_utc[16];
                  char temp_dat[16];
                  char temp_lat[16];
                  char temp_lon[16];
                  char temp_alt[16];
                  char temp_pre[16];
                  char temp_cou[16];
                  char temp_spe[16];
                  char temp_nsa[16];
                  memset(temp_utc,0x00,sizeof(temp_utc));
                  memset(temp_dat,0x00,sizeof(temp_dat));
                  memset(temp_lat,0x00,sizeof(temp_lat));
                  memset(temp_lon,0x00,sizeof(temp_lon));
                  memset(temp_alt,0x00,sizeof(temp_alt));
                  memset(temp_pre,0x00,sizeof(temp_pre));
                  memset(temp_cou,0x00,sizeof(temp_cou));
                  memset(temp_spe,0x00,sizeof(temp_spe));
                  memset(temp_nsa,0x00,sizeof(temp_nsa));
                  memset(modem_data.gps_utc,0x00,sizeof(modem_data.gps_utc));
                  memset(modem_data.gps_date,0x00,sizeof(modem_data.gps_date));
                  memset(modem_data.gps_latitude,0x00,sizeof(modem_data.gps_latitude));
                  memset(modem_data.gps_longitude,0x00,sizeof(modem_data.gps_longitude));
                  memset(modem_data.gps_altitude,0x00,sizeof(modem_data.gps_altitude));
                  memset(modem_data.gps_precision,0x00,sizeof(modem_data.gps_precision));
                  memset(modem_data.gps_course,0x00,sizeof(modem_data.gps_course));
                  memset(modem_data.gps_speed,0x00,sizeof(modem_data.gps_speed));
                  memset(modem_data.gps_satt_in_use,0x00,sizeof(modem_data.gps_satt_in_use));

                  modem_data.gnss_online = GetGPSLocation(temp_utc,temp_dat,temp_lat,temp_lon,temp_alt,temp_pre,temp_cou,temp_spe,temp_nsa);
                  if(modem_data.gnss_online && atoi(temp_nsa) > 3)
                    {
                      strcpy(modem_data.gps_utc, temp_utc);
                      strcpy(modem_data.gps_date, temp_dat);
                      strcpy(modem_data.gps_latitude, temp_lat);
                      strcpy(modem_data.gps_longitude, temp_lon);
                      strcpy(modem_data.gps_altitude, temp_alt);
                      strcpy(modem_data.gps_precision, temp_pre);
                      strcpy(modem_data.gps_course, temp_cou);
                      strcpy(modem_data.gps_speed, temp_spe);
                      strcpy(modem_data.gps_satt_in_use, temp_nsa);
                    }
                }
            }
        }

        /*Upload to Telit Cloud*/
        if(cloud_time_counter >= TELIT_CLOUD_UPDATE_INTERVAL)
        {
            /*If not waiting for any data to receive*/
            if(!modem_data.data_request)
            {
                if(UPLOAD_CLOUD)
                {
                    /*If we have GPRS connection...*/
                    if (modem_data.gprs_status)
                    {
                        /*Reset counter now*/
                        cloud_time_counter = 0;

                        /*Authenticate only once per session*/
                        if(!authenticated)
                        {
                            /*Authentication*/
                            temp_result = ModemOpenTcpSocket("api-de.devicewise.com", 80);
                            if(temp_result)
                            {
                                authenticated = TelitPortalAuthenticate();
                                ModemCloseTcpSocket();
                                if(!authenticated)
                                {
                                    /*Check GPRS status*/
                                    modem_data.gprs_status = GPRS_StatusCheck();
                                    if(!modem_data.gprs_status)
                                    {
                                        modem_data.data_request = false;
                                        authenticated = false;
                                    }
                                }
                                else
                                {
                                    /*If authentication is OK, we can post data now*/
                                    goto post;
                                }
                            }
                        }
                        else
                        {
                            /*Post*/
                            post:
                            temp_result = ModemOpenTcpSocket("api-de.devicewise.com", 80);
                            if (temp_result)
                            {
                                authenticated = TelitPortalPostData();
                                ModemCloseTcpSocket();
                            }
                            if(!authenticated)
                            {
                                /*Check GPRS status*/
                                modem_data.gprs_status = GPRS_StatusCheck();
                                if(!modem_data.gprs_status)
                                {
                                    modem_data.data_request = false;
                                    authenticated = false;
                                }
                            }
                        }
                     }
                }
            }
        }

        /*Send data via SMS*/
        if(SEND_SMS)
        {
            /*Do not interrupt if other process requested data*/
            if(!modem_data.data_request)
            {

                /*If we have received a call*/
                if(msg_sts)
                {
                    /*Hang up*/
                    (void) SCP_SendCommandWaitAnswer("ATH\r", "OK", 2000, 1);

                    memset(g_sms_buff, 0x00, sizeof(g_sms_buff));
                    memset(post_buff, 0x00, sizeof(post_buff));

                    strcat(g_sms_buff, modem_data.gps_latitude);
                    strcat(g_sms_buff, ", ");
                    strcat(g_sms_buff, modem_data.gps_longitude);
                    strcat(g_sms_buff, ", ");

                    memset(temp_buff, 0x00, sizeof(temp_buff));
                    sprintf(temp_buff, "%.2f", sensors_data.bme280_temperature);
                    strcat(temp_buff, "C, ");
                    strcat(g_sms_buff, temp_buff);

                    memset(temp_buff, 0x00, sizeof(temp_buff));
                    sprintf(temp_buff, "%.2f", sensors_data.bme280_pressure);
                    strcat(temp_buff, "kPa, ");
                    strcat(g_sms_buff, temp_buff);

                    memset(temp_buff, 0x00, sizeof(temp_buff));
                    sprintf(temp_buff, "%.2f", sensors_data.bme280_humidity);
                    strcat(temp_buff, "% ");
                    strcat(g_sms_buff, temp_buff);

                    /*Termination symbol*/
                    strcat(g_sms_buff, "\032");

                    sprintf(post_buff, "AT+CMGS=%s\r", incoming_number);
                    SCP_SendDoubleCommandWaitAnswer(post_buff, g_sms_buff,">", "OK", 5000, 5);
                    msg_sts = false;
                }
            }
        }
    }
}
