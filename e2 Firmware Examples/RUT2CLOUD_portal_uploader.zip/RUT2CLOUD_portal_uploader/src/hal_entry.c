/* HAL-only entry function */
#include "hal_data.h"
void hal_entry(void)
{
    g_rtc0.p_api->open(g_rtc0.p_ctrl, g_rtc0.p_ctrl);
}
