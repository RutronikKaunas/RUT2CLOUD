/* generated thread header file - do not edit */
#ifndef BUTTON_PROCESSING_THREAD_H_
#define BUTTON_PROCESSING_THREAD_H_
#include "bsp_api.h"
#include "tx_api.h"
#include "hal_data.h"
#ifdef __cplusplus
extern "C" void button_processing_thread_entry(void);
#else
extern void button_processing_thread_entry(void);
#endif
#ifdef __cplusplus
extern "C"
{
#endif
extern TX_SEMAPHORE pb_switch_sem;
#ifdef __cplusplus
} /* extern "C" */
#endif
#endif /* BUTTON_PROCESSING_THREAD_H_ */
