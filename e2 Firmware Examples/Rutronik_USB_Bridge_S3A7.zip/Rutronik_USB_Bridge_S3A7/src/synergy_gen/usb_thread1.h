/* generated thread header file - do not edit */
#ifndef USB_THREAD1_H_
#define USB_THREAD1_H_
#include "bsp_api.h"
#include "tx_api.h"
#include "hal_data.h"
#ifdef __cplusplus
extern "C" void usb_thread1_entry(void);
#else
extern void usb_thread1_entry(void);
#endif
#include "sf_i2c.h"
#include "sf_i2c_api.h"
#include "sf_el_ux_comms_v2.h"
#include "sf_comms_api.h"
#ifdef __cplusplus
extern "C"
{
#endif
/* SF I2C on SF I2C Instance. */
extern const sf_i2c_instance_t g_sf_i2c_device_mag;
/* SF I2C on SF I2C Instance. */
extern const sf_i2c_instance_t g_sf_i2c_device_gyro;
/* SF I2C on SF I2C Instance. */
extern const sf_i2c_instance_t g_sf_i2c_device_acc;
/* SF I2C on SF I2C Instance. */
extern const sf_i2c_instance_t g_sf_i2c_device0;
/* USB Communication Framework Instance */
extern const sf_comms_instance_t g_sf_comms_usb1;
/* USBX CDC-ACM Instance Activate User Callback Function */
VOID ux_cdc_device1_instance_activate(VOID *cdc_instance);
/* USBX CDC-ACM Instance Deactivate User Callback Function */
VOID ux_cdc_device1_instance_deactivate_internal(VOID *cdc_instance);
void g_sf_comms_usb1_err_callback(void *p_instance, void *p_data);
void sf_comms_init_usb1(void);
#ifdef __cplusplus
} /* extern "C" */
#endif
#endif /* USB_THREAD1_H_ */
