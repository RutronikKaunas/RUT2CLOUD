/* generated thread source file - do not edit */
#include "led_control.h"

TX_THREAD led_control;
void led_control_create(void);
static void led_control_func(ULONG thread_input);
static uint8_t led_control_stack[1024] BSP_PLACE_IN_SECTION_V2(".stack.led_control") BSP_ALIGN_VARIABLE_V2(BSP_STACK_ALIGNMENT);
void tx_startup_err_callback(void *p_instance, void *p_data);
void tx_startup_common_init(void);
TX_SEMAPHORE g_led_semaphore;
extern bool g_ssp_common_initialized;
extern uint32_t g_ssp_common_thread_count;
extern TX_SEMAPHORE g_ssp_common_initialized_semaphore;

void led_control_create(void)
{
    /* Increment count so we will know the number of ISDE created threads. */
    g_ssp_common_thread_count++;

    /* Initialize each kernel object. */
    UINT err_g_led_semaphore;
    err_g_led_semaphore = tx_semaphore_create (&g_led_semaphore, (CHAR *) "LED Semaphore", 1);
    if (TX_SUCCESS != err_g_led_semaphore)
    {
        tx_startup_err_callback (&g_led_semaphore, 0);
    }

    UINT err;
    err = tx_thread_create (&led_control, (CHAR *) "LED Thread", led_control_func, (ULONG) NULL, &led_control_stack,
                            1024, 1, 1, 1, TX_AUTO_START);
    if (TX_SUCCESS != err)
    {
        tx_startup_err_callback (&led_control, 0);
    }
}

static void led_control_func(ULONG thread_input)
{
    /* Not currently using thread_input. */
    SSP_PARAMETER_NOT_USED (thread_input);

    /* Initialize common components */
    tx_startup_common_init ();

    /* Initialize each module instance. */

    /* Enter user code for this thread. */
    led_control_entry ();
}
