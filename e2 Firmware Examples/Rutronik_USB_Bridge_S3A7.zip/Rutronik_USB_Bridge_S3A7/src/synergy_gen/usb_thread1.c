/* generated thread source file - do not edit */
#include "usb_thread1.h"

TX_THREAD usb_thread1;
void usb_thread1_create(void);
static void usb_thread1_func(ULONG thread_input);
static uint8_t usb_thread1_stack[1024] BSP_PLACE_IN_SECTION_V2(".stack.usb_thread1") BSP_ALIGN_VARIABLE_V2(BSP_STACK_ALIGNMENT);
void tx_startup_err_callback(void *p_instance, void *p_data);
void tx_startup_common_init(void);
/** Get driver cfg from bus and use all same settings except slave address and addressing mode. */
const i2c_cfg_t g_sf_i2c_device_mag_i2c_cfg =
{ .channel = g_sf_i2c_bus0_CHANNEL,
  .rate = g_sf_i2c_bus0_RATE,
  .slave = 0x13,
  .addr_mode = I2C_ADDR_MODE_7BIT,
  .sda_delay = g_sf_i2c_bus0_SDA_DELAY,
  .p_transfer_tx = g_sf_i2c_bus0_P_TRANSFER_TX,
  .p_transfer_rx = g_sf_i2c_bus0_P_TRANSFER_RX,
  .p_callback = g_sf_i2c_bus0_P_CALLBACK,
  .p_context = g_sf_i2c_bus0_P_CONTEXT,
  .rxi_ipl = g_sf_i2c_bus0_RXI_IPL,
  .txi_ipl = g_sf_i2c_bus0_TXI_IPL,
  .tei_ipl = g_sf_i2c_bus0_TEI_IPL,
  .eri_ipl = g_sf_i2c_bus0_ERI_IPL,
  .p_extend = g_sf_i2c_bus0_P_EXTEND, };

sf_i2c_instance_ctrl_t g_sf_i2c_device_mag_ctrl =
{ .p_lower_lvl_ctrl = &g_i2c0_ctrl, };
const sf_i2c_cfg_t g_sf_i2c_device_mag_cfg =
{ .p_bus = (sf_i2c_bus_t *) &g_sf_i2c_bus0, .p_lower_lvl_cfg = &g_sf_i2c_device_mag_i2c_cfg, };
/* Instance structure to use this module. */
const sf_i2c_instance_t g_sf_i2c_device_mag =
{ .p_ctrl = &g_sf_i2c_device_mag_ctrl, .p_cfg = &g_sf_i2c_device_mag_cfg, .p_api = &g_sf_i2c_on_sf_i2c };
/** Get driver cfg from bus and use all same settings except slave address and addressing mode. */
const i2c_cfg_t g_sf_i2c_device_gyro_i2c_cfg =
{ .channel = g_sf_i2c_bus0_CHANNEL,
  .rate = g_sf_i2c_bus0_RATE,
  .slave = 0x69,
  .addr_mode = I2C_ADDR_MODE_7BIT,
  .sda_delay = g_sf_i2c_bus0_SDA_DELAY,
  .p_transfer_tx = g_sf_i2c_bus0_P_TRANSFER_TX,
  .p_transfer_rx = g_sf_i2c_bus0_P_TRANSFER_RX,
  .p_callback = g_sf_i2c_bus0_P_CALLBACK,
  .p_context = g_sf_i2c_bus0_P_CONTEXT,
  .rxi_ipl = g_sf_i2c_bus0_RXI_IPL,
  .txi_ipl = g_sf_i2c_bus0_TXI_IPL,
  .tei_ipl = g_sf_i2c_bus0_TEI_IPL,
  .eri_ipl = g_sf_i2c_bus0_ERI_IPL,
  .p_extend = g_sf_i2c_bus0_P_EXTEND, };

sf_i2c_instance_ctrl_t g_sf_i2c_device_gyro_ctrl =
{ .p_lower_lvl_ctrl = &g_i2c0_ctrl, };
const sf_i2c_cfg_t g_sf_i2c_device_gyro_cfg =
{ .p_bus = (sf_i2c_bus_t *) &g_sf_i2c_bus0, .p_lower_lvl_cfg = &g_sf_i2c_device_gyro_i2c_cfg, };
/* Instance structure to use this module. */
const sf_i2c_instance_t g_sf_i2c_device_gyro =
{ .p_ctrl = &g_sf_i2c_device_gyro_ctrl, .p_cfg = &g_sf_i2c_device_gyro_cfg, .p_api = &g_sf_i2c_on_sf_i2c };
/** Get driver cfg from bus and use all same settings except slave address and addressing mode. */
const i2c_cfg_t g_sf_i2c_device_acc_i2c_cfg =
{ .channel = g_sf_i2c_bus0_CHANNEL,
  .rate = g_sf_i2c_bus0_RATE,
  .slave = 0x19,
  .addr_mode = I2C_ADDR_MODE_7BIT,
  .sda_delay = g_sf_i2c_bus0_SDA_DELAY,
  .p_transfer_tx = g_sf_i2c_bus0_P_TRANSFER_TX,
  .p_transfer_rx = g_sf_i2c_bus0_P_TRANSFER_RX,
  .p_callback = g_sf_i2c_bus0_P_CALLBACK,
  .p_context = g_sf_i2c_bus0_P_CONTEXT,
  .rxi_ipl = g_sf_i2c_bus0_RXI_IPL,
  .txi_ipl = g_sf_i2c_bus0_TXI_IPL,
  .tei_ipl = g_sf_i2c_bus0_TEI_IPL,
  .eri_ipl = g_sf_i2c_bus0_ERI_IPL,
  .p_extend = g_sf_i2c_bus0_P_EXTEND, };

sf_i2c_instance_ctrl_t g_sf_i2c_device_acc_ctrl =
{ .p_lower_lvl_ctrl = &g_i2c0_ctrl, };
const sf_i2c_cfg_t g_sf_i2c_device_acc_cfg =
{ .p_bus = (sf_i2c_bus_t *) &g_sf_i2c_bus0, .p_lower_lvl_cfg = &g_sf_i2c_device_acc_i2c_cfg, };
/* Instance structure to use this module. */
const sf_i2c_instance_t g_sf_i2c_device_acc =
{ .p_ctrl = &g_sf_i2c_device_acc_ctrl, .p_cfg = &g_sf_i2c_device_acc_cfg, .p_api = &g_sf_i2c_on_sf_i2c };
/** Get driver cfg from bus and use all same settings except slave address and addressing mode. */
const i2c_cfg_t g_sf_i2c_device0_i2c_cfg =
{ .channel = g_sf_i2c_bus0_CHANNEL,
  .rate = g_sf_i2c_bus0_RATE,
  .slave = 0x77,
  .addr_mode = I2C_ADDR_MODE_7BIT,
  .sda_delay = g_sf_i2c_bus0_SDA_DELAY,
  .p_transfer_tx = g_sf_i2c_bus0_P_TRANSFER_TX,
  .p_transfer_rx = g_sf_i2c_bus0_P_TRANSFER_RX,
  .p_callback = g_sf_i2c_bus0_P_CALLBACK,
  .p_context = g_sf_i2c_bus0_P_CONTEXT,
  .rxi_ipl = g_sf_i2c_bus0_RXI_IPL,
  .txi_ipl = g_sf_i2c_bus0_TXI_IPL,
  .tei_ipl = g_sf_i2c_bus0_TEI_IPL,
  .eri_ipl = g_sf_i2c_bus0_ERI_IPL,
  .p_extend = g_sf_i2c_bus0_P_EXTEND, };

sf_i2c_instance_ctrl_t g_sf_i2c_device0_ctrl =
{ .p_lower_lvl_ctrl = &g_i2c0_ctrl, };
const sf_i2c_cfg_t g_sf_i2c_device0_cfg =
{ .p_bus = (sf_i2c_bus_t *) &g_sf_i2c_bus0, .p_lower_lvl_cfg = &g_sf_i2c_device0_i2c_cfg, };
/* Instance structure to use this module. */
const sf_i2c_instance_t g_sf_i2c_device0 =
{ .p_ctrl = &g_sf_i2c_device0_ctrl, .p_cfg = &g_sf_i2c_device0_cfg, .p_api = &g_sf_i2c_on_sf_i2c };
#if defined(__ICCARM__)
#define g_sf_comms_usb1_err_callback_WEAK_ATTRIBUTE
#pragma weak g_sf_comms_usb1_err_callback  = g_sf_comms_usb1_err_callback_internal
#define ux_cdc_device1_instance_deactivate_WEAK_ATTRIBUTE
#pragma weak ux_cdc_device1_instance_deactivate  = ux_cdc_device1_instance_deactivate_internal
#elif defined(__GNUC__)
#define g_sf_comms_usb1_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_sf_comms_usb1_err_callback_internal")))
#define ux_cdc_device1_instance_deactivate_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("ux_cdc_device1_instance_deactivate_internal")))
#endif
void g_sf_comms_usb1_err_callback(void *p_instance, void *p_data)
g_sf_comms_usb1_err_callback_WEAK_ATTRIBUTE;
void ux_cdc_device1_instance_deactivate(VOID *cdc_instance)
ux_cdc_device1_instance_deactivate_WEAK_ATTRIBUTE;
/***********************************************************************************************************************
 * USB Communications Framework (SF_EL_UX_COMMS) Instance for g_sf_comms_usb1
 **********************************************************************************************************************/
sf_el_ux_comms_instance_ctrl_t g_sf_comms_usb1_instance_ctrl =
{ .p_cdc = NULL, };

/* Instance structure to use this module. */
const sf_comms_instance_t g_sf_comms_usb1 =
{ .p_ctrl = &g_sf_comms_usb1_instance_ctrl, .p_cfg = NULL, .p_api = &g_sf_el_ux_comms_on_sf_comms };

/***********************************************************************************************************************
 * USBX Device CDC-ACM Instance Activate Callback function required for g_sf_comms_usb1
 **********************************************************************************************************************/
VOID ux_cdc_device1_instance_activate(VOID *cdc_instance)
{
    /* Save the CDC instance for g_sf_comms_usb1. */
    g_sf_comms_usb1_instance_ctrl.p_cdc = (UX_SLAVE_CLASS_CDC_ACM *) cdc_instance;

    /* Inform the CDC instance activation event for g_sf_comms_usb1. */
    if (NULL != g_sf_comms_usb1.p_ctrl)
    {
        sf_el_ux_comms_instance_ctrl_t *p_ux_comms_ctrl = (sf_el_ux_comms_instance_ctrl_t *) g_sf_comms_usb1.p_ctrl;

        /* Put a semaphore if the instance for g_sf_comms_usb1 to inform CDC instance is ready. */
        tx_semaphore_ceiling_put (&p_ux_comms_ctrl->semaphore, 1);
    }
    return;
}
/***********************************************************************************************************************
 * @brief      This is a weak USBX Device CDC-ACM Instance Deactivate Callback function required for g_sf_comms_usb1
 *             It should be overridden by defining a user function with the prototype mentioned below.
 *             - VOID ux_cdc_device1_instance_deactivate (VOID *cdc_instance)
 *
 * @param[in]  cdc_instance argument is used to identify the CDC-ACM Instance
 **********************************************************************************************************************/
VOID ux_cdc_device1_instance_deactivate_internal(VOID *cdc_instance)
{
    SSP_PARAMETER_NOT_USED (cdc_instance);

    /* Reset the CDC instance for g_sf_comms_usb1. */
    g_sf_comms_usb1_instance_ctrl.p_cdc = UX_NULL;

    return;
}
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function 
 *             with the prototype below.
 *             - voidg_sf_comms_usb1_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_sf_comms_usb1_err_callback_internal(void *p_instance, void *p_data);
void g_sf_comms_usb1_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}
/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void sf_comms_init_usb1(void)
 **********************************************************************************************************************/
void sf_comms_init_usb1(void)
{
    ssp_err_t ssp_err_g_sf_comms_usb1;
    /** Open USB Communications Framework */
    ssp_err_g_sf_comms_usb1 = g_sf_comms_usb1.p_api->open (g_sf_comms_usb1.p_ctrl, g_sf_comms_usb1.p_cfg);
    if (UX_SUCCESS != ssp_err_g_sf_comms_usb1)
    {
        g_sf_comms_usb1_err_callback ((void *) &g_sf_comms_usb1, &ssp_err_g_sf_comms_usb1);
    }
}
extern bool g_ssp_common_initialized;
extern uint32_t g_ssp_common_thread_count;
extern TX_SEMAPHORE g_ssp_common_initialized_semaphore;

void usb_thread1_create(void)
{
    /* Increment count so we will know the number of ISDE created threads. */
    g_ssp_common_thread_count++;

    /* Initialize each kernel object. */

    UINT err;
    err = tx_thread_create (&usb_thread1, (CHAR *) "USB COM1 Receive Thread", usb_thread1_func, (ULONG) NULL,
                            &usb_thread1_stack, 1024, 2, 2, 1, TX_AUTO_START);
    if (TX_SUCCESS != err)
    {
        tx_startup_err_callback (&usb_thread1, 0);
    }
}

static void usb_thread1_func(ULONG thread_input)
{
    /* Not currently using thread_input. */
    SSP_PARAMETER_NOT_USED (thread_input);

    /* Initialize common components */
    tx_startup_common_init ();

    /* Initialize each module instance. */
    /** Call initialization function if user has selected to do so.*/
#if (1)
    sf_comms_init_usb1 ();
#endif

    /* Enter user code for this thread. */
    usb_thread1_entry ();
}
