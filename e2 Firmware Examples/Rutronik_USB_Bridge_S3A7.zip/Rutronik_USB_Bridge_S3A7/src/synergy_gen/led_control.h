/* generated thread header file - do not edit */
#ifndef LED_CONTROL_H_
#define LED_CONTROL_H_
#include "bsp_api.h"
#include "tx_api.h"
#include "hal_data.h"
#ifdef __cplusplus
extern "C" void led_control_entry(void);
#else
extern void led_control_entry(void);
#endif
#ifdef __cplusplus
extern "C"
{
#endif
extern TX_SEMAPHORE g_led_semaphore;
#ifdef __cplusplus
} /* extern "C" */
#endif
#endif /* LED_CONTROL_H_ */
