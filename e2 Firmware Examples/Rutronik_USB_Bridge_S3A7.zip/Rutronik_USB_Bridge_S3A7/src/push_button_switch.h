/*
 * push_button_switch.h
 *
 *  Created on: Mar 27, 2017
 *      Author: Rajkumar.Thiagarajan
 */

#ifndef PUSH_BUTTON_SWITCH_H_
#define PUSH_BUTTON_SWITCH_H_

#include  "hal_data.h"
#include  "tx_api.h"
#include  "common.h"

#define PB_PRESSED      0x01
#define PB_RELEASED     0x00

#define SWITCH_1 0x01



typedef struct
{
    ioport_level_t level;
    ioport_port_pin_t pin;
    bool triggered;
    const external_irq_instance_t *irq;
}pb_switch_irq_t;

typedef struct
{
    TX_SEMAPHORE *pb_sem;
    pb_switch_irq_t *pb_switch;
    pb_switch_payload_t *pb_msg;
    uint8_t count;
}pb_switch_context_t;

#endif /* PUSH_BUTTON_SWITCH_H_ */
