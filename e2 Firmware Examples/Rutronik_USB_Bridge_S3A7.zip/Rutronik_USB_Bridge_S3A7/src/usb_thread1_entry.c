#include "usb_thread1.h"
#include "led_control.h"
#include "common.h"
#include "util.h"

/*******************************************************************************************************************//**
 * @brief  USB Thread entry function
 *
 * This USB Thread function handles all the USBX CDC Device related communication in this application.
 *
 **********************************************************************************************************************/
void usb_thread1_entry(void)
{
   // ssp_err_t ReturnVal = SSP_SUCCESS;
    uint8_t recieve[256];
    uint8_t send[256];
    uint8_t address=0, read=0;
    uint32_t length=0;
    uint32_t i=0;

    /* Open SCI2 IIC devices */
    (void) g_sf_i2c_device0.p_api->open(g_sf_i2c_device0.p_ctrl, g_sf_i2c_device0.p_cfg);
    (void) g_sf_i2c_device_acc.p_api->open(g_sf_i2c_device_acc.p_ctrl, g_sf_i2c_device_acc.p_cfg);
    (void) g_sf_i2c_device_gyro.p_api->open(g_sf_i2c_device_gyro.p_ctrl, g_sf_i2c_device_gyro.p_cfg);
    (void) g_sf_i2c_device_mag.p_api->open(g_sf_i2c_device_mag.p_ctrl, g_sf_i2c_device_mag.p_cfg);

    while (1)
    {
        /*Check if VCOM0 is initialised*/
        if (NULL != ((sf_el_ux_comms_instance_ctrl_t*)g_sf_comms_usb1.p_ctrl)->p_cdc )
        {
            while(true)
            {
                /*Read every byte we get over USB*/
                g_sf_comms_usb1.p_api->read(g_sf_comms_usb1.p_ctrl, &read, sizeof(read), TX_WAIT_FOREVER);
                recieve[i]=read;
                i++;

                /*Indicate active communications*/
                if(!g_led_semaphore.tx_semaphore_count)
                {
                    tx_semaphore_put (&g_led_semaphore);
                }

                /*The end symbol received*/
                if(read == 'P')
                {
                    break;
                }

                /*Buffer overflow protection*/
                if (i > 255)
                {
                    i = 0;
                }
            }

            /*Package received, begin parsing*/
            i=0;
            switch(recieve[i])
            {
                /*Start char received*/
                case 'S':
                {
                    address=recieve[i+1];
                    length=recieve[i+2];

                    switch(address)
                    {
                        case BME_WRITE:
                        {
                            (void) g_sf_i2c_device0.p_api->write(g_sf_i2c_device0.p_ctrl, &recieve[i+3], length, false, IIC_TIMEOUT);;
                            break;
                        }
                        case BME_READ:
                        {
                            (void) g_sf_i2c_device0.p_api->read(g_sf_i2c_device0.p_ctrl, send, length, false, IIC_TIMEOUT);
                            (void) g_sf_comms_usb1.p_api->write(g_sf_comms_usb1.p_ctrl, send, length, TX_WAIT_FOREVER);
                            break;
                        }
                        case ACC_WRITE:
                        {
                            (void) g_sf_i2c_device_acc.p_api->write(g_sf_i2c_device_acc.p_ctrl, &recieve[i+3], length, false, IIC_TIMEOUT);;
                            break;
                        }
                        case ACC_READ:
                        {
                            (void) g_sf_i2c_device_acc.p_api->read(g_sf_i2c_device_acc.p_ctrl, send, length, false, IIC_TIMEOUT);
                            (void) g_sf_comms_usb1.p_api->write(g_sf_comms_usb1.p_ctrl, send, length, TX_WAIT_FOREVER);
                            break;
                        }
                        case GYR_WRITE:
                        {
                            (void) g_sf_i2c_device_gyro.p_api->write(g_sf_i2c_device_gyro.p_ctrl, &recieve[i+3], length, false, IIC_TIMEOUT);;
                            break;
                        }
                        case GYR_READ:
                        {
                            (void) g_sf_i2c_device_gyro.p_api->read(g_sf_i2c_device_gyro.p_ctrl, send, length, false, IIC_TIMEOUT);
                            (void) g_sf_comms_usb1.p_api->write(g_sf_comms_usb1.p_ctrl, send, length, TX_WAIT_FOREVER);
                            break;
                        }

                        case MAG_WRITE:
                        {
                            (void) g_sf_i2c_device_mag.p_api->write(g_sf_i2c_device_mag.p_ctrl, &recieve[i+3], length, false, IIC_TIMEOUT);;
                            break;
                        }
                        case MAG_READ:
                        {
                            (void) g_sf_i2c_device_mag.p_api->read(g_sf_i2c_device_mag.p_ctrl, send, length, false, IIC_TIMEOUT);
                            (void) g_sf_comms_usb1.p_api->write(g_sf_comms_usb1.p_ctrl, send, length, TX_WAIT_FOREVER);
                            break;
                        }

                        /*No address found, error*/
                        default:
                        {
                            break;
                        }
                    }

                    break;
                }

                default:
                {
                    /*Packet begins not with a start char, error*/
                    break;
                }
            }

            i=0;
            length=0;
        }
        else
        {
            tx_thread_sleep(1);
        }
    }
}
