/***********************************************************************************************************************
* File Name    : button_processing_thread_entry.c
* Description  : This file contains button thread function which handles User Button event in this application.
***********************************************************************************************************************/
/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2017 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

#include "button_processing_thread.h"
#include "push_button_switch.h"
#include "config_s3a7.h"
#include "util.h"
#include "common.h"
#include "led_control.h"

/* Function prototypes */
void button_processing_thread_entry(void);
static void push_button_switch_init (void);

#define PB_SWITCH_INFO(N)                       \
    {                                           \
        .level = IOPORT_LEVEL_LOW,              \
        .pin = PB_SWITCH_##N##_PIN,             \
        .triggered = false,                     \
        .irq = &PB_SWITCH_##N##_IRQ_INSTANCE,   \
     }                                          \

#if (PB_SWITCH_COUNT > 0) && defined (PB_SWITCH)
static pb_switch_irq_t pb_switch[] =
{
#if (PB_SWITCH_COUNT > 0) && defined (PB_SWITCH_1_PIN)
    PB_SWITCH_INFO(1),
#endif
};
#endif

#define PB_SWITCH_DEFAULT_STATUS(N)  \
    {                                \
        .pb_switch_num = N,          \
        .level = PB_RELEASED,        \
    }                                \

#if (PB_SWITCH_COUNT > 0) && defined (PB_SWITCH)
static pb_switch_payload_t pb_switch_message[] =
{
#if (PB_SWITCH_COUNT > 0) && defined (PB_SWITCH_1_PIN)
 PB_SWITCH_DEFAULT_STATUS(1),
#endif
#if (PB_SWITCH_COUNT > 1) && defined (PB_SWITCH_2_PIN)
 PB_SWITCH_DEFAULT_STATUS(2),
#endif
};
#endif

static pb_switch_context_t context =
{
    .pb_sem = &pb_switch_sem,
    .pb_msg = &pb_switch_message[0],
#if PB_SWITCH_COUNT > 0 && defined (PB_SWITCH)
    .pb_switch = &pb_switch[0],
    .count = nelem (pb_switch),
#endif
};

/*******************************************************************************************************************//**
 * @brief  push_button_switch_init function
 *
 * This function handles button_init, initializes button related interrupts,
 * this code is used by multiple boards where some PINs might be initialized in
 * the BSP with single edge, this guarantees both edges are used.
 **********************************************************************************************************************/
static void push_button_switch_init (void)
{
#if PB_SWITCH_COUNT > 0 && defined (PB_SWITCH)
    ssp_err_t err;

    for (int i = 0; i < inelem (pb_switch); i++)
    {
        // guarantee both edges, Since we need event for both Switch press and Release.

        err = context.pb_switch[i].irq->p_api->open(context.pb_switch[i].irq->p_ctrl, context.pb_switch[i].irq->p_cfg);

        if (SSP_SUCCESS == err)
        {
            // make sure we have access to this in the interrupt handler
           // context.pb_switch[i].irq->p_ctrl->p_context = (void*) &pb_switch[i].irq;
            // init
            context.pb_switch[i].triggered = false;
        }
    }
#endif
}

/*******************************************************************************************************************//**
 * @brief  Button Thread entry function
 *
 * This Button Thread function handles all user button events in this application.
 * Based on the user button event, it creates a queue message and pushes it to USB thread for
 * processing.
 *
 **********************************************************************************************************************/
void button_processing_thread_entry(void)
{
    pb_switch_context_t *ctx = &context;
    pb_switch_irq_t *pbs_irq = ctx->pb_switch;

    ioport_port_pin_t cell_reset = CELL_RESET_CTRL_PIN;
    ioport_port_pin_t gnss_reset = GNSS_RESET_CTRL_PIN;
    ioport_port_pin_t charger_ctrl = CHARGER_CTRL_PIN;
    ioport_port_pin_t cell_pwr_ctrl = CELL_POWER_CTRL_PIN;
    ioport_port_pin_t gnss_pwr_ctrl = GNSS_POWER_CTRL_PIN;
    ioport_port_pin_t button_pin = PB_SWITCH_1_PIN;
    ioport_level_t button_level = IOPORT_LEVEL_HIGH;
    static _Bool power_status;

    push_button_switch_init ();

    /*Enable Power for Charger, Cellular and GNSS, Reset pins must be in HIGH state*/
    g_ioport.p_api->pinWrite(cell_reset, IOPORT_LEVEL_LOW);
    g_ioport.p_api->pinWrite(gnss_reset, IOPORT_LEVEL_LOW);
    g_ioport.p_api->pinWrite(cell_pwr_ctrl, IOPORT_LEVEL_HIGH);
    g_ioport.p_api->pinWrite(gnss_pwr_ctrl, IOPORT_LEVEL_HIGH);
    g_ioport.p_api->pinWrite(charger_ctrl, IOPORT_LEVEL_LOW);
    power_status = true;

    while (pbs_irq)
    {
        /* Wait for a button event */
        tx_semaphore_get (ctx->pb_sem, TX_WAIT_FOREVER);

        for (uint8_t i = 0; i < ctx->count; i++)
        {
            /* we got at least one button */
            if (pbs_irq[i].triggered)
            {
                if(pbs_irq[i].level == IOPORT_LEVEL_HIGH)
                {
                    ctx->pb_msg->level = PB_RELEASED;
                }
                else if(pbs_irq[i].level == IOPORT_LEVEL_LOW)
                {
                    ctx->pb_msg->level =  PB_PRESSED;
                }

                ctx->pb_msg->pb_switch_num = (uint8_t)(i+SWITCH_1);
                ctx->pb_msg->msg_hdr.hdr_val = PUSH_BUTTON;

                pbs_irq[i].triggered = false;
            }

            /*Reset Modules and charger if button was released*/
            if ((ctx->pb_msg->pb_switch_num == SWITCH_1) && (ctx->pb_msg->level == PB_RELEASED))
            {

                /*Pull the reset pins DOWN by enabling MOSFETs*/
                g_ioport.p_api->pinWrite(cell_reset, IOPORT_LEVEL_HIGH);
                g_ioport.p_api->pinWrite(gnss_reset, IOPORT_LEVEL_HIGH);
                g_ioport.p_api->pinWrite(charger_ctrl, IOPORT_LEVEL_HIGH);

                /*Indicate button action*/
                if(!g_led_semaphore.tx_semaphore_count)
                {
                    tx_semaphore_put (&g_led_semaphore);
                    tx_semaphore_put (&g_led_semaphore);
                    tx_semaphore_put (&g_led_semaphore);
                }

                /*Keep it on for 500 milliseconds*/
                tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND/2));

                /*Pull the reset pins UP by disabling MOSFETs*/
                g_ioport.p_api->pinWrite(cell_reset, IOPORT_LEVEL_LOW);
                g_ioport.p_api->pinWrite(gnss_reset, IOPORT_LEVEL_LOW);
                g_ioport.p_api->pinWrite(charger_ctrl, IOPORT_LEVEL_LOW);
            }

            /*If button is pressed and held for 3 seconds - shut down power supply for Cellular and GNSS modules*/
            else if ((ctx->pb_msg->pb_switch_num == SWITCH_1) && (ctx->pb_msg->level == PB_PRESSED))
            {
                /*Wait for 3000 milliseconds*/
                tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND*3));
                g_ioport.p_api->pinRead(button_pin, &button_level);

                if(button_level == IOPORT_LEVEL_LOW)
                {
                    if(power_status)
                    {
                        g_ioport.p_api->pinWrite(cell_pwr_ctrl, IOPORT_LEVEL_LOW);
                        g_ioport.p_api->pinWrite(gnss_pwr_ctrl, IOPORT_LEVEL_LOW);
                        g_ioport.p_api->pinWrite(charger_ctrl, IOPORT_LEVEL_HIGH);

                        /* short led signal*/
                        tx_semaphore_put (&g_led_semaphore);
                        tx_semaphore_put (&g_led_semaphore);
                        tx_semaphore_put (&g_led_semaphore);
                        power_status = false;
                    }
                    else
                    {
                        g_ioport.p_api->pinWrite(cell_pwr_ctrl, IOPORT_LEVEL_HIGH);
                        g_ioport.p_api->pinWrite(gnss_pwr_ctrl, IOPORT_LEVEL_HIGH);
                        g_ioport.p_api->pinWrite(charger_ctrl, IOPORT_LEVEL_LOW);

                        /* long led signal*/
                        tx_semaphore_put (&g_led_semaphore);
                        tx_semaphore_put (&g_led_semaphore);
                        tx_semaphore_put (&g_led_semaphore);
                        tx_semaphore_put (&g_led_semaphore);
                        tx_semaphore_put (&g_led_semaphore);
                        tx_semaphore_put (&g_led_semaphore);
                        tx_semaphore_put (&g_led_semaphore);
                        tx_semaphore_put (&g_led_semaphore);
                        tx_semaphore_put (&g_led_semaphore);
                        tx_semaphore_put (&g_led_semaphore);
                        tx_semaphore_put (&g_led_semaphore);
                        tx_semaphore_put (&g_led_semaphore);
                        tx_semaphore_put (&g_led_semaphore);
                        tx_semaphore_put (&g_led_semaphore);
                        tx_semaphore_put (&g_led_semaphore);
                        power_status = true;
                    }
                }
            }
        }
    }
}
/*******************************************************************************************************************//**
 * @brief  pb_switch_event_callback function
 *
 * This callback function handles all the user button event in this application.
 *
 **********************************************************************************************************************/
static void pb_switch_event_callback(pb_switch_context_t *ctx, int n, external_irq_callback_args_t * p_args)
{
#if PB_SWITCH_COUNT > 0 && defined (PB_SWITCH)
    if(p_args)
    {
        int pos = n - 1;

        // Regardless of Falling or Rising edge, event callback gets called. Falling edge means Push button switch pressed.
        // Rising edge means the Push button switch is released. When the Switch pressed or released generates interrupt
        // on the Falling or rising edge. This triggers the callback. We need is to post a semaphore and remember
        // what button generated the trigger.

        g_ioport.p_api->pinRead(ctx->pb_switch[pos].pin, &ctx->pb_switch[pos].level);

        ctx->pb_switch[pos].triggered = true;

        // post the semaphore
        tx_semaphore_put (ctx->pb_sem);
    }
#endif
}

/*******************************************************************************************************************//**
 * @brief  PB_SWITCH_1_IRQ_CALLBACK function
 *
 * This Interrupt handler callback function handles the user button 1 event in this application.
 *
 **********************************************************************************************************************/
#ifdef PB_SWITCH_1_IRQ_CALLBACK
void PB_SWITCH_1_IRQ_CALLBACK (external_irq_callback_args_t * p_args)
{
    pb_switch_event_callback (&context, SWITCH_1, p_args);
}
#endif
