#include "led_control.h"
#include "util.h"

/* LED Thread entry function */
void led_control_entry(void)
{
    ssp_err_t err;

    /* LED type structure */
    bsp_leds_t leds;

    /* Get LED information for this board */
    err = R_BSP_LedsGet(&leds);

    if(err)
    {
        /*No LEDs declared?*/
        APP_ERR_TRAP(err);
    }

    while (1)
    {
        /* Wait for a LED semaphore */
        tx_semaphore_get (&g_led_semaphore, TX_WAIT_FOREVER);

        /*Turn on LED*/
        g_ioport.p_api->pinWrite(leds.p_leds[0], IOPORT_LEVEL_LOW);

        /*Keep it on for a while*/
        tx_thread_sleep ((ULONG)(TX_TIMER_TICKS_PER_SECOND/100));

        /*Turn off LED*/
        g_ioport.p_api->pinWrite(leds.p_leds[0], IOPORT_LEVEL_HIGH);
    }
}
