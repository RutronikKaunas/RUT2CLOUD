#include "SCI0_receive_thread.h"
#include "usb_thread0.h"
#include "led_control.h"
#include "common.h"
#include "util.h"

/* SCI0 Receive Thread entry function */
void SCI0_receive_thread_entry(void)
{
    ssp_err_t ReturnVal = SSP_SUCCESS;
    uint8_t data;

    while (1)
    {

        if (NULL != ((sf_el_ux_comms_instance_ctrl_t*)g_sf_comms0.p_ctrl)->p_cdc )
        {
            /*Receive data from SCI0*/
            ReturnVal = g_sf_comms0.p_api->read(g_sf_comms0.p_ctrl, &data, sizeof(data), TX_WAIT_FOREVER);

            /*Indicate active communications*/
            if(!g_led_semaphore.tx_semaphore_count)
            {
                tx_semaphore_put (&g_led_semaphore);
            }

            /*Send the data to VCOM0*/
            if(ReturnVal == SSP_SUCCESS)
            {
                /*Check if VCOM0 is initialised*/
                if (NULL != ((sf_el_ux_comms_instance_ctrl_t*)g_sf_comms_usb0.p_ctrl)->p_cdc )
                {
                    (void) g_sf_comms_usb0.p_api->write(g_sf_comms_usb0.p_ctrl, &data, sizeof(data), TX_WAIT_FOREVER);
                }
            }
        }
        else
        {
            tx_thread_sleep(1);
        }

    }
}
