/*
 * common.h
 *
 *  Created on: 7 Sep 2018
 *      Author: GDR
 */

#ifndef COMMON_H_
#define COMMON_H_

#include "hal_data.h"

#define STRING_LEN 33

typedef enum {
    PUSH_BUTTON = 1,
}EVENT_TYPE;

typedef struct
{
    EVENT_TYPE hdr_val;
} msg_hdr_t;


typedef struct
{   msg_hdr_t msg_hdr;
    uint8_t pb_switch_num;
    uint8_t level;
} pb_switch_payload_t;

#define BME_READ        0xEF
#define BME_WRITE       0xEE
#define IIC_TIMEOUT     100
#define ACC_READ        0x33
#define ACC_WRITE       0x32
#define GYR_READ        0xD3
#define GYR_WRITE       0xD2
#define MAG_READ        0x27
#define MAG_WRITE       0x26

#endif /* COMMON_H_ */
