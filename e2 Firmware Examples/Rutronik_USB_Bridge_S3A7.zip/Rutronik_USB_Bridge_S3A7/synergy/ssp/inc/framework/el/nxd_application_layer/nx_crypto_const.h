/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2017 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Crypto Component                                                 */
/**                                                                       */
/**   Crypto                                                              */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/


/**************************************************************************/
/*                                                                        */
/*  COMPONENT DEFINITION                                   RELEASE        */
/*                                                                        */
/*    nx_crypto_const.h                                  PORTABLE C       */
/*                                                           5.11         */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Timothy Stapko, Express Logic, Inc.                                 */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This file defines the NetX Security Encryption component.           */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-15-2017     Timothy Stapko           Initial Version 5.11          */
/*                                                                        */
/**************************************************************************/

#ifndef _NX_CRYPTO_CONST_H_
#define _NX_CRYPTO_CONST_H_


/* Define the encryption algorithm, as outlined in RFC 4305 3.1.1 */
/* These values are used in nx_crypto_algorithm field. */
/* These values are the same as defined in RFC 5996 3.3.2 */
#define NX_CRYPTO_NONE                           0
#define NX_CRYPTO_ENCRYPTION_DES_IV64            1
#define NX_CRYPTO_ENCRYPTION_DES_CBC             2
#define NX_CRYPTO_ENCRYPTION_3DES_CBC            3
#define NX_CRYPTO_ENCRYPTION_RC5                 4
#define NX_CRYPTO_ENCRYPTION_IDEA                5
#define NX_CRYPTO_ENCRYPTION_CAST                6
#define NX_CRYPTO_ENCRYPTION_BLOWFISH            7
#define NX_CRYPTO_ENCRYPTION_3IDEA               8
#define NX_CRYPTO_ENCRYPTION_DES_IV32            9
#define NX_CRYPTO_ENCRYPTION_NULL                11
#define NX_CRYPTO_ENCRYPTION_AES_CBC             12
#define NX_CRYPTO_ENCRYPTION_AES_CTR             13
#define NX_CRYPTO_ENCRYPTION_AES_CCM_8           14
#define NX_CRYPTO_ENCRYPTION_AES_CCM_12          15
#define NX_CRYPTO_ENCRYPTION_AES_CCM_16          16
#define NX_CRYPTO_ENCRYPTION_AES_GCM_8           18
#define NX_CRYPTO_ENCRYPTION_AES_GCM_12          19
#define NX_CRYPTO_ENCRYPTION_AES_GCM_16          20
#define NX_CRYPTO_ENCRYPTION_NULL_AUTH_AES_GMAC  21
#define NX_CRYPTO_ENCRYPTION_CAMELLIA_CBC        23
#define NX_CRYPTO_ENCRYPTION_CAMELLIA_CTR        24
#define NX_CRYPTO_ENCRYPTION_CAMELLIA_CCM_8      25
#define NX_CRYPTO_ENCRYPTION_CAMELLIA_CCM_12     26
#define NX_CRYPTO_ENCRYPTION_CAMELLIA_CCM_16     27
#define NX_CRYPTO_ENCRYPTION_CHACHA20_POLY1305   28


/* Define the authentication algorithm, as outlined in RFC 4305 3.2 */
/* See also: https://www.iana.org/assignments/ikev2-parameters/ikev2-parameters.xhtml */
/* These values are used in nx_crypto_algorithm field. */
/* These values are the same as defined in RFC 5996 3.3.2 */
#define NX_CRYPTO_AUTHENTICATION_NONE            0
#define NX_CRYPTO_AUTHENTICATION_HMAC_MD5_96     1
#define NX_CRYPTO_AUTHENTICATION_HMAC_SHA1_96    2
#define NX_CRYPTO_AUTHENTICATION_DES_MAC         3
#define NX_CRYPTO_AUTHENTICATION_KPDK_MD5        4
#define NX_CRYPTO_AUTHENTICATION_AES_XCBC_MAC_96 5
#define NX_CRYPTO_AUTHENTICATION_HMAC_MD5_128    6
#define NX_CRYPTO_AUTHENTICATION_HMAC_SHA1_160   7
#define NX_CRYPTO_AUTHENTICATION_AES_CMAC_96     8
#define NX_CRYPTO_AUTHENTICATION_AES_128_GMAC    9
#define NX_CRYPTO_AUTHENTICATION_AES_192_GMAC    10
#define NX_CRYPTO_AUTHENTICATION_AES_256_GMAC    11
#define NX_CRYPTO_AUTHENTICATION_HMAC_SHA2_256   12
#define NX_CRYPTO_AUTHENTICATION_HMAC_SHA2_384   13
#define NX_CRYPTO_AUTHENTICATION_HMAC_SHA2_512   14

/* Define the Pseudorandom Function algorithm */
/* These values are used in nx_crypto_algorithm field. */
/* These values are the same as defined in RFC 5996 3.3.2 */
#define NX_CRYPTO_PRF_HMAC_MD5                   1
#define NX_CRYPTO_PRF_HMAC_SHA1                  2
#define NX_CRYPTO_PRF_HMAC_TIGER                 3
#define NX_CRYPTO_PRF_HMAC_AES128_XCBC           4
#define NX_CRYPTO_PRF_HMAC_SHA2_256              5
#define NX_CRYPTO_PRF_HMAC_SHA2_384              6
#define NX_CRYPTO_PRF_HMAC_SHA2_512              7

/* Define crypto ICV bits size. */
#define NX_CRYPTO_AUTHENTICATION_ICV_TRUNC_BITS  96

#ifndef NX_CRYPTO_MAX_IV_SIZE_IN_BITS
#define NX_CRYPTO_MAX_IV_SIZE_IN_BITS            192
#endif /* NX_CRYPTO_MAX_IV_SIZE_IN_BYTES */

/* Define values used for nx_crypto_type. */
#define NX_CRYPTO_ENCRYPT                        1    /* ESP Encrypt (egress) */
#define NX_CRYPTO_DECRYPT                        2    /* ESP Decrypt (ingress) */
#define NX_CRYPTO_AUTHENTICATE                   3    /* AH Authenticate (egress) */
#define NX_CRYPTO_VERIFY                         4    /* AH Verify (ingress) */
#define NX_CRYPTO_HASH_INITIALIZE                5    /* Hash initialize */
#define NX_CRYPTO_HASH_UPDATE                    6    /* Hash update */
#define NX_CRYPTO_HASH_CALCULATE                 7    /* Hash calculate */
#define NX_CRYPTO_PRF                            8    /* For the TLS PRF function. */
#define NX_CRYPTO_SET_PRIME_P                    9    /* Set Prime number P.  This is used in software RSA implementation. */
#define NX_CRYPTO_SET_PRIME_Q                    10   /* Set Prime number Q.  This is used in software RSA implementation. */
#define NX_CRYPTO_SET_ADDITIONAL_DATA            11   /* Set additional data pointer and length.*/

/* ECJPAKE operations. */
#define NX_CRYPTO_ECJPAKE_HASH_METHOD_SET        11
#define NX_CRYPTO_ECJPAKE_CURVE_SET              12
#define NX_CRYPTO_ECJPAKE_HELLO_GENERATE         13
#define NX_CRYPTO_ECJPAKE_HELLO_PROCESS          14
#define NX_CRYPTO_ECJPAKE_KEY_EXCHANGE_GENERATE  15
#define NX_CRYPTO_ECJPAKE_KEY_EXCHANGE_PROCESS   16

/* Define align MACRO to a byte boundry. */
#define NX_CRYPTO_ALIGN8(len)                    (((len) + 7) & ~7)

/* Find the offset of a structure. */
#define NX_CRYPTO_OFFSET(a, b)                   ((ULONG)(&(((a *)(0)) -> b)))


typedef USHORT NX_CRYPTO_KEY_SIZE;

#define NX_CRYPTO_SUCCESS                        0x0          /* Function returned successfully. */
#define NX_CRYPTO_AES_UNSUPPORTED_KEY_SIZE       0x1001       /* An unknown key size was used in an AES operation. */
#define NX_CRYPTO_AUTHENTICATION_FAILED          0x1002       /* Authentication failed.  */

#endif /* _NX_CRYPTO_H_ */

