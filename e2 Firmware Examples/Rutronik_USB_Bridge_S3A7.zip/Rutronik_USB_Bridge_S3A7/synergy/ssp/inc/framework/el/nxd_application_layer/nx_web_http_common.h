/**************************************************************************/
/*                                                                        */  
/*            Copyright (c) 1996-2018 by Express Logic Inc.               */ 
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Component                                                        */
/**                                                                       */
/**   Hypertext Transfer Protocol (HTTP)                                  */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/


/**************************************************************************/
/*                                                                        */
/*  APPLICATION INTERFACE DEFINITION                       RELEASE        */
/*                                                                        */
/*    nx_web_http_common.h                                PORTABLE C      */
/*                                                           5.10         */
/*  AUTHOR                                                                */
/*                                                                        */
/*    William E. Lamie, Express Logic, Inc.                               */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This file defines the NetX Web Hypertext Transfer Protocol (HTTP)   */
/*    component, including all data types and external references.        */
/*    It is assumed that nx_api.h and nx_port.h have already been         */
/*    included, along with fx_api.h and fx_port.h. If HTTPS is being used */
/*    then nx_secure_tls_api.h must also be included.                     */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  05-15-2018     Timothy Stapko           Initial Version 5.10          */
/*                                                                        */
/**************************************************************************/

#ifndef NX_WEB_HTTP_COMMON_H
#define NX_WEB_HTTP_COMMON_H

/* Determine if a C++ compiler is being used.  If so, ensure that standard
   C is used to process the API information.  */

#ifdef   __cplusplus

/* Yes, C++ compiler is present.  Use standard C.  */
extern   "C" {

#endif

/* Define the HTTP version.  */
#define NX_WEB_HTTP_VERSION                     "HTTP/1.1"
    
/* Define HTTP TCP socket create options.  */

#ifndef NX_WEB_HTTP_TYPE_OF_SERVICE
#define NX_WEB_HTTP_TYPE_OF_SERVICE             NX_IP_NORMAL
#endif

#ifndef NX_WEB_HTTP_FRAGMENT_OPTION
#define NX_WEB_HTTP_FRAGMENT_OPTION             NX_DONT_FRAGMENT
#endif

#ifndef NX_WEB_HTTP_TIME_TO_LIVE
#define NX_WEB_HTTP_TIME_TO_LIVE                0x80
#endif

#ifndef NX_WEB_HTTP_MAX_RESOURCE
#define NX_WEB_HTTP_MAX_RESOURCE                40
#endif

#ifndef NX_WEB_HTTP_MAX_NAME
#define NX_WEB_HTTP_MAX_NAME                    20
#endif

#ifndef NX_WEB_HTTP_MAX_PASSWORD
#define NX_WEB_HTTP_MAX_PASSWORD                20
#endif

#ifndef NX_PHYSICAL_TRAILER
#define NX_PHYSICAL_TRAILER                     4
#endif

#define NX_WEB_HTTP_MAX_STRING                  (NX_WEB_HTTP_MAX_NAME + NX_WEB_HTTP_MAX_PASSWORD + (NX_WEB_HTTP_MAX_NAME + NX_WEB_HTTP_MAX_PASSWORD)/2)

#define NX_WEB_HTTP_MAX_BINARY_MD5              16
#define NX_WEB_HTTP_MAX_ASCII_MD5               33


/* Define return code constants.  */
#define NX_WEB_HTTP_ERROR                       0x30000        /* HTTP internal error                                  */
#define NX_WEB_HTTP_TIMEOUT                     0x30001        /* HTTP timeout occurred                                */
#define NX_WEB_HTTP_FAILED                      0x30002        /* HTTP error                                           */
#define NX_WEB_HTTP_DONT_AUTHENTICATE           0x30003        /* HTTP authentication not needed                       */
#define NX_WEB_HTTP_BASIC_AUTHENTICATE          0x30004        /* HTTP basic authentication requested                  */
#define NX_WEB_HTTP_DIGEST_AUTHENTICATE         0x30005        /* HTTP digest authentication requested                 */
#define NX_WEB_HTTP_NOT_FOUND                   0x30006        /* HTTP request not found                               */
#define NX_WEB_HTTP_DATA_END                    0x30007        /* HTTP end of content area                             */
#define NX_WEB_HTTP_CALLBACK_COMPLETED          0x30008        /* HTTP user callback completed the processing          */
#define NX_WEB_HTTP_POOL_ERROR                  0x30009        /* HTTP supplied pool payload is too small              */
#define NX_WEB_HTTP_NOT_READY                   0x3000A        /* HTTP client not ready for operation                  */
#define NX_WEB_HTTP_AUTHENTICATION_ERROR        0x3000B        /* HTTP client authentication failed                    */
#define NX_WEB_HTTP_GET_DONE                    0x3000C        /* HTTP client get is complete                          */
#define NX_WEB_HTTP_BAD_PACKET_LENGTH           0x3000D        /* Invalid packet received - length incorrect           */
#define NX_WEB_HTTP_REQUEST_UNSUCCESSFUL_CODE   0x3000E        /* Received an error code instead of 2xx from server    */
#define NX_WEB_HTTP_INCOMPLETE_PUT_ERROR        0x3000F        /* Server responds before PUT is complete               */
#define NX_WEB_HTTP_PASSWORD_TOO_LONG           0x30011        /* Password exceeded expected length                    */
#define NX_WEB_HTTP_USERNAME_TOO_LONG           0x30012        /* Username exceeded expected length                    */
#define NX_WEB_HTTP_NO_QUERY_PARSED             0x30013        /* Server unable to find query in client request        */
#define NX_WEB_HTTP_METHOD_ERROR                0x30014        /* Client method (e.g. GET, POST) was missing required information. */
#define NX_WEB_HTTP_IMPROPERLY_TERMINATED_PARAM 0x30015        /* Client request parameter not properly terminated     */
#define NX_WEB_HTTP_BOUNDARY_ALREADY_FOUND      0x30016        /* Boundary is already found.                           */
#define NX_WEB_HTTP_MISSING_CONTENT_LENGTH      0x30017        /* The Content-Length header was not found.             */
#define NX_WEB_HTTP_EXTENSION_NOT_FOUND         0x30018        /* A searched-for HTTP type extension was not found.    */
#define NX_WEB_HTTP_EXTENSION_MIME_DEFAULT      0x30019        /* No matching extension found, return default.         */
/* Define the HTTP Server TCP port number */

#define NX_WEB_HTTP_SERVER_PORT               80        /* Port for HTTP server                                 */
#define NX_WEB_HTTPS_SERVER_PORT             443        /* Port for HTTPS server.                               */

/* Define constants for the various HTTP methods supported. */
#define NX_WEB_HTTP_METHOD_NONE             0x0
#define NX_WEB_HTTP_METHOD_GET              0x1
#define NX_WEB_HTTP_METHOD_PUT              0x2
#define NX_WEB_HTTP_METHOD_POST             0x3
#define NX_WEB_HTTP_METHOD_DELETE           0x4
#define NX_WEB_HTTP_METHOD_HEAD             0x5

/* Define status codes. */
#define NX_WEB_HTTP_STATUS_CONTINUE             "100 Continue"
#define NX_WEB_HTTP_STATUS_SWITCHING_PROTOCOLS  "101 Switching Protocols"
#define NX_WEB_HTTP_STATUS_OK                   "200 OK"
#define NX_WEB_HTTP_STATUS_CREATED              "201 Created"
#define NX_WEB_HTTP_STATUS_ACCEPTED             "202 Accepted"
#define NX_WEB_HTTP_STATUS_NON_AUTH_INFO        "203 Non-Authoritative Information"
#define NX_WEB_HTTP_STATUS_NO_CONTENT           "204 No Content"
#define NX_WEB_HTTP_STATUS_RESET_CONTENT        "205 Reset Content"
#define NX_WEB_HTTP_STATUS_PARTIAL_CONTENT      "206 Partial Content"
#define NX_WEB_HTTP_STATUS_MULTIPLE_CHOICES     "300 Multiple Choices"
#define NX_WEB_HTTP_STATUS_MOVED_PERMANETLY     "301 Moved Permanently"
#define NX_WEB_HTTP_STATUS_FOUND                "302 Found"
#define NX_WEB_HTTP_STATUS_SEE_OTHER            "303 See Other"
#define NX_WEB_HTTP_STATUS_NOT_MODIFIED         "304 Not Modified"
#define NX_WEB_HTTP_STATUS_USE_PROXY            "305 Use Proxy"
#define NX_WEB_HTTP_STATUS_TEMPORARY_REDIRECT   "307 Temporary Redirect"
#define NX_WEB_HTTP_STATUS_BAD_REQUEST          "400 Bad Request"
#define NX_WEB_HTTP_STATUS_UNAUTHORIZED         "401 Unauthorized"
#define NX_WEB_HTTP_STATUS_PAYMENT_REQUIRED     "402 Payment Required"
#define NX_WEB_HTTP_STATUS_FORBIDDEN            "403 Forbidden"
#define NX_WEB_HTTP_STATUS_NOT_FOUND            "404 Not Found"
#define NX_WEB_HTTP_STATUS_METHOD_NOT_ALLOWED   "405 Method Not Allowed"
#define NX_WEB_HTTP_STATUS_NOT_ACCEPTABLE       "406 Not Acceptable"
#define NX_WEB_HTTP_STATUS_PROXY_AUTH_REQUIRED  "407 Proxy Authentication Required"
#define NX_WEB_HTTP_STATUS_REQUEST_TIMEOUT      "408 Request Time-out"
#define NX_WEB_HTTP_STATUS_CONFLICT             "409 Conflict"
#define NX_WEB_HTTP_STATUS_GONE                 "410 Gone"
#define NX_WEB_HTTP_STATUS_LENGTH_REQUIRED      "411 Length Required"
#define NX_WEB_HTTP_STATUS_PRECONDITION_FAILED  "412 Precondition Failed"
#define NX_WEB_HTTP_STATUS_ENTITY_TOO_LARGE     "413 Request Entity Too Large"
#define NX_WEB_HTTP_STATUS_URL_TOO_LARGE        "414 Request-URL Too Large"
#define NX_WEB_HTTP_STATUS_UNSUPPORTED_MEDIA    "415 Unsupported Media Type"
#define NX_WEB_HTTP_STATUS_RANGE_NOT_SATISFY    "416 Requested range not satisfiable"
#define NX_WEB_HTTP_STATUS_EXPECTATION_FAILED   "417 Expectation Failed"
#define NX_WEB_HTTP_STATUS_INTERNAL_ERROR       "500 Internal Server Error"
#define NX_WEB_HTTP_STATUS_NOT_IMPLEMENTED      "501 Not Implemented"
#define NX_WEB_HTTP_STATUS_BAD_GATEWAY          "502 Bad Gateway"
#define NX_WEB_HTTP_STATUS_SERVICE_UNAVAILABLE  "503 Service Unavailable"
#define NX_WEB_HTTP_STATUS_GATEWAY_TIMEOUT      "504 Gateway Time-out"
#define NX_WEB_HTTP_STATUS_VERSION_ERROR        "505 HTTP Version not supported"


/* Define the max length of header field. */

#ifndef NX_WEB_HTTP_MAX_HEADER_FIELD            
#define NX_WEB_HTTP_MAX_HEADER_FIELD            256
#endif

/* Determine if a C++ compiler is being used.  If so, complete the standard
   C conditional started above.  */
#ifdef   __cplusplus
        }
#endif

#endif  /* NX_WEB_HTTP_COMMON_H */
