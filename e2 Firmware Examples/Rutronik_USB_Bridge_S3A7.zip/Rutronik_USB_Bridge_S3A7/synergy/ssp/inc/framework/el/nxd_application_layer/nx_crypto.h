/**************************************************************************/
/*                                                                        */
/*            Copyright (c) 1996-2017 by Express Logic Inc.               */
/*                                                                        */
/*  This software is copyrighted by and is the sole property of Express   */
/*  Logic, Inc.  All rights, title, ownership, or other interests         */
/*  in the software remain the property of Express Logic, Inc.  This      */
/*  software may only be used in accordance with the corresponding        */
/*  license agreement.  Any unauthorized use, duplication, transmission,  */
/*  distribution, or disclosure of this software is expressly forbidden.  */
/*                                                                        */
/*  This Copyright notice may not be removed or modified without prior    */
/*  written consent of Express Logic, Inc.                                */
/*                                                                        */
/*  Express Logic, Inc. reserves the right to modify this software        */
/*  without notice.                                                       */
/*                                                                        */
/*  Express Logic, Inc.                     info@expresslogic.com         */
/*  11423 West Bernardo Court               http://www.expresslogic.com   */
/*  San Diego, CA  92127                                                  */
/*                                                                        */
/**************************************************************************/


/**************************************************************************/
/**************************************************************************/
/**                                                                       */
/** NetX Crypto Component                                                 */
/**                                                                       */
/**   Crypto                                                              */
/**                                                                       */
/**************************************************************************/
/**************************************************************************/


/**************************************************************************/
/*                                                                        */
/*  COMPONENT DEFINITION                                   RELEASE        */
/*                                                                        */
/*    nx_crypto.h                                         PORTABLE C      */
/*                                                           5.11         */
/*  AUTHOR                                                                */
/*                                                                        */
/*    Timothy Stapko, Express Logic, Inc.                                 */
/*                                                                        */
/*  DESCRIPTION                                                           */
/*                                                                        */
/*    This file defines the NetX Security Encryption component.           */
/*                                                                        */
/*  RELEASE HISTORY                                                       */
/*                                                                        */
/*    DATE              NAME                      DESCRIPTION             */
/*                                                                        */
/*  12-15-2017     Timothy Stapko           Initial Version 5.11          */
/*                                                                        */
/**************************************************************************/

#ifndef _NX_CRYPTO_H_
#define _NX_CRYPTO_H_

#include "nx_api.h"
#include "nx_crypto_const.h"

/* Note that both input and output packets are prepared by the
   caller. For encryption/decryption operations, the callee shall
   use the output buffer for encrypted or decrypted data. For
   authentication operations, the callee shall use the output
   buffer for the digest.
   'crypto_metadata' Pointer to a storage space managed by the underlying crypto method.
   The content of this block is defined by each sa in use.
   'crypto_metadata_size' is the size of the crypto context block, in bytes. */
typedef struct NX_CRYPTO_INFO_STRUCT
{
    USHORT             nx_crypto_op;            /* Encrypt, Decrypt, Authenticate, Verify */
    NX_CRYPTO_KEY_SIZE nx_crypto_key_size_in_bits;
    UCHAR             *nx_crypto_key;
    UCHAR             *nx_crypto_iv_ptr;
    UCHAR             *nx_crypto_input;
    UCHAR             *nx_crypto_output;
    USHORT             nx_crypto_input_length_in_byte;
    USHORT             nx_crypto_output_length_in_byte;
    VOID              *nx_crypto_metadata;
    USHORT             nx_crypto_metadata_size;
    USHORT             nx_crypto_algorithm;
    volatile UINT      nx_crypto_status;
    VOID                (*nx_crypto_hw_process_callback)(VOID *packet_ptr, UINT status);
} NX_CRYPTO_INFO;

/* Notes on *nx_crypto_operation:
   The crypto method strcuture contains a function pointer: nx_crypto_operation.

   This function pointer should be set for the crypto method in use.  The arguments to this function are:
   nx_crypto_operation(UINT operation, UINT protocol, NX_CRYPTO_METHOD* crypto_method_ptr, NX_PACKET *packet_ptr)

   ESP/AH process invokes this function, specifies the operation to perform (encrypt, decrypt,
   digest computation, and the packet (data) to be performed on.

   This routine shall return SUCCESS/FAILURE on return.  */

typedef struct NX_CRYPTO_METHOD_STRUCT
{
    /* Name of the algorithm. For example:
       NX_CRYPTO_ENCRYPTOIN_3DES_CBC or NX_CRYPTO_AUTHENTICATION_HMAC_SHA1_96.
       Refer to nx_crypto.h for a list of symbols used in this field. User may
       wish to extend the list. */
    USHORT nx_crypto_algorithm;

    /* Size of the key, in bits. */
    USHORT nx_crypto_key_size_in_bits;

    /* Size of the IV block, in bits. This is used for encryption. */
    USHORT nx_crypto_IV_size_in_bits;

    /* Size of the ICV block, in bits. This is used for authentication. */
    USHORT nx_crypto_ICV_size_in_bits;

    /* Size of the crypto block, in bytes. */
    ULONG nx_crypto_block_size_in_bytes;

    /* Size of the meta data area, in bytes. */
    ULONG nx_crypto_metadata_area_size;

    /* nx_cyrpto_init function initializes the underlying crypto
       method with the "key" information. If the crytpo method requires
       the storage of additional session information, this nx_crypto_init
       routine must allocate memory as needed, and pass a handle
       back to the caller in the parameter "handler". When NetX IPSec
       invokes this crypto method, the handle is passed to crypto operation.
       'crypto_metadata' Pointer to a storage space managed by the underlying crypto method.
       The content of this block is defined by each sa in use.
       'crypto_metadata_size' is the size of the crypto context block, in bytes. */
    UINT (*nx_crypto_init)(struct NX_CRYPTO_METHOD_STRUCT *method,
                           UCHAR *key, NX_CRYPTO_KEY_SIZE key_size_in_bits,
                           VOID **handler,
                           VOID *crypto_metadata,
                           ULONG crypto_metadata_size);

    /* When the SA is no longer needed, NetX IPSec calls nx_crypto_cleanup
       function and passes in the handler, so that the underlying
       method can clean up the resource, if needed.  */
    UINT (*nx_crypto_cleanup)(VOID *handler);

    /* Function pointer to the actual crypto or hash operation.
       For crypto operation, this function returns NX_SUCCESS or
       appropriate error code.
       Note that both input and output buffers are prepared by the
       caller. For encryption/decryption operations, the callee shall
       use the output buffer for encrypted or decrypted data. For
       authentication operations, the callee shall use the output
       buffer for the digest.
       'crypto_metadata' Pointer to a storage space managed by the underlying crypto method.
       The content of this block is defined by each sa in use.
       'crypto_metadata_size' is the size of the crypto context block, in bytes. */
    UINT (*nx_crypto_operation)(UINT op,       /* Encrypt, Decrypt, Authenticate */
                                VOID *handler, /* Crypto handler */
                                struct NX_CRYPTO_METHOD_STRUCT *method,
                                UCHAR *key,
                                NX_CRYPTO_KEY_SIZE key_size_in_bits,
                                UCHAR *input,
                                ULONG input_length_in_byte,
                                UCHAR *iv_ptr,
                                UCHAR *output,
                                ULONG output_length_in_byte,
                                VOID *crypto_metadata,
                                ULONG crypto_metadata_size,
                                VOID *packet_ptr,
                                VOID (*nx_crypto_hw_process_callback)(VOID *packet_ptr, UINT status));
} NX_CRYPTO_METHOD;

#endif /* _NX_CRYPTO_H_ */

