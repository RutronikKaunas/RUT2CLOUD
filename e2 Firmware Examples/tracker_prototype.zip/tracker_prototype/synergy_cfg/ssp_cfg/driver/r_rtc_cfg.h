/* generated configuration header file - do not edit */
#ifndef R_RTC_CFG_H_
#define R_RTC_CFG_H_
#define RTC_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#endif /* R_RTC_CFG_H_ */
