/* generated configuration header file - do not edit */
#ifndef R_LPMV2_CFG_H_
#define R_LPMV2_CFG_H_
#define LPMV2_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#endif /* R_LPMV2_CFG_H_ */
