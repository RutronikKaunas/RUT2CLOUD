/* generated configuration header file - do not edit */
#ifndef R_FLASH_CFG_H_
#define R_FLASH_CFG_H_
#define FLASH_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#define FLASH_CFG_PARAM_CODE_FLASH_PROGRAMMING_ENABLE (0)
#endif /* R_FLASH_CFG_H_ */
