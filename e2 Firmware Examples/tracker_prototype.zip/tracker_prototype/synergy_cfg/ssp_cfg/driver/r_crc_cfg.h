/* generated configuration header file - do not edit */
#ifndef R_CRC_CFG_H_
#define R_CRC_CFG_H_
#define CRC_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#endif /* R_CRC_CFG_H_ */
