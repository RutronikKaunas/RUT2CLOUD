/* generated configuration header file - do not edit */
#ifndef R_SCI_UART_CFG_H_
#define R_SCI_UART_CFG_H_
#define SCI_UART_CFG_EXTERNAL_RTS_OPERATION (0)
#define SCI_UART_CFG_RX_ENABLE (1)
#define SCI_UART_CFG_TX_ENABLE (1)
#define SCI_UART_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#endif /* R_SCI_UART_CFG_H_ */
