/* generated configuration header file - do not edit */
#ifndef SF_UART_COMMS_CFG_H_
#define SF_UART_COMMS_CFG_H_
#define SF_UART_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#define SF_UART_COMMS_CFG_QUEUE_SIZE_WORDS (256)
#endif /* SF_UART_COMMS_CFG_H_ */
