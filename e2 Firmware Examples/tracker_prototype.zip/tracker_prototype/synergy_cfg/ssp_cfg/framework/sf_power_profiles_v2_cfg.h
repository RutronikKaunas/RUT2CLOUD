/* generated configuration header file - do not edit */
#ifndef SF_POWER_PROFILES_V2_CFG_H_
#define SF_POWER_PROFILES_V2_CFG_H_
#define SF_POWER_PROFILES_V2_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#endif /* SF_POWER_PROFILES_V2_CFG_H_ */
