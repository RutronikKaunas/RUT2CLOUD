/* generated configuration header file - do not edit */
#ifndef SF_I2C_CFG_H_
#define SF_I2C_CFG_H_
#define SF_I2C_CFG_PARAM_CHECKING_ENABLE (1)
#endif /* SF_I2C_CFG_H_ */
